import os
import secrets

# Load .env before anything else so os.environ is populated
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
OUTPUT_FOLDER = os.path.join(BASE_DIR, 'outputs')

ALLOWED_EXTENSIONS = {'pdf', 'docx'}
MAX_UPLOAD_SIZE_MB = int(os.environ.get('MAX_UPLOAD_SIZE_MB', '50'))
MAX_CONTENT_LENGTH = MAX_UPLOAD_SIZE_MB * 1024 * 1024

SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(32))

# ---------------------------------------------------------------------------
# LLM provider selection
# ---------------------------------------------------------------------------
# LLM_PROVIDER: 'ollama' (default, local) | 'gemini' (Vertex AI, external)
LLM_PROVIDER = os.environ.get('LLM_PROVIDER', 'ollama').lower()

# External LLMs (Gemini) are disabled by default.
# Set ALLOW_EXTERNAL_LLM=true only when intentionally using cloud providers.
_ext = os.environ.get('ALLOW_EXTERNAL_LLM', 'false').lower()
ALLOW_EXTERNAL_LLM = _ext in ('true', '1', 'yes')

# Ollama is always treated as local and is never blocked by ALLOW_EXTERNAL_LLM.
LLM_ENABLED = os.environ.get('LLM_ENABLED', 'false').lower() in ('true', '1', 'yes')

# Ollama config
OLLAMA_BASE_URL = os.environ.get('OLLAMA_BASE_URL', 'http://localhost:11434')
OLLAMA_MODEL = os.environ.get('OLLAMA_MODEL', 'qwen')
LLM_TIMEOUT_SECONDS = int(os.environ.get('LLM_TIMEOUT_SECONDS', '60'))

# ---------------------------------------------------------------------------
# Gemini / Vertex AI config
# ---------------------------------------------------------------------------
GEMINI_PROJECT_ID = os.environ.get('GEMINI_PROJECT_ID', '')
GEMINI_LOCATION   = os.environ.get('GEMINI_LOCATION', 'us-central1')
GEMINI_MODEL      = os.environ.get('GEMINI_MODEL', 'gemini-2.5-pro')

# ---------------------------------------------------------------------------
# NLP
# ---------------------------------------------------------------------------
SPACY_MODEL = os.environ.get('SPACY_MODEL', 'en_core_web_sm')
PRESIDIO_ENABLED = os.environ.get('PRESIDIO_ENABLED', 'true').lower() in ('true', '1', 'yes')

# ---------------------------------------------------------------------------
# Session / cleanup
# ---------------------------------------------------------------------------
STATE_TTL_HOURS = int(os.environ.get('STATE_TTL_HOURS', '24'))

# ---------------------------------------------------------------------------
# Logging — never log PHI/PII content
# ---------------------------------------------------------------------------
LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
LOG_FILE  = os.environ.get('LOG_FILE', os.path.join(BASE_DIR, 'app.log'))

DEFAULT_REDACTION_MODE = 'blackout'
