"""
Document Redaction Application — Flask entry point.

Mode 1 — Standard PHI/PII:
  Upload → Review detected entities → Custom search → Preview → Confirm → Download

Mode 2 — AI Redaction Assistant:
  Upload + natural-language instruction → AI generates plan → User reviews plan
  → (optional) Custom search → Apply → Download
"""

import os
import sys
import json
import uuid
import logging
import shutil
from datetime import datetime, timedelta
from io import BytesIO
from pathlib import Path
from typing import Optional

from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, send_file, abort, after_this_request,
)
from werkzeug.utils import secure_filename

# ---------------------------------------------------------------------------
# Bootstrap app
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.config.from_pyfile('config.py')
app.config['MAX_CONTENT_LENGTH'] = app.config.get('MAX_CONTENT_LENGTH', 50 * 1024 * 1024)

# ---------------------------------------------------------------------------
# Logging — never log PHI/PII content
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=getattr(logging, app.config.get('LOG_LEVEL', 'INFO')),
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(app.config.get('LOG_FILE', 'app.log')),
    ],
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory document store (no files written to disk for uploads/outputs)
# ---------------------------------------------------------------------------
_file_store: dict = {}    # file_id -> bytes  (original upload)
_output_store: dict = {}  # file_id -> (bytes, filename)  (redacted output)

# ---------------------------------------------------------------------------
# Ensure session-state directory exists (state.json files only)
# ---------------------------------------------------------------------------
Path(app.config['UPLOAD_FOLDER']).mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = app.config.get('ALLOWED_EXTENSIONS', {'pdf', 'docx'})


# ---------------------------------------------------------------------------
# State helpers
# ---------------------------------------------------------------------------

def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_session_dir(file_id: str) -> Path:
    return Path(app.config['UPLOAD_FOLDER']) / file_id


def get_state_path(file_id: str) -> Path:
    return get_session_dir(file_id) / 'state.json'


def load_state(file_id: str) -> Optional[dict]:
    p = get_state_path(file_id)
    if not p.exists():
        return None
    try:
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        logger.error("Failed to load state %s: %s", file_id, exc)
        return None


def save_state(file_id: str, state: dict) -> None:
    with open(get_state_path(file_id), 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def cleanup_session(file_id: str) -> None:
    _file_store.pop(file_id, None)
    _output_store.pop(file_id, None)
    session_dir = get_session_dir(file_id)
    if session_dir.exists():
        shutil.rmtree(session_dir, ignore_errors=True)


def cleanup_old_sessions() -> None:
    ttl = app.config.get('STATE_TTL_HOURS', 24)
    cutoff = datetime.utcnow() - timedelta(hours=ttl)
    for d in Path(app.config['UPLOAD_FOLDER']).iterdir():
        if not d.is_dir():
            continue
        sp = d / 'state.json'
        if not sp.exists():
            continue
        if datetime.utcfromtimestamp(sp.stat().st_mtime) < cutoff:
            file_id = d.name
            shutil.rmtree(d, ignore_errors=True)
            _file_store.pop(file_id, None)
            _output_store.pop(file_id, None)
            logger.info("Cleaned up expired session: %s", file_id)


def _read_uploaded_file(file) -> tuple:
    """Validate upload and store bytes in memory. Returns (file_id, safe_name, ext)."""
    safe_name = secure_filename(file.filename)
    ext = safe_name.rsplit('.', 1)[1].lower()
    file_id = str(uuid.uuid4())
    file_bytes = file.read()
    _file_store[file_id] = file_bytes
    get_session_dir(file_id).mkdir(parents=True, exist_ok=True)
    logger.info("Uploaded: session=%s ext=%s size=%d bytes", file_id, ext, len(file_bytes))
    return file_id, safe_name, ext


# ---------------------------------------------------------------------------
# Index
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    cleanup_old_sessions()
    llm_provider = app.config.get('LLM_PROVIDER', 'ollama')
    allow_external = app.config.get('ALLOW_EXTERNAL_LLM', False)
    return render_template('index.html',
                           llm_provider=llm_provider,
                           allow_external=allow_external)


# ---------------------------------------------------------------------------
# Upload — branches on mode
# ---------------------------------------------------------------------------

@app.route('/upload', methods=['POST'])
def upload():
    if 'document' not in request.files:
        flash('No file selected.', 'danger')
        return redirect(url_for('index'))

    file = request.files['document']
    if not file or not file.filename:
        flash('No file selected.', 'danger')
        return redirect(url_for('index'))

    if not allowed_file(file.filename):
        flash('Unsupported file type. Please upload a PDF or DOCX file.', 'danger')
        return redirect(url_for('index'))

    mode = request.form.get('mode', 'standard')

    if mode == 'ai_assistant':
        return _handle_ai_upload(file)
    return _handle_standard_upload(file)


def _handle_standard_upload(file):
    """Standard PHI/PII detection workflow."""
    try:
        file_id, safe_name, ext = _read_uploaded_file(file)
    except Exception as exc:
        flash(f'Upload error: {exc}', 'danger')
        return redirect(url_for('index'))

    try:
        entities = _run_detection(file_id, ext)
    except Exception as exc:
        logger.error("Detection failed: %s", exc)
        cleanup_session(file_id)
        flash(f'Error processing document: {exc}', 'danger')
        return redirect(url_for('index'))

    state = {
        'file_id': file_id,
        'mode': 'standard',
        'original_filename': safe_name,
        'file_type': ext,
        'entities': entities,
        'custom_searches': [],
        'pending_search': None,
        'created_at': datetime.utcnow().isoformat(),
        'status': 'pending',
    }
    save_state(file_id, state)
    flash(f'Document processed. Found {len(entities)} potential item(s) to review.', 'success')
    return redirect(url_for('review', file_id=file_id))


def _handle_ai_upload(file):
    """AI Redaction Assistant workflow."""
    instruction = request.form.get('ai_instruction', '').strip()
    if not instruction:
        flash('Please describe what should be redacted before uploading.', 'warning')
        return redirect(url_for('index'))

    # Check LLM is usable before processing the file
    try:
        from services.llm_client import get_llm_client
        get_llm_client()
    except RuntimeError as exc:
        flash(str(exc), 'danger')
        return redirect(url_for('index'))

    try:
        file_id, safe_name, ext = _read_uploaded_file(file)
    except Exception as exc:
        flash(f'Upload error: {exc}', 'danger')
        return redirect(url_for('index'))

    state = {
        'file_id': file_id,
        'mode': 'ai_assistant',
        'ai_instruction': instruction,
        'original_filename': safe_name,
        'file_type': ext,
        'entities': [],
        'custom_searches': [],
        'pending_search': None,
        'ai_plan': None,
        'created_at': datetime.utcnow().isoformat(),
        'status': 'pending',
    }

    try:
        plan = _run_ai_analysis(file_id, ext, instruction)
        state['ai_plan'] = plan
    except RuntimeError as exc:
        cleanup_session(file_id)
        flash(str(exc), 'danger')
        return redirect(url_for('index'))
    except Exception as exc:
        logger.error("AI analysis failed: %s", exc)
        cleanup_session(file_id)
        flash(f'AI analysis error: {exc}', 'danger')
        return redirect(url_for('index'))

    save_state(file_id, state)
    n = len(plan.get('actions', []))
    flash(f'AI generated a redaction plan with {n} proposed action(s). Please review below.', 'info')
    return redirect(url_for('ai_plan_review', file_id=file_id))


def _run_detection(file_id: str, ext: str) -> list:
    from services.extractor import extract_pdf, extract_docx
    from services.pii_detector import detect_pii_in_pdf, detect_pii_in_docx
    from services.llm_detector import detect_with_llm_pdf, detect_with_llm_docx

    file_bytes = _file_store[file_id]
    if ext == 'pdf':
        pages = extract_pdf(file_bytes)
        entities = detect_pii_in_pdf(pages) + detect_with_llm_pdf(pages)
    else:
        segments = extract_docx(file_bytes)
        entities = detect_pii_in_docx(segments) + detect_with_llm_docx(segments)

    seen = {}
    for e in entities:
        key = f"{e['text'].lower()}|{e['location']}"
        if key not in seen or e['confidence'] > seen[key]['confidence']:
            seen[key] = e
    return list(seen.values())


def _run_ai_analysis(file_id: str, ext: str, instruction: str) -> dict:
    from services.extractor import extract_pdf, extract_docx, get_full_text_pdf, get_full_text_docx
    from services.ai_redaction_assistant import analyze_document, normalize_actions, resolve_locations

    file_bytes = _file_store[file_id]
    if ext == 'pdf':
        pages = extract_pdf(file_bytes)
        full_text = get_full_text_pdf(pages)
        raw_plan = analyze_document(full_text, instruction)
        actions = normalize_actions(raw_plan.get('actions', []))
        actions = resolve_locations(actions, pages, 'pdf')
    else:
        segments = extract_docx(file_bytes)
        full_text = get_full_text_docx(segments)
        raw_plan = analyze_document(full_text, instruction)
        actions = normalize_actions(raw_plan.get('actions', []))
        actions = resolve_locations(actions, segments, 'docx')

    return {
        'summary': raw_plan.get('summary', ''),
        'actions': actions,
    }


# ---------------------------------------------------------------------------
# AI Redaction Assistant — Plan Review
# ---------------------------------------------------------------------------

@app.route('/ai_plan/<file_id>', methods=['GET'])
def ai_plan_review(file_id):
    state = load_state(file_id)
    if not state or state.get('mode') != 'ai_assistant':
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))
    if not state.get('ai_plan'):
        flash('No AI plan found. Please re-upload.', 'warning')
        return redirect(url_for('index'))

    plan = state['ai_plan']
    resolved = [a for a in plan['actions'] if a['status'] == 'resolved']
    needs_review = [a for a in plan['actions'] if a['status'] == 'needs_review']
    return render_template('ai_plan_review.html', state=state, plan=plan,
                           resolved=resolved, needs_review=needs_review)


@app.route('/ai_plan/<file_id>/apply', methods=['POST'])
def ai_plan_apply(file_id):
    """
    Convert approved AI plan actions into standard entities and apply redaction.
    """
    state = load_state(file_id)
    if not state or state.get('mode') != 'ai_assistant':
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))

    plan = state.get('ai_plan', {})
    actions = plan.get('actions', [])

    # Parse form: per-action selection, mode, replacement
    for action in actions:
        aid = action['action_id']
        action['selected'] = f'sel_{aid}' in request.form
        action['selected_mode'] = request.form.get(f'mode_{aid}', action['recommended_mode'])
        action['selected_replacement'] = request.form.get(f'rep_{aid}', action['replacement_text']).strip()

    approved = [a for a in actions if a.get('selected')]
    if not approved:
        flash('No actions selected. Please select at least one item to redact.', 'warning')
        return redirect(url_for('ai_plan_review', file_id=file_id))

    # Convert to standard entity format
    from services.ai_redaction_assistant import actions_to_entities
    entities = actions_to_entities(approved)
    state['entities'] = entities
    state['ai_plan']['actions'] = actions
    save_state(file_id, state)

    return redirect(url_for('redact_confirm', file_id=file_id))


# ---------------------------------------------------------------------------
# Standard Review
# ---------------------------------------------------------------------------

@app.route('/review/<file_id>', methods=['GET'])
def review(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))
    entity_types = sorted({e['entity_type'] for e in state['entities']})
    sources = sorted({e['source'] for e in state['entities']})
    return render_template('review.html', state=state,
                           entity_types=entity_types, sources=sources)


@app.route('/review/<file_id>/save', methods=['POST'])
def save_review(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))

    for entity in state['entities']:
        eid = entity['id']
        entity['selected'] = f'sel_{eid}' in request.form
        entity['mode'] = request.form.get(f'mode_{eid}', 'blackout')
        entity['replacement'] = request.form.get(f'rep_{eid}', '').strip()

    save_state(file_id, state)
    action = request.form.get('action', 'custom')
    if action == 'redact':
        return redirect(url_for('redact_confirm', file_id=file_id))
    return redirect(url_for('custom_search', file_id=file_id))


# ---------------------------------------------------------------------------
# Custom Search (shared by both modes)
# ---------------------------------------------------------------------------

@app.route('/custom/<file_id>', methods=['GET'])
def custom_search(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))
    return render_template('custom_search.html', state=state)


@app.route('/custom/<file_id>/search', methods=['POST'])
def custom_search_submit(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))

    search_text = request.form.get('search_text', '').strip()
    if not search_text:
        flash('Please enter text to search for.', 'warning')
        return redirect(url_for('custom_search', file_id=file_id))

    file_bytes = _file_store.get(file_id)
    if file_bytes is None:
        flash('Session data unavailable (server may have restarted). Please re-upload.', 'warning')
        cleanup_session(file_id)
        return redirect(url_for('index'))

    try:
        matches = _run_custom_search(file_bytes, state['file_type'], search_text)
    except Exception as exc:
        flash(f'Search error: {exc}', 'danger')
        return redirect(url_for('custom_search', file_id=file_id))

    if not matches:
        flash(f'No occurrences of "{search_text}" found in the document.', 'info')
        return redirect(url_for('custom_search', file_id=file_id))

    state['pending_search'] = {'search_text': search_text, 'matches': matches}
    save_state(file_id, state)
    return redirect(url_for('preview', file_id=file_id))


@app.route('/custom/<file_id>/ai_search', methods=['POST'])
def ai_custom_search(file_id):
    """Smart search: describe what to find; LLM identifies exact text in the document."""
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))

    query = request.form.get('ai_query', '').strip()
    if not query:
        flash('Please describe what to search for.', 'warning')
        return redirect(url_for('custom_search', file_id=file_id))

    try:
        from services.llm_client import get_llm_client
        get_llm_client()
    except RuntimeError as exc:
        flash(str(exc), 'danger')
        return redirect(url_for('custom_search', file_id=file_id))

    file_bytes = _file_store.get(file_id)
    if file_bytes is None:
        flash('Session data unavailable (server may have restarted). Please re-upload.', 'warning')
        cleanup_session(file_id)
        return redirect(url_for('index'))

    try:
        from services.extractor import extract_pdf, extract_docx, get_full_text_pdf, get_full_text_docx
        from services.ai_redaction_assistant import smart_search
        ext = state['file_type']
        if ext == 'pdf':
            full_text = get_full_text_pdf(extract_pdf(file_bytes))
        else:
            full_text = get_full_text_docx(extract_docx(file_bytes))
        candidates = smart_search(full_text, query)
    except RuntimeError as exc:
        flash(str(exc), 'danger')
        return redirect(url_for('custom_search', file_id=file_id))
    except Exception as exc:
        logger.error("AI smart search failed: %s", exc)
        flash(f'AI search error: {exc}', 'danger')
        return redirect(url_for('custom_search', file_id=file_id))

    if not candidates:
        flash(f'No matches found for "{query}". Try rephrasing or use exact text search.', 'info')
        return redirect(url_for('custom_search', file_id=file_id))

    all_matches = []
    for text in candidates:
        try:
            all_matches.extend(_run_custom_search(file_bytes, ext, text))
        except Exception:
            pass

    if not all_matches:
        flash(
            f'AI identified {len(candidates)} candidate(s) for "{query}" '
            'but could not locate them exactly in the document. '
            'Try exact text search instead.',
            'warning',
        )
        return redirect(url_for('custom_search', file_id=file_id))

    state['pending_search'] = {
        'search_text': f'[AI] {query}',
        'matches': all_matches,
    }
    save_state(file_id, state)
    return redirect(url_for('preview', file_id=file_id))


def _run_custom_search(file_bytes: bytes, ext: str, search_text: str) -> list:
    from services.extractor import extract_pdf, extract_docx
    from services.custom_matcher import search_in_pdf_pages, search_in_docx_segments
    if ext == 'pdf':
        return search_in_pdf_pages(extract_pdf(file_bytes), search_text)
    return search_in_docx_segments(extract_docx(file_bytes), search_text)


@app.route('/preview/<file_id>', methods=['GET'])
def preview(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))
    if not state.get('pending_search'):
        return redirect(url_for('custom_search', file_id=file_id))
    return render_template('preview.html', state=state)


@app.route('/preview/<file_id>/confirm', methods=['POST'])
def preview_confirm(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))

    pending = state.get('pending_search')
    if not pending:
        return redirect(url_for('custom_search', file_id=file_id))

    for match in pending['matches']:
        mid = match['id']
        match['selected'] = f'sel_{mid}' in request.form
        match['mode'] = request.form.get(f'mode_{mid}', 'blackout')
        match['replacement'] = request.form.get(f'rep_{mid}', '').strip()

    selected = [m for m in pending['matches'] if m['selected']]
    if selected:
        state['custom_searches'].append({'search_text': pending['search_text'], 'matches': selected})
        flash(f'Added {len(selected)} match(es) for "{pending["search_text"]}" to redaction list.', 'success')

    state['pending_search'] = None
    save_state(file_id, state)

    action = request.form.get('action', 'more')
    if action == 'redact':
        return redirect(url_for('redact_confirm', file_id=file_id))
    return redirect(url_for('custom_search', file_id=file_id))


@app.route('/custom/<file_id>/remove/<int:search_idx>', methods=['POST'])
def remove_custom_search(file_id, search_idx):
    state = load_state(file_id)
    if not state:
        abort(404)
    if 0 <= search_idx < len(state['custom_searches']):
        removed = state['custom_searches'].pop(search_idx)
        save_state(file_id, state)
        flash(f'Removed "{removed["search_text"]}" from redaction list.', 'info')
    return redirect(url_for('custom_search', file_id=file_id))


# ---------------------------------------------------------------------------
# Redaction (shared final step)
# ---------------------------------------------------------------------------

@app.route('/redact/<file_id>', methods=['GET'])
def redact_confirm(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))

    ai_selected = [e for e in state['entities'] if e.get('selected')]
    custom_matches = [m for cs in state['custom_searches']
                      for m in cs['matches'] if m.get('selected')]
    return render_template('redact_confirm.html', state=state,
                           ai_selected=ai_selected, custom_matches=custom_matches)


@app.route('/redact/<file_id>/apply', methods=['POST'])
def apply_redaction(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))

    if state.get('status') == 'redacted':
        return redirect(url_for('result', file_id=file_id))

    file_bytes = _file_store.get(file_id)
    if file_bytes is None:
        flash('Session data unavailable (server may have restarted). Please re-upload.', 'warning')
        cleanup_session(file_id)
        return redirect(url_for('index'))

    ext = state['file_type']
    stem = Path(state['original_filename']).stem
    output_filename = f"{stem}_redacted.{ext}"

    all_entities = list(state['entities'])
    for cs in state['custom_searches']:
        all_entities.extend(cs['matches'])

    try:
        if ext == 'pdf':
            from services.redactor_pdf import redact_pdf
            result = redact_pdf(file_bytes, all_entities)
        else:
            from services.redactor_docx import redact_docx
            result = redact_docx(file_bytes, all_entities)
    except Exception as exc:
        logger.error("Redaction failed for %s: %s", file_id, exc)
        flash(f'Redaction error: {exc}', 'danger')
        return redirect(url_for('redact_confirm', file_id=file_id))

    output_bytes = result.pop('output_bytes')
    _output_store[file_id] = (output_bytes, output_filename)
    # Original no longer needed — release memory
    _file_store.pop(file_id, None)

    state.update({
        'status': 'redacted',
        'output_filename': output_filename,
        'redaction_summary': result,
        'redacted_at': datetime.utcnow().isoformat(),
    })
    save_state(file_id, state)
    logger.info("Redaction complete: session=%s entities=%d", file_id, len(all_entities))
    return redirect(url_for('result', file_id=file_id))


# ---------------------------------------------------------------------------
# Result + Download
# ---------------------------------------------------------------------------

@app.route('/result/<file_id>')
def result(file_id):
    state = load_state(file_id)
    if not state:
        flash('Session not found or expired.', 'warning')
        return redirect(url_for('index'))
    if state.get('status') != 'redacted':
        return redirect(url_for('redact_confirm', file_id=file_id))

    ai_count = sum(1 for e in state['entities'] if e.get('selected'))
    custom_count = sum(1 for cs in state['custom_searches']
                       for m in cs['matches'] if m.get('selected'))
    return render_template('result.html', state=state,
                           ai_count=ai_count, custom_count=custom_count)


@app.route('/download/<file_id>')
def download(file_id):
    state = load_state(file_id)
    if not state or state.get('status') != 'redacted':
        abort(404)

    entry = _output_store.get(file_id)
    if not entry:
        abort(404)

    output_bytes, output_filename = entry
    ext = state.get('file_type', 'pdf')
    mimetype = (
        'application/pdf' if ext == 'pdf'
        else 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )

    @after_this_request
    def _cleanup(response):
        if response.status_code == 200:
            cleanup_session(file_id)
            logger.info("Session cleaned up after download: %s", file_id)
        return response

    return send_file(
        BytesIO(output_bytes),
        as_attachment=True,
        download_name=output_filename,
        mimetype=mimetype,
    )


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

@app.errorhandler(413)
def too_large(e):
    flash(f'File too large. Max {app.config.get("MAX_UPLOAD_SIZE_MB", 50)} MB.', 'danger')
    return redirect(url_for('index'))


@app.errorhandler(404)
def not_found(e):
    return render_template('error.html', error='Page not found.'), 404


@app.errorhandler(500)
def server_error(e):
    logger.exception("Unhandled server error")
    return render_template('error.html', error='An internal error occurred.'), 500


# ---------------------------------------------------------------------------
# Template helpers
# ---------------------------------------------------------------------------

@app.template_filter('pct')
def pct_filter(value):
    try:
        return f"{int(float(value) * 100)}%"
    except (TypeError, ValueError):
        return '—'


@app.context_processor
def inject_globals():
    return {
        'llm_enabled': app.config.get('LLM_ENABLED', False),
        'llm_provider': app.config.get('LLM_PROVIDER', 'ollama'),
        'allow_external': app.config.get('ALLOW_EXTERNAL_LLM', False),
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    debug = os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=debug)
