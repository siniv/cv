"""
Unit tests for the regex-based PII/PHI detection layer.
These tests do not require Presidio or spaCy to be installed.
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from services.pii_detector import detect_with_regex, _deduplicate


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def entity_texts(entities):
    return [e['text'] for e in entities]


def entity_types(entities):
    return [e['entity_type'] for e in entities]


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

class TestEmailDetection:
    def test_simple_email(self):
        result = detect_with_regex("Contact me at alice@example.com please.", "Page 1")
        assert any(e['entity_type'] == 'EMAIL' for e in result)
        assert 'alice@example.com' in entity_texts(result)

    def test_email_with_plus_tag(self):
        result = detect_with_regex("Send to bob+tag@company.org", "Page 1")
        assert 'bob+tag@company.org' in entity_texts(result)

    def test_no_email_in_plain_text(self):
        result = detect_with_regex("No contact information here.", "Page 1")
        assert not any(e['entity_type'] == 'EMAIL' for e in result)

    def test_multiple_emails(self):
        result = detect_with_regex(
            "Primary: alice@a.com  Backup: bob@b.org", "Page 1"
        )
        texts = entity_texts(result)
        assert 'alice@a.com' in texts
        assert 'bob@b.org' in texts


# ---------------------------------------------------------------------------
# Phone
# ---------------------------------------------------------------------------

class TestPhoneDetection:
    def test_dashed_phone(self):
        result = detect_with_regex("Call 555-234-5678 now.", "Page 1")
        assert any(e['entity_type'] == 'PHONE' for e in result)

    def test_dotted_phone(self):
        result = detect_with_regex("Reach us at 555.234.5678", "Page 1")
        assert any(e['entity_type'] == 'PHONE' for e in result)

    def test_parentheses_phone(self):
        result = detect_with_regex("Office: (800) 555-1234", "Page 1")
        assert any(e['entity_type'] == 'PHONE' for e in result)


# ---------------------------------------------------------------------------
# SSN
# ---------------------------------------------------------------------------

class TestSSNDetection:
    def test_valid_ssn(self):
        result = detect_with_regex("SSN: 123-45-6789", "Page 2")
        assert any(e['entity_type'] == 'SSN' for e in result)

    def test_invalid_ssn_all_zeros(self):
        # SSN starting with 000 is invalid
        result = detect_with_regex("000-45-6789", "Page 2")
        assert not any(e['entity_type'] == 'SSN' for e in result)

    def test_ssn_confidence_high(self):
        result = detect_with_regex("123-45-6789", "Page 2")
        ssns = [e for e in result if e['entity_type'] == 'SSN']
        assert ssns[0]['confidence'] >= 0.95


# ---------------------------------------------------------------------------
# IP Address
# ---------------------------------------------------------------------------

class TestIPAddressDetection:
    def test_valid_ipv4(self):
        result = detect_with_regex("Server at 192.168.1.100", "Page 3")
        assert any(e['entity_type'] == 'IP_ADDRESS' for e in result)

    def test_invalid_ip_out_of_range(self):
        result = detect_with_regex("Address: 999.999.999.999", "Page 3")
        assert not any(e['entity_type'] == 'IP_ADDRESS' for e in result)


# ---------------------------------------------------------------------------
# URL
# ---------------------------------------------------------------------------

class TestURLDetection:
    def test_https_url(self):
        result = detect_with_regex("Visit https://example.com/path?q=1", "Page 3")
        assert any(e['entity_type'] == 'URL' for e in result)

    def test_http_url(self):
        result = detect_with_regex("See http://old-site.org", "Page 3")
        assert any(e['entity_type'] == 'URL' for e in result)


# ---------------------------------------------------------------------------
# Medical Record Number
# ---------------------------------------------------------------------------

class TestMedicalRecordDetection:
    def test_mrn_prefix(self):
        result = detect_with_regex("Patient MRN: 1234567", "Page 4")
        assert any(e['entity_type'] == 'MEDICAL_RECORD_NUMBER' for e in result)

    def test_medical_record_prefix(self):
        result = detect_with_regex("Medical Record Number: 98765", "Page 4")
        assert any(e['entity_type'] == 'MEDICAL_RECORD_NUMBER' for e in result)


# ---------------------------------------------------------------------------
# Tax ID
# ---------------------------------------------------------------------------

class TestTaxIDDetection:
    def test_ein_format(self):
        result = detect_with_regex("EIN: 12-3456789", "Page 5")
        assert any(e['entity_type'] == 'TAX_ID' for e in result)


# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------

class TestDeduplication:
    def test_removes_exact_duplicates(self):
        entities = [
            {'id': '1', 'text': 'john@example.com', 'location': 'Page 1',
             'entity_type': 'EMAIL', 'confidence': 0.99, 'source': 'RULE',
             'mode': 'blackout', 'replacement': '', 'selected': True},
            {'id': '2', 'text': 'john@example.com', 'location': 'Page 1',
             'entity_type': 'EMAIL', 'confidence': 0.85, 'source': 'NLP',
             'mode': 'blackout', 'replacement': '', 'selected': True},
        ]
        deduped = _deduplicate(entities)
        assert len(deduped) == 1
        # Keeps the higher-confidence one
        assert deduped[0]['confidence'] == 0.99

    def test_keeps_different_locations(self):
        entities = [
            {'id': '1', 'text': 'john@example.com', 'location': 'Page 1',
             'entity_type': 'EMAIL', 'confidence': 0.99, 'source': 'RULE',
             'mode': 'blackout', 'replacement': '', 'selected': True},
            {'id': '2', 'text': 'john@example.com', 'location': 'Page 3',
             'entity_type': 'EMAIL', 'confidence': 0.99, 'source': 'RULE',
             'mode': 'blackout', 'replacement': '', 'selected': True},
        ]
        deduped = _deduplicate(entities)
        assert len(deduped) == 2

    def test_case_insensitive_dedup(self):
        entities = [
            {'id': '1', 'text': 'John@Example.COM', 'location': 'Page 1',
             'entity_type': 'EMAIL', 'confidence': 0.90, 'source': 'RULE',
             'mode': 'blackout', 'replacement': '', 'selected': True},
            {'id': '2', 'text': 'john@example.com', 'location': 'Page 1',
             'entity_type': 'EMAIL', 'confidence': 0.99, 'source': 'NLP',
             'mode': 'blackout', 'replacement': '', 'selected': True},
        ]
        deduped = _deduplicate(entities)
        assert len(deduped) == 1


# ---------------------------------------------------------------------------
# Entity structure
# ---------------------------------------------------------------------------

class TestEntityStructure:
    def test_entity_has_required_fields(self):
        result = detect_with_regex("Email: test@test.com", "Page 1")
        assert result
        entity = result[0]
        for field in ('id', 'source', 'entity_type', 'text', 'location',
                      'confidence', 'mode', 'replacement', 'selected'):
            assert field in entity, f"Missing field: {field}"

    def test_default_mode_is_blackout(self):
        result = detect_with_regex("Email: test@test.com", "Page 1")
        assert result[0]['mode'] == 'blackout'

    def test_default_selected_is_true(self):
        result = detect_with_regex("Email: test@test.com", "Page 1")
        assert result[0]['selected'] is True

    def test_source_is_rule(self):
        result = detect_with_regex("Email: test@test.com", "Page 1")
        assert result[0]['source'] == 'RULE'
