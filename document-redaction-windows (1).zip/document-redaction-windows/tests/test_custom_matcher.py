"""
Unit tests for the custom text matcher.
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from services.custom_matcher import (
    search_in_pdf_pages,
    search_in_docx_segments,
    count_occurrences,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SAMPLE_PAGES = [
    {'page': 1, 'text': 'This agreement is between Lexality and ABC Corp dated January 2024.'},
    {'page': 2, 'text': 'Lexality provides services under this master service agreement.'},
    {'page': 3, 'text': 'No mention here of the company name at all.'},
    {'page': 4, 'text': 'LEXALITY (in caps) also appears on this page and lexality (lowercase) too.'},
]

SAMPLE_SEGMENTS = [
    {'idx': 0, 'text': 'Client: Acme Corporation', 'location': 'Paragraph 1', 'type': 'paragraph'},
    {'idx': 1, 'text': 'The Acme Corporation agrees to the terms.', 'location': 'Paragraph 2', 'type': 'paragraph'},
    {'idx': 2, 'text': 'Payment is due within 30 days.', 'location': 'Paragraph 3', 'type': 'paragraph'},
    {'idx': 3, 'text': 'ACME CORPORATION confirms receipt.', 'location': 'Table 1, Row 1, Col 1', 'type': 'table'},
]


# ---------------------------------------------------------------------------
# PDF search
# ---------------------------------------------------------------------------

class TestSearchInPDFPages:
    def test_finds_single_word(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'Lexality')
        assert len(results) >= 2  # pages 1 and 2

    def test_case_insensitive(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'lexality')
        # Should find on pages 1, 2, and 4 (lowercase + LEXALITY + lexality)
        assert len(results) >= 3

    def test_finds_phrase(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'master service agreement')
        assert len(results) == 1
        assert results[0]['page'] == 2

    def test_no_match_returns_empty(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'nonexistent_xyz_123')
        assert results == []

    def test_empty_search_returns_empty(self):
        assert search_in_pdf_pages(SAMPLE_PAGES, '') == []
        assert search_in_pdf_pages(SAMPLE_PAGES, '   ') == []

    def test_result_has_required_fields(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'Lexality')
        assert results
        r = results[0]
        for field in ('id', 'text', 'page', 'location', 'context',
                      'mode', 'replacement', 'selected'):
            assert field in r, f"Missing field: {field}"

    def test_context_surrounds_match(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'ABC Corp')
        assert results
        assert 'ABC Corp' in results[0]['context']
        # Context should include surrounding text
        assert 'Lexality' in results[0]['context'] or 'agreement' in results[0]['context']

    def test_page_number_correct(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'January 2024')
        assert results[0]['page'] == 1

    def test_default_selected_true(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'Lexality')
        assert all(r['selected'] for r in results)

    def test_default_mode_blackout(self):
        results = search_in_pdf_pages(SAMPLE_PAGES, 'Lexality')
        assert all(r['mode'] == 'blackout' for r in results)

    def test_multiple_on_same_page(self):
        # Page 4 has LEXALITY and lexality — two occurrences
        results = search_in_pdf_pages(SAMPLE_PAGES, 'lexality')
        page4 = [r for r in results if r['page'] == 4]
        assert len(page4) >= 2


# ---------------------------------------------------------------------------
# DOCX search
# ---------------------------------------------------------------------------

class TestSearchInDOCXSegments:
    def test_finds_phrase_across_paragraphs(self):
        results = search_in_docx_segments(SAMPLE_SEGMENTS, 'Acme Corporation')
        assert len(results) == 3  # paragraphs 1, 2 and table

    def test_case_insensitive(self):
        results = search_in_docx_segments(SAMPLE_SEGMENTS, 'acme corporation')
        assert len(results) == 3

    def test_no_match(self):
        results = search_in_docx_segments(SAMPLE_SEGMENTS, 'XYZ Holdings')
        assert results == []

    def test_result_has_location(self):
        results = search_in_docx_segments(SAMPLE_SEGMENTS, 'Acme Corporation')
        locations = {r['location'] for r in results}
        assert 'Paragraph 1' in locations
        assert 'Table 1, Row 1, Col 1' in locations

    def test_segment_idx_present(self):
        results = search_in_docx_segments(SAMPLE_SEGMENTS, 'Acme Corporation')
        assert all(r['segment_idx'] is not None for r in results)


# ---------------------------------------------------------------------------
# Count occurrences
# ---------------------------------------------------------------------------

class TestCountOccurrences:
    def test_pdf_count(self):
        n = count_occurrences(SAMPLE_PAGES, 'Lexality', is_pdf=True)
        assert n >= 2

    def test_docx_count(self):
        n = count_occurrences(SAMPLE_SEGMENTS, 'Acme Corporation', is_pdf=False)
        assert n == 3

    def test_zero_for_no_match(self):
        assert count_occurrences(SAMPLE_PAGES, 'ZZZNOMATCH', is_pdf=True) == 0

    def test_empty_search(self):
        assert count_occurrences(SAMPLE_PAGES, '', is_pdf=True) == 0
