"""
Hybrid PII/PHI detection: regex rules + Microsoft Presidio + spaCy NER.
Each component degrades gracefully if its dependencies are missing.
"""

import re
import uuid
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Regex patterns for rule-based detection
# Format: entity_type -> (pattern, confidence)
# ---------------------------------------------------------------------------
REGEX_PATTERNS: Dict[str, tuple] = {
    'EMAIL': (
        r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b',
        0.99,
    ),
    'PHONE': (
        r'\b(\+?1[\s.\-]?)?\(?[2-9]\d{2}\)?[\s.\-][2-9]\d{2}[\s.\-]\d{4}\b',
        0.95,
    ),
    'SSN': (
        r'\b(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b',
        0.99,
    ),
    'CREDIT_CARD': (
        r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|'
        r'6(?:011|5[0-9]{2})[0-9]{12})\b',
        0.95,
    ),
    'DATE_OF_BIRTH': (
        r'\b(?:0?[1-9]|1[0-2])[/\-](?:0?[1-9]|[12]\d|3[01])[/\-](?:19|20)\d{2}\b',
        0.85,
    ),
    'TAX_ID': (
        r'\b\d{2}-\d{7}\b',
        0.90,
    ),
    'MEDICAL_RECORD_NUMBER': (
        r'\b(?:MRN?|Medical\s+Record(?:\s+Number)?|MR#)[\s:#]*\d{5,10}\b',
        0.95,
    ),
    'ACCOUNT_NUMBER': (
        r'\b(?:account|acct)[\s#:]*\d{6,16}\b',
        0.88,
    ),
    'POLICY_NUMBER': (
        r'\b(?:policy|pol(?:icy)?(?:\s+no\.?|\s+number)?)[\s:#]*[A-Z0-9]{6,16}\b',
        0.85,
    ),
    'MEMBER_ID': (
        r'\b(?:member\s+(?:id|no\.?|number)|mbr[\s#:]+)[\s:#]*[A-Z0-9]{6,16}\b',
        0.85,
    ),
    'NATIONAL_PROVIDER_ID': (
        r'\bNPI[\s:#]*\d{10}\b',
        0.97,
    ),
    'DEA_NUMBER': (
        r'\bDEA[\s:#]*[A-Z]{2}\d{7}\b',
        0.97,
    ),
    'PASSPORT': (
        r'\b[A-Z]{1,2}\d{6,9}\b',
        0.70,
    ),
    'DRIVERS_LICENSE': (
        r'\b(?:DL|Driver(?:s)?(?:\s+License)?)[\s:#]*[A-Z0-9]{6,12}\b',
        0.80,
    ),
}

# ---------------------------------------------------------------------------
# Presidio setup (lazy init)
# ---------------------------------------------------------------------------
_presidio_analyzer = None
_presidio_available = None


def _get_presidio_analyzer():
    global _presidio_analyzer, _presidio_available
    if _presidio_available is not None:
        return _presidio_analyzer

    try:
        from presidio_analyzer import AnalyzerEngine
        from presidio_analyzer.nlp_engine import NlpEngineProvider
        import config

        spacy_model = getattr(config, 'SPACY_MODEL', 'en_core_web_lg')

        provider = NlpEngineProvider(nlp_configuration={
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": "en", "model_name": spacy_model}],
        })
        nlp_engine = provider.create_engine()
        _presidio_analyzer = AnalyzerEngine(nlp_engine=nlp_engine)
        _presidio_available = True
        logger.info("Presidio analyzer initialized with model: %s", spacy_model)
    except Exception as exc:
        logger.warning("Presidio not available (%s). Falling back to regex only.", exc)
        _presidio_available = False
        _presidio_analyzer = None

    return _presidio_analyzer


# ---------------------------------------------------------------------------
# spaCy standalone setup (used if Presidio is not available)
# ---------------------------------------------------------------------------
_spacy_nlp = None
_spacy_available = None


def _get_spacy_nlp():
    global _spacy_nlp, _spacy_available
    if _spacy_available is not None:
        return _spacy_nlp

    try:
        import spacy
        import config
        spacy_model = getattr(config, 'SPACY_MODEL', 'en_core_web_lg')
        _spacy_nlp = spacy.load(spacy_model)
        _spacy_available = True
        logger.info("spaCy model loaded: %s", spacy_model)
    except Exception as exc:
        logger.warning("spaCy not available (%s). NER will be skipped.", exc)
        _spacy_available = False
        _spacy_nlp = None

    return _spacy_nlp


# ---------------------------------------------------------------------------
# Presidio entity type mapping to our types
# ---------------------------------------------------------------------------
# Only map the Presidio entity types we actually want to surface.
# Unmapped types (ORGANIZATION, DATE_TIME, LOCATION, NRP, URL, IP_ADDRESS,
# MEDICAL_LICENSE) are silently dropped.
PRESIDIO_TYPE_MAP = {
    'PERSON': 'PERSON',
    'EMAIL_ADDRESS': 'EMAIL',
    'PHONE_NUMBER': 'PHONE',
    'US_SSN': 'SSN',
    'CREDIT_CARD': 'CREDIT_CARD',
    'US_PASSPORT': 'PASSPORT',
    'US_DRIVER_LICENSE': 'DRIVERS_LICENSE',
    'US_ITIN': 'TAX_ID',
    'US_BANK_NUMBER': 'ACCOUNT_NUMBER',
    'IBAN_CODE': 'ACCOUNT_NUMBER',
}

# Words that indicate an entity is an organisation/program, not a person.
# Used to filter NLP-detected PERSON entities that are actually organisations.
_ORG_WORDS = frozenset({
    'foundation', 'fdn', 'society', 'samaj', 'samiti', 'sabha', 'samman',
    'scholarship', 'college', 'university', 'institute', 'institution',
    'school', 'academy', 'trust', 'vidyamandir', 'vidyalaya', 'mandir',
    'corp', 'corporation', 'company', 'co', 'ltd', 'llc', 'inc', 'plc',
    'manufacturer', 'manufacturing', 'industries', 'industry', 'enterprises',
    'building', 'article', 'center', 'centre', 'club', 'association',
    'organization', 'organisation', 'group', 'fund', 'committee',
    'department', 'agency', 'bureau', 'authority', 'services', 'solutions',
    'hospital', 'clinic', 'medical', 'health', 'healthcare',
    'bank', 'insurance', 'capital', 'finance', 'investment', 'ventures',
    'seva', 'kalyan', 'pinjrapole', 'parishad', 'kendra', 'ashram',
})


def _looks_like_person(text: str) -> bool:
    """
    Return False if the NLP-detected 'PERSON' entity is likely an organisation,
    program name, or other non-person entity.
    Heuristics:
      - More than 5 words → probably an org or phrase
      - Contains a digit → not a person name
      - Contains org-indicator words → organisation
      - Contains punctuation typical of titles/headlines (–, —, +, /, &)
    """
    if not text or not text.strip():
        return False
    words = text.strip().split()
    if len(words) > 5:
        return False
    if any(ch.isdigit() for ch in text):
        return False
    if any(ch in text for ch in ('–', '—', '+', '&', '/', '\\', '|', '@')):
        return False
    lower_words = {w.strip('.,()[]').lower() for w in words}
    if lower_words & _ORG_WORDS:
        return False
    return True


# Only PERSON is retained from spaCy NER; everything else is skipped.
SPACY_ENTITY_MAP = {
    'PERSON': 'PERSON',
    'ORG': None,
    'GPE': None,
    'LOC': None,
    'FAC': None,
    'DATE': None,
    'CARDINAL': None,
    'MONEY': None,
    'PERCENT': None,
    'ORDINAL': None,
    'QUANTITY': None,
    'TIME': None,
    'WORK_OF_ART': None,
    'LAW': None,
    'LANGUAGE': None,
    'EVENT': None,
    'PRODUCT': None,
    'NORP': None,
}


def _make_entity(source: str, entity_type: str, text: str, location: str,
                 confidence: float, page: Optional[int] = None,
                 para_idx=None) -> Dict[str, Any]:
    return {
        'id': str(uuid.uuid4()),
        'source': source,
        'entity_type': entity_type,
        'text': text,
        'location': location,
        'page': page,
        'para_idx': para_idx,
        'confidence': round(confidence, 2),
        'mode': 'blackout',
        'replacement': '',
        'selected': True,
    }


def detect_with_regex(text: str, location: str, page: Optional[int] = None,
                      para_idx=None) -> List[Dict[str, Any]]:
    """Apply all regex patterns to `text`, returning matched entities."""
    found = []
    for entity_type, (pattern, confidence) in REGEX_PATTERNS.items():
        for match in re.finditer(pattern, text, re.IGNORECASE):
            matched_text = match.group()
            found.append(_make_entity(
                source='RULE',
                entity_type=entity_type,
                text=matched_text,
                location=location,
                confidence=confidence,
                page=page,
                para_idx=para_idx,
            ))
    return found


def detect_with_presidio(text: str, location: str, page: Optional[int] = None,
                         para_idx=None) -> List[Dict[str, Any]]:
    """Run Presidio NLP analyzer on `text`."""
    analyzer = _get_presidio_analyzer()
    if not analyzer:
        return []

    try:
        # Restrict to only the entity types we have explicit mappings for;
        # this stops Presidio running ORGANIZATION, DATE_TIME, LOCATION etc.
        results = analyzer.analyze(
            text=text,
            language='en',
            entities=list(PRESIDIO_TYPE_MAP.keys()),
        )
    except Exception as exc:
        logger.warning("Presidio analysis failed: %s", exc)
        return []

    found = []
    for r in results:
        entity_type = PRESIDIO_TYPE_MAP.get(r.entity_type)
        if entity_type is None:
            continue
        matched_text = text[r.start:r.end].strip()
        # Filter out implausible short matches for ID-type entities
        if entity_type == 'DRIVERS_LICENSE' and len(matched_text) < 6:
            continue
        if entity_type == 'PASSPORT' and len(matched_text) < 6:
            continue
        # Filter NLP PERSON entities that look like organisations
        if entity_type == 'PERSON' and not _looks_like_person(matched_text):
            continue
        found.append(_make_entity(
            source='NLP',
            entity_type=entity_type,
            text=matched_text,
            location=location,
            confidence=round(r.score, 2),
            page=page,
            para_idx=para_idx,
        ))
    return found


def detect_with_spacy(text: str, location: str, page: Optional[int] = None,
                      para_idx=None) -> List[Dict[str, Any]]:
    """Run spaCy NER on `text` (used when Presidio is unavailable)."""
    nlp = _get_spacy_nlp()
    if not nlp:
        return []

    try:
        doc = nlp(text)
    except Exception as exc:
        logger.warning("spaCy NER failed: %s", exc)
        return []

    found = []
    for ent in doc.ents:
        entity_type = SPACY_ENTITY_MAP.get(ent.label_)
        if entity_type is None:
            continue
        if entity_type == 'PERSON' and not _looks_like_person(ent.text):
            continue
        found.append(_make_entity(
            source='NLP',
            entity_type=entity_type,
            text=ent.text,
            location=location,
            confidence=0.80,
            page=page,
            para_idx=para_idx,
        ))
    return found


def _deduplicate(entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Remove near-duplicate detections.
    Two entities are duplicates if they share the same text and location.
    When duplicates exist, keep the one with highest confidence.
    """
    seen: Dict[str, Dict[str, Any]] = {}
    for entity in entities:
        key = f"{entity['text'].lower()}|{entity['location']}"
        if key not in seen or entity['confidence'] > seen[key]['confidence']:
            seen[key] = entity
    return list(seen.values())


def detect_pii_in_pdf(pages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Run full detection pipeline on extracted PDF pages."""
    all_entities: List[Dict[str, Any]] = []
    import config
    presidio_enabled = getattr(config, 'PRESIDIO_ENABLED', True)

    for page_dict in pages:
        text = page_dict['text']
        page_num = page_dict['page']
        location = f"Page {page_num}"

        # Regex
        all_entities.extend(detect_with_regex(text, location, page=page_num))

        # NLP
        if presidio_enabled:
            all_entities.extend(detect_with_presidio(text, location, page=page_num))
        else:
            all_entities.extend(detect_with_spacy(text, location, page=page_num))

    return _deduplicate(all_entities)


def detect_pii_in_docx(segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Run full detection pipeline on extracted DOCX segments."""
    all_entities: List[Dict[str, Any]] = []
    import config
    presidio_enabled = getattr(config, 'PRESIDIO_ENABLED', True)

    for seg in segments:
        text = seg['text']
        location = seg['location']
        para_idx = seg['idx']

        # Regex
        all_entities.extend(detect_with_regex(text, location, para_idx=para_idx))

        # NLP
        if presidio_enabled:
            all_entities.extend(detect_with_presidio(text, location, para_idx=para_idx))
        else:
            all_entities.extend(detect_with_spacy(text, location, para_idx=para_idx))

    return _deduplicate(all_entities)
