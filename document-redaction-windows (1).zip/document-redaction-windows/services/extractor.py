"""
Text extraction from PDF and DOCX files.
Returns structured content with location metadata for downstream redaction.
"""

import logging
from io import BytesIO
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


def extract_pdf(source: bytes) -> List[Dict[str, Any]]:
    """
    Extract text from each page of a PDF.
    Returns a list of page dicts with text and block-level detail.
    """
    try:
        import fitz  # PyMuPDF
    except ImportError:
        raise RuntimeError("PyMuPDF (fitz) is required for PDF extraction. Run: pip install PyMuPDF")

    pages = []
    doc = fitz.open(stream=source, filetype="pdf")
    try:
        for page_num, page in enumerate(doc, start=1):
            text = page.get_text("text")
            # Get word-level bounding boxes for precise location tracking
            words = page.get_text("words")  # (x0, y0, x1, y1, word, block_no, line_no, word_no)
            blocks = page.get_text("blocks")  # (x0, y0, x1, y1, text, block_no, block_type)
            pages.append({
                'page': page_num,
                'text': text,
                'words': words,
                'blocks': blocks,
            })
    finally:
        doc.close()

    logger.info("Extracted %d pages from PDF", len(pages))
    return pages


def extract_docx(source: bytes) -> List[Dict[str, Any]]:
    """
    Extract text from a DOCX file with paragraph and table location metadata.
    Returns a list of segment dicts.
    """
    try:
        from docx import Document
    except ImportError:
        raise RuntimeError("python-docx is required for DOCX extraction. Run: pip install python-docx")

    doc = Document(BytesIO(source))
    segments = []

    # Main body paragraphs
    for idx, para in enumerate(doc.paragraphs):
        text = para.text
        if not text.strip():
            continue
        segments.append({
            'idx': idx,
            'text': text,
            'location': f'Paragraph {idx + 1}',
            'type': 'paragraph',
            'table_idx': None,
            'row_idx': None,
            'col_idx': None,
            'cell_para_idx': None,
        })

    # Tables
    for table_idx, table in enumerate(doc.tables):
        for row_idx, row in enumerate(table.rows):
            for col_idx, cell in enumerate(row.cells):
                for cell_para_idx, para in enumerate(cell.paragraphs):
                    text = para.text
                    if not text.strip():
                        continue
                    segments.append({
                        'idx': (table_idx, row_idx, col_idx, cell_para_idx),
                        'text': text,
                        'location': f'Table {table_idx + 1}, Row {row_idx + 1}, Col {col_idx + 1}',
                        'type': 'table',
                        'table_idx': table_idx,
                        'row_idx': row_idx,
                        'col_idx': col_idx,
                        'cell_para_idx': cell_para_idx,
                    })

    logger.info("Extracted %d segments from DOCX", len(segments))
    return segments


def get_full_text_pdf(pages: List[Dict[str, Any]]) -> str:
    """Concatenate all page text for NLP processing."""
    return "\n".join(p['text'] for p in pages)


def get_full_text_docx(segments: List[Dict[str, Any]]) -> str:
    """Concatenate all segment text for NLP processing."""
    return "\n".join(s['text'] for s in segments)


def find_text_in_pdf_pages(pages: List[Dict[str, Any]], text: str) -> List[Dict[str, Any]]:
    """
    Find all occurrences of `text` in PDF pages.
    Returns list of {page, context} dicts.
    """
    results = []
    text_lower = text.lower()
    for page_dict in pages:
        page_text = page_dict['text']
        lower_page = page_text.lower()
        start = 0
        while True:
            pos = lower_page.find(text_lower, start)
            if pos == -1:
                break
            ctx_start = max(0, pos - 100)
            ctx_end = min(len(page_text), pos + len(text) + 100)
            context = page_text[ctx_start:ctx_end]
            results.append({
                'page': page_dict['page'],
                'context': context,
                'char_offset': pos,
            })
            start = pos + 1
    return results


def find_text_in_docx_segments(segments: List[Dict[str, Any]], text: str) -> List[Dict[str, Any]]:
    """
    Find all occurrences of `text` across DOCX segments.
    Returns list of {location, context, segment_idx} dicts.
    """
    results = []
    text_lower = text.lower()
    for seg_idx, seg in enumerate(segments):
        seg_text = seg['text']
        lower_seg = seg_text.lower()
        start = 0
        while True:
            pos = lower_seg.find(text_lower, start)
            if pos == -1:
                break
            ctx_start = max(0, pos - 100)
            ctx_end = min(len(seg_text), pos + len(text) + 100)
            context = seg_text[ctx_start:ctx_end]
            results.append({
                'location': seg['location'],
                'context': context,
                'segment_idx': seg_idx,
                'char_offset': pos,
            })
            start = pos + 1
    return results
