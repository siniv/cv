"""
AI Redaction Assistant.

Converts a natural-language redaction instruction into a structured,
user-reviewable redaction plan. The LLM NEVER directly modifies the document —
it only proposes actions. The user must approve every action before redaction.

Pipeline:
  1. build_prompt()          — combine document text + user instruction
  2. analyze_document()      — call LLM, validate response
  3. normalize_actions()     — assign IDs, validate schema, deduplicate
  4. resolve_locations()     — find each original_text in the actual document
  5. actions_to_entities()   — convert approved actions → standard entity format
                               (consumed by existing redactor_pdf / redactor_docx)
"""

import re
import uuid
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Documents longer than this are chunked for the LLM prompt
MAX_DOCUMENT_CHARS = 12_000

# ---------------------------------------------------------------------------
# Prompt engineering
# ---------------------------------------------------------------------------

_SYSTEM = """\
You are a document redaction expert. Your task is to analyze a document and \
create a structured redaction plan based on the user's instructions.

MANDATORY RULES — violating any rule makes the response invalid:
1. Return ONLY valid JSON. Zero text, markdown, or explanation outside the JSON.
2. Never redact anything directly — only PROPOSE actions.
3. Every "original_text" value must be an EXACT substring of the document text \
   provided. Do not paraphrase, summarize, or rewrite it.
4. Do not hallucinate values that are not present in the document.
5. Set confidence based on how certain you are the item matches the instruction.
6. Provide a clear, concise reason for each action.
7. If the instruction says to use aliases (e.g. "Patient A"), set \
   recommended_mode to "custom" and provide the alias in replacement_text.

REQUIRED JSON SHAPE:
{
  "summary": "<one-sentence summary of the plan>",
  "actions": [
    {
      "action_id": "<unique string, e.g. a1>",
      "entity_type": "<PERSON|EMAIL|PHONE|ADDRESS|ORGANIZATION|DATE|CUSTOM|etc>",
      "original_text": "<exact substring from the document>",
      "recommended_mode": "<blackout|redacted|custom>",
      "replacement_text": "<alias or value if mode=custom, else empty string>",
      "reason": "<why this matches the user instruction>",
      "confidence": <float 0.0–1.0>
    }
  ]
}
"""

_USER_TEMPLATE = """\
USER INSTRUCTION:
{instruction}

DOCUMENT TEXT:
\"\"\"
{document_text}
\"\"\"

Identify every piece of text in the document that the instruction requires to \
be redacted. Return only the JSON redaction plan — nothing else.
"""


def build_prompt(document_text: str, instruction: str) -> str:
    """Assemble the full LLM prompt. Truncates very long documents."""
    text = document_text
    suffix = ""
    if len(text) > MAX_DOCUMENT_CHARS:
        suffix = (
            f"\n\n[Note: document was truncated to {MAX_DOCUMENT_CHARS} chars "
            f"({len(document_text) - MAX_DOCUMENT_CHARS} chars omitted from the end)]"
        )
        text = text[:MAX_DOCUMENT_CHARS]

    user_block = _USER_TEMPLATE.format(
        instruction=instruction.strip(),
        document_text=text + suffix,
    )
    return f"{_SYSTEM}\n\n{user_block}"


# ---------------------------------------------------------------------------
# LLM call + validation
# ---------------------------------------------------------------------------

def analyze_document(document_text: str, instruction: str) -> Dict[str, Any]:
    """
    Call the configured LLM and return a validated raw plan dict.
    Raises RuntimeError with a user-friendly message on any failure.
    """
    from services.llm_client import get_llm_client

    client = get_llm_client()
    prompt = build_prompt(document_text, instruction)

    logger.info("Sending document to LLM for AI redaction plan generation")
    result = client.generate_json(prompt)

    if not isinstance(result, dict):
        raise RuntimeError(
            f"LLM returned {type(result).__name__} instead of a JSON object. "
            "Try a different model or check your Ollama/Gemini setup."
        )
    if "actions" not in result:
        raise RuntimeError(
            "LLM response is missing the 'actions' field. "
            "The model may not have followed the JSON format. Try again."
        )
    if not isinstance(result["actions"], list):
        raise RuntimeError("LLM 'actions' field must be a list.")

    return result


# ---------------------------------------------------------------------------
# Normalise + deduplicate
# ---------------------------------------------------------------------------

def normalize_actions(raw_actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Validate and normalise LLM action objects.
    - Assigns sequential action IDs.
    - Validates recommended_mode.
    - Clamps confidence to [0, 1].
    - Deduplicates on (original_text_lower, entity_type).
    """
    seen: set = set()
    out: List[Dict[str, Any]] = []

    for i, raw in enumerate(raw_actions, start=1):
        if not isinstance(raw, dict):
            continue

        original_text = str(raw.get("original_text", "")).strip()
        if not original_text:
            continue

        entity_type = str(raw.get("entity_type", "CUSTOM")).upper().strip()
        dedup_key = (original_text.lower(), entity_type)
        if dedup_key in seen:
            continue
        seen.add(dedup_key)

        mode = str(raw.get("recommended_mode", "blackout")).lower()
        if mode not in ("blackout", "redacted", "custom"):
            mode = "blackout"

        try:
            confidence = float(raw.get("confidence", 0.75))
            confidence = max(0.0, min(1.0, confidence))
        except (TypeError, ValueError):
            confidence = 0.75

        out.append({
            "action_id": f"a{i}",
            "entity_type": entity_type,
            "original_text": original_text,
            "recommended_mode": mode,
            "replacement_text": str(raw.get("replacement_text", "")),
            "reason": str(raw.get("reason", "")),
            "confidence": round(confidence, 2),
            "status": "pending",
            "locations": [],
        })

    return out


# ---------------------------------------------------------------------------
# Location resolution
# ---------------------------------------------------------------------------

def resolve_locations(
    actions: List[Dict[str, Any]],
    pages_or_segments: List[Dict[str, Any]],
    file_type: str,
) -> List[Dict[str, Any]]:
    """
    For each action, find all exact occurrences of original_text in the document.

    Sets action['status']:
      'resolved'     — at least one occurrence found
      'needs_review' — no exact match found (user must confirm before redacting)

    Sets action['locations'] to a list of location dicts.
    """
    for action in actions:
        search_text = action["original_text"]
        if not search_text:
            action["status"] = "needs_review"
            continue

        pattern = re.compile(re.escape(search_text), re.IGNORECASE | re.DOTALL)
        locations: List[Dict[str, Any]] = []

        if file_type == "pdf":
            for page_dict in pages_or_segments:
                text = page_dict["text"]
                page_num = page_dict["page"]
                for m in pattern.finditer(text):
                    ctx_s = max(0, m.start() - 80)
                    ctx_e = min(len(text), m.end() + 80)
                    locations.append({
                        "page": page_num,
                        "location": f"Page {page_num}",
                        "context": text[ctx_s:ctx_e].replace("\n", " "),
                        "start_char": m.start(),
                        "end_char": m.end(),
                        "segment_idx": None,
                    })
        else:
            for seg in pages_or_segments:
                text = seg["text"]
                for m in pattern.finditer(text):
                    ctx_s = max(0, m.start() - 80)
                    ctx_e = min(len(text), m.end() + 80)
                    locations.append({
                        "page": None,
                        "location": seg["location"],
                        "context": text[ctx_s:ctx_e].replace("\n", " "),
                        "start_char": m.start(),
                        "end_char": m.end(),
                        "segment_idx": seg.get("idx"),
                    })

        action["locations"] = locations
        action["status"] = "resolved" if locations else "needs_review"

    return actions


# ---------------------------------------------------------------------------
# Convert approved actions → standard entity format
# ---------------------------------------------------------------------------

def smart_search(document_text: str, query: str) -> List[str]:
    """
    Use the configured LLM to find all specific named entities in the document
    that match the user's natural-language description.

    Returns a list of exact substrings (proper nouns / specific names) found in
    the document, which are then passed to the regular custom_matcher for
    location resolution and preview.
    """
    from services.llm_client import get_llm_client

    text = document_text[:MAX_DOCUMENT_CHARS]
    prompt = f"""\
You are a document analysis expert helping identify specific text to redact.

The user wants to redact: "{query}"

YOUR JOB: Find every specific proper noun or named item in the document that \
belongs to the requested category and return them as exact substrings.

CRITICAL — the difference between WRONG and CORRECT:
  User asks for "college names"
    WRONG:  ["college", "university"]          ← these are category words, not names
    CORRECT: ["St. Xavier's College", "IIT Bombay", "Harvard University"]  ← actual names

  User asks for "diagnosis or medical condition"
    WRONG:  ["diagnosis", "condition", "disease"]
    CORRECT: ["Type 2 Diabetes", "Hypertension", "Acute Myocardial Infarction"]

  User asks for "company names"
    WRONG:  ["company", "organization", "firm"]
    CORRECT: ["Grant Thornton", "Acme Corp", "Tata Consultancy Services"]

RULES:
1. Return ONLY specific proper nouns — never return the category word itself.
2. Every string must be copied CHARACTER-FOR-CHARACTER from the document below.
3. No duplicates. No explanation outside the JSON.
4. If nothing matches, return [].
5. Return ONLY a JSON array: ["name1", "name2", ...]

DOCUMENT TEXT:
\"\"\"
{text}
\"\"\"
"""
    client = get_llm_client()
    result = client.generate_json(prompt)
    if isinstance(result, list):
        return [str(s).strip() for s in result if str(s).strip()]
    return []


def actions_to_entities(approved_actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Convert approved AI plan actions into the internal entity format
    expected by redactor_pdf.py and redactor_docx.py.

    One entity is emitted per *location* of each action so the redactor
    can precisely target each occurrence.  If an action has no resolved
    locations the text is still included as a best-effort (the redactor
    will search the whole document for it).
    """
    entities: List[Dict[str, Any]] = []

    for action in approved_actions:
        mode = action.get("selected_mode", action["recommended_mode"])
        replacement = action.get("selected_replacement", action["replacement_text"])
        locations = action.get("locations") or [{}]

        for loc in locations:
            entities.append({
                "id": str(uuid.uuid4()),
                "source": "AI_ASSISTANT",
                "entity_type": action["entity_type"],
                "text": action["original_text"],
                "location": loc.get("location", "Unknown"),
                "page": loc.get("page"),
                "para_idx": loc.get("segment_idx"),
                "confidence": action["confidence"],
                "mode": mode,
                "replacement": replacement,
                "selected": True,
            })

    return entities
