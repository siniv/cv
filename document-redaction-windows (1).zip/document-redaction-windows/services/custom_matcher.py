"""
User-defined custom text matching.
Searches for exact phrases (case-insensitive) across the document
and returns matches with surrounding context for user confirmation.
"""

import re
import uuid
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

CONTEXT_CHARS = 120  # characters of context on each side of a match


def _build_match(match_text: str, page: Optional[int], location: str,
                 context: str, char_offset: int, segment_idx=None,
                 mode: str = 'blackout', replacement: str = '') -> Dict[str, Any]:
    return {
        'id': str(uuid.uuid4()),
        'text': match_text,
        'page': page,
        'location': location,
        'context': context,
        'char_offset': char_offset,
        'segment_idx': segment_idx,
        'mode': mode,
        'replacement': replacement,
        'selected': True,
    }


def search_in_pdf_pages(pages: List[Dict[str, Any]], search_text: str) -> List[Dict[str, Any]]:
    """
    Find all occurrences of `search_text` (case-insensitive) in PDF pages.
    Returns a list of match dicts with context previews.
    """
    if not search_text or not search_text.strip():
        return []

    results = []
    pattern = re.compile(re.escape(search_text.strip()), re.IGNORECASE | re.DOTALL)

    for page_dict in pages:
        page_text = page_dict['text']
        page_num = page_dict['page']
        location = f"Page {page_num}"

        for m in pattern.finditer(page_text):
            ctx_start = max(0, m.start() - CONTEXT_CHARS)
            ctx_end = min(len(page_text), m.end() + CONTEXT_CHARS)
            context = page_text[ctx_start:ctx_end].replace('\n', ' ')

            results.append(_build_match(
                match_text=m.group(),
                page=page_num,
                location=location,
                context=context,
                char_offset=m.start(),
            ))

    logger.info("Custom search '%s...' found %d match(es) in PDF",
                search_text[:30], len(results))
    return results


def search_in_docx_segments(segments: List[Dict[str, Any]],
                             search_text: str) -> List[Dict[str, Any]]:
    """
    Find all occurrences of `search_text` (case-insensitive) in DOCX segments.
    Returns a list of match dicts with context previews.
    """
    if not search_text or not search_text.strip():
        return []

    results = []
    pattern = re.compile(re.escape(search_text.strip()), re.IGNORECASE | re.DOTALL)

    for seg_idx, seg in enumerate(segments):
        seg_text = seg['text']
        location = seg['location']

        for m in pattern.finditer(seg_text):
            ctx_start = max(0, m.start() - CONTEXT_CHARS)
            ctx_end = min(len(seg_text), m.end() + CONTEXT_CHARS)
            context = seg_text[ctx_start:ctx_end].replace('\n', ' ')

            results.append(_build_match(
                match_text=m.group(),
                page=None,
                location=location,
                context=context,
                char_offset=m.start(),
                segment_idx=seg_idx,
            ))

    logger.info("Custom search '%s...' found %d match(es) in DOCX",
                search_text[:30], len(results))
    return results


def count_occurrences(pages_or_segments: List[Dict[str, Any]],
                      search_text: str, is_pdf: bool) -> int:
    """Quick count of occurrences without building full match objects."""
    if not search_text or not search_text.strip():
        return 0
    pattern = re.compile(re.escape(search_text.strip()), re.IGNORECASE | re.DOTALL)
    total = 0
    for item in pages_or_segments:
        text = item.get('text', '')
        total += len(pattern.findall(text))
    return total
