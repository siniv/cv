"""
True PDF redaction using PyMuPDF redaction annotations.

IMPORTANT: This performs PERMANENT, irreversible text removal.
Black rectangles painted over text are NOT used — PyMuPDF's apply_redactions()
permanently strips the underlying content stream so the original text cannot
be recovered by tools like pdf-parser, pdftotext, or copy-paste.
"""

import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


def _get_replacement_text(entity: Dict[str, Any]) -> str:
    """Return the overlay text for non-blackout modes."""
    mode = entity.get('mode', 'blackout')
    if mode == 'redacted':
        return '[REDACTED]'
    if mode == 'custom':
        replacement = entity.get('replacement', '').strip()
        return replacement if replacement else '[REDACTED]'
    return ''  # blackout - no overlay text


def redact_pdf(input_bytes: bytes,
               entities: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Apply redactions to a PDF and return the redacted bytes.

    Redaction strategy per mode:
    - blackout: solid black fill, no text, original content permanently removed
    - redacted: solid black fill, white '[REDACTED]' overlay text
    - custom: solid black fill, white custom text overlay

    Returns a dict with output_bytes and summary counts.
    """
    try:
        import fitz  # PyMuPDF
    except ImportError:
        raise RuntimeError("PyMuPDF is required. Run: pip install PyMuPDF")

    selected = [e for e in entities if e.get('selected', False)]
    if not selected:
        return {'output_bytes': input_bytes, 'redacted_count': 0, 'pages_affected': 0}

    doc = fitz.open(stream=input_bytes, filetype="pdf")
    total_redacted = 0
    pages_affected = set()

    for entity in selected:
        search_text = entity.get('text', '').strip()
        if not search_text:
            continue

        replacement_text = _get_replacement_text(entity)
        entity_page = entity.get('page')

        # Determine which pages to search
        if entity_page is not None:
            page_indices = [entity_page - 1]  # convert 1-based to 0-based
        else:
            page_indices = range(len(doc))

        for page_idx in page_indices:
            if page_idx < 0 or page_idx >= len(doc):
                continue
            page = doc[page_idx]

            # search_for returns a list of fitz.Rect instances
            rects = page.search_for(search_text, quads=False)
            if not rects:
                # Try case-insensitive search across all pages if page-specific missed
                if entity_page is not None:
                    rects = page.search_for(search_text.lower(), quads=False)
                    rects += page.search_for(search_text.upper(), quads=False)

            for rect in rects:
                if replacement_text:
                    # Non-blackout: overlay replacement text in white on black background
                    page.add_redact_annot(
                        rect,
                        text=replacement_text,
                        fontname="Helv",
                        fontsize=min(10, rect.height * 0.8),
                        align=fitz.TEXT_ALIGN_LEFT,
                        fill=(0, 0, 0),
                        text_color=(1, 1, 1),
                    )
                else:
                    # Blackout: solid black, no overlay text
                    page.add_redact_annot(rect, fill=(0, 0, 0))

                total_redacted += 1
                pages_affected.add(page_idx + 1)

            # Apply redactions for this page immediately
            # (must happen before adding more annotations to avoid conflicts)
            if rects:
                page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)

    output_bytes = doc.tobytes(
        garbage=4,      # remove all unreferenced objects
        clean=True,     # sanitise content streams
        deflate=True,   # compress streams
    )
    doc.close()

    logger.info(
        "PDF redaction complete: %d item(s) redacted across %d page(s)",
        total_redacted, len(pages_affected),
    )
    return {
        'output_bytes': output_bytes,
        'redacted_count': total_redacted,
        'pages_affected': len(pages_affected),
    }


def verify_redaction(output_bytes: bytes, original_texts: List[str]) -> List[str]:
    """
    Verification pass: check that none of the original texts appear in
    the redacted PDF. Returns any texts that were NOT successfully removed.
    Useful for QA and testing.
    """
    try:
        import fitz
    except ImportError:
        return []

    doc = fitz.open(stream=output_bytes, filetype="pdf")
    remaining = []

    for text in original_texts:
        found = False
        for page in doc:
            if page.search_for(text):
                found = True
                break
        if found:
            remaining.append(text)

    doc.close()
    return remaining
