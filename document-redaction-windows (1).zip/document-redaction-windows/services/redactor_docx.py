"""
DOCX redaction via python-docx.

Limitations vs PDF redaction:
  - DOCX is XML-based; text is split across 'runs' within a paragraph.
  - When a match spans multiple runs, this implementation merges the paragraph
    runs into a single run (preserving the first run's font), then replaces.
    Per-character formatting (bold/italic mid-word) is lost in that paragraph.
  - There is no cryptographic 'removal' equivalent to PDF redaction.
    The replacement is textual — the original string no longer exists in the file.
  - Headers, footers, and table cells are all searched and replaced.

Best practice: after redaction, review the output in Word to confirm appearance.
"""

import logging
import re
import copy
from io import BytesIO
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


def _get_replacement_text(entity: Dict[str, Any]) -> str:
    mode = entity.get('mode', 'blackout')
    if mode == 'blackout':
        return '█████'
    if mode == 'redacted':
        return '[REDACTED]'
    if mode == 'custom':
        replacement = entity.get('replacement', '').strip()
        return replacement if replacement else '[REDACTED]'
    return '[REDACTED]'


def _replace_in_paragraph(paragraph, search_text: str, replacement: str) -> bool:
    """
    Replace all occurrences of search_text in paragraph (case-insensitive).
    Handles text split across multiple runs by merging, replacing, then
    rebuilding with the first run's character formatting.
    Returns True if any replacement was made.
    """
    if not paragraph.runs:
        return False

    full_text = ''.join(run.text for run in paragraph.runs)
    pattern = re.compile(re.escape(search_text), re.IGNORECASE | re.DOTALL)

    if not pattern.search(full_text):
        return False

    new_text = pattern.sub(replacement, full_text)

    # Save first run's formatting reference
    first_run = paragraph.runs[0]

    # Write new text into first run, blank out all others
    first_run.text = new_text
    for run in paragraph.runs[1:]:
        run.text = ''

    return True


def _replace_in_paragraphs(paragraphs, search_text: str, replacement: str) -> int:
    """Replace in a list of Paragraph objects. Returns replacement count."""
    count = 0
    for para in paragraphs:
        if _replace_in_paragraph(para, search_text, replacement):
            count += 1
    return count


def redact_docx(input_bytes: bytes,
                entities: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Apply redactions to a DOCX file and return the redacted bytes.
    Searches paragraphs, tables, headers, and footers.
    """
    try:
        from docx import Document
    except ImportError:
        raise RuntimeError("python-docx is required. Run: pip install python-docx")

    selected = [e for e in entities if e.get('selected', False)]
    if not selected:
        return {'output_bytes': input_bytes, 'redacted_count': 0}

    doc = Document(BytesIO(input_bytes))
    total_replaced = 0

    for entity in selected:
        search_text = entity.get('text', '').strip()
        if not search_text:
            continue
        replacement = _get_replacement_text(entity)

        # Main body paragraphs
        total_replaced += _replace_in_paragraphs(doc.paragraphs, search_text, replacement)

        # Tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    total_replaced += _replace_in_paragraphs(
                        cell.paragraphs, search_text, replacement
                    )

        # Headers and footers for each section
        for section in doc.sections:
            # Header
            if section.header:
                total_replaced += _replace_in_paragraphs(
                    section.header.paragraphs, search_text, replacement
                )
                for table in section.header.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            total_replaced += _replace_in_paragraphs(
                                cell.paragraphs, search_text, replacement
                            )
            # Footer
            if section.footer:
                total_replaced += _replace_in_paragraphs(
                    section.footer.paragraphs, search_text, replacement
                )
                for table in section.footer.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            total_replaced += _replace_in_paragraphs(
                                cell.paragraphs, search_text, replacement
                            )

    buf = BytesIO()
    doc.save(buf)
    logger.info("DOCX redaction complete: %d paragraph(s) modified", total_replaced)
    return {'output_bytes': buf.getvalue(), 'redacted_count': total_replaced}
