"""
LLM-based PII/PHI detection for Standard mode (per-segment scanning).
Uses the unified LLMClient from llm_client.py — provider is determined by config.
External API usage is disabled by default (ALLOW_EXTERNAL_LLM=False).
"""

import uuid
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

DETECTION_PROMPT = """\
You are a PHI/PII detection expert. Analyze the text below and identify ALL \
personally identifiable information (PII) or protected health information (PHI).

Return ONLY a valid JSON array. Each element must have:
  - "entity_type": string (PERSON, DATE_OF_BIRTH, ADDRESS, PHONE, EMAIL, SSN,
    MEDICAL_CONDITION, MEDICATION, PROVIDER_NAME, PATIENT_NAME, ORGANIZATION,
    LOCATION, ACCOUNT_NUMBER, INSURANCE_ID, or any other PHI/PII type)
  - "text": the EXACT matched substring from the input text
  - "confidence": float 0.0–1.0
  - "reason": brief explanation

If no PHI/PII is found return an empty array: []
Return ONLY the JSON array. Zero text outside it.

TEXT:
\"\"\"
{text}
\"\"\"
"""

LLM_CHUNK_SIZE = 2000  # chars per chunk to respect context limits


def _is_llm_enabled() -> bool:
    try:
        import config
        return bool(getattr(config, 'LLM_ENABLED', False))
    except Exception:
        return False


def _call_llm(text: str) -> List[Dict[str, Any]]:
    """Send a text chunk to the configured LLM client and return entity list."""
    from services.llm_client import get_llm_client

    try:
        client = get_llm_client()
        result = client.generate_json(DETECTION_PROMPT.format(text=text))
        if isinstance(result, list):
            return result
        if isinstance(result, dict) and 'entities' in result:
            return result['entities']
        return []
    except RuntimeError as exc:
        logger.warning("LLM detection skipped: %s", exc)
        return []
    except Exception as exc:
        logger.warning("LLM detection error: %s", exc)
        return []


def _make_entity(entity_type: str, text: str, location: str,
                 confidence: float, reason: str,
                 page: Optional[int] = None, para_idx=None) -> Dict[str, Any]:
    return {
        'id': str(uuid.uuid4()),
        'source': 'LLM',
        'entity_type': entity_type.upper(),
        'text': text,
        'location': location,
        'page': page,
        'para_idx': para_idx,
        'confidence': round(min(max(float(confidence), 0.0), 1.0), 2),
        'mode': 'blackout',
        'replacement': '',
        'selected': True,
    }


def _process_results(raw: List[Dict[str, Any]], location: str,
                     page: Optional[int], para_idx) -> List[Dict[str, Any]]:
    entities = []
    if not isinstance(raw, list):
        return entities
    for item in raw:
        try:
            entity_type = str(item.get('entity_type', 'UNKNOWN')).upper()
            text = str(item.get('text', '')).strip()
            confidence = float(item.get('confidence', 0.75))
            reason = str(item.get('reason', ''))
            if not text:
                continue
            entities.append(_make_entity(entity_type, text, location,
                                         confidence, reason, page=page,
                                         para_idx=para_idx))
        except (TypeError, ValueError) as exc:
            logger.debug("Skipping malformed LLM entity: %s", exc)
    return entities


def detect_with_llm_pdf(pages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Run LLM detection on PDF pages. No-op if LLM is disabled."""
    if not _is_llm_enabled():
        return []

    all_entities: List[Dict[str, Any]] = []
    for page_dict in pages:
        text = page_dict['text']
        page_num = page_dict['page']
        location = f"Page {page_num}"
        for start in range(0, len(text), LLM_CHUNK_SIZE):
            chunk = text[start:start + LLM_CHUNK_SIZE]
            if not chunk.strip():
                continue
            raw = _call_llm(chunk)
            all_entities.extend(_process_results(raw, location, page_num, None))

    return all_entities


def detect_with_llm_docx(segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Run LLM detection on DOCX segments. No-op if LLM is disabled."""
    if not _is_llm_enabled():
        return []

    all_entities: List[Dict[str, Any]] = []
    for seg in segments:
        text = seg['text']
        location = seg['location']
        para_idx = seg['idx']
        for start in range(0, len(text), LLM_CHUNK_SIZE):
            chunk = text[start:start + LLM_CHUNK_SIZE]
            if not chunk.strip():
                continue
            raw = _call_llm(chunk)
            all_entities.extend(_process_results(raw, location, None, para_idx))

    return all_entities
