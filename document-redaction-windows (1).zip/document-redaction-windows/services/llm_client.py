"""
Unified LLM client interface with Ollama and Gemini (Vertex AI) implementations.

- Ollama is always allowed (local).
- Gemini requires ALLOW_EXTERNAL_LLM=true; raises a clear error otherwise.
- All providers expose the same generate_json(prompt) -> Any interface.
"""

import json
import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class LLMClient(ABC):
    """Common interface for all LLM providers."""

    @abstractmethod
    def generate_json(self, prompt: str) -> Any:
        """Send prompt, return parsed JSON (dict or list)."""
        ...

    def is_available(self) -> bool:
        return True


# ---------------------------------------------------------------------------
# JSON parsing helper
# ---------------------------------------------------------------------------

def _parse_json_safe(raw: str) -> Any:
    """Strip markdown fences and parse JSON; raises RuntimeError on failure."""
    raw = raw.strip()
    if raw.startswith("```"):
        lines = raw.splitlines()
        raw = "\n".join(l for l in lines if not l.startswith("```"))
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        preview = raw[:300].replace("\n", " ")
        raise RuntimeError(f"LLM returned invalid JSON: {exc} — raw: {preview}")


# ---------------------------------------------------------------------------
# Ollama implementation (local, always permitted)
# ---------------------------------------------------------------------------

class OllamaLLMClient(LLMClient):
    """Ollama local LLM via POST /api/generate."""

    def __init__(self, base_url: str, model: str, timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    def generate_json(self, prompt: str) -> Any:
        try:
            import requests
        except ImportError:
            raise RuntimeError("requests is required. Run: pip install requests")

        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.0, "num_predict": 4096},
        }
        try:
            resp = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            raw = resp.json().get("response", "").strip()
            return _parse_json_safe(raw)
        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Ollama is not reachable at {self.base_url}. "
                "Make sure 'ollama serve' is running."
            )
        except requests.exceptions.Timeout:
            raise RuntimeError(
                f"Ollama request timed out after {self.timeout}s. "
                "Try a smaller model or increase LLM_TIMEOUT_SECONDS."
            )
        except RuntimeError:
            raise
        except Exception as exc:
            raise RuntimeError(f"Ollama error: {exc}")

    def is_available(self) -> bool:
        try:
            import requests
            requests.get(f"{self.base_url}/api/tags", timeout=3)
            return True
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Gemini Vertex AI implementation (external; requires ALLOW_EXTERNAL_LLM=true)
# ---------------------------------------------------------------------------

class GeminiLLMClient(LLMClient):
    """Gemini 2.5 Pro via Google Vertex AI SDK.

    Prerequisites:
      pip install google-cloud-aiplatform
      gcloud auth application-default login
      Enable Vertex AI API in your GCP project.
    """

    def __init__(self, project_id: str, location: str, model: str):
        self.project_id = project_id
        self.location = location
        self.model = model
        self._init_sdk()

    def _init_sdk(self) -> None:
        try:
            import vertexai
            vertexai.init(project=self.project_id, location=self.location)
        except ImportError:
            raise RuntimeError(
                "google-cloud-aiplatform is required for Gemini. "
                "Run: pip install google-cloud-aiplatform"
            )

    def generate_json(self, prompt: str) -> Any:
        try:
            from vertexai.generative_models import GenerativeModel, GenerationConfig
        except ImportError:
            raise RuntimeError(
                "google-cloud-aiplatform is required for Gemini. "
                "Run: pip install google-cloud-aiplatform"
            )

        model = GenerativeModel(self.model)
        config = GenerationConfig(
            temperature=0.0,
            response_mime_type="application/json",
        )
        try:
            response = model.generate_content(prompt, generation_config=config)
            return _parse_json_safe(response.text)
        except RuntimeError:
            raise
        except Exception as exc:
            raise RuntimeError(f"Gemini Vertex AI error: {exc}")

    def is_available(self) -> bool:
        try:
            from vertexai.generative_models import GenerativeModel
            return True
        except ImportError:
            return False


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_llm_client() -> LLMClient:
    """
    Return the configured LLM client.

    Ollama: always permitted (local).
    Gemini: only if ALLOW_EXTERNAL_LLM=true.
    Raises RuntimeError with a clear message if misconfigured.
    """
    import config

    provider = getattr(config, "LLM_PROVIDER", "ollama").lower().strip()
    allow_external = getattr(config, "ALLOW_EXTERNAL_LLM", False)

    if provider == "gemini":
        if not allow_external:
            raise RuntimeError(
                "Gemini is disabled because ALLOW_EXTERNAL_LLM=false. "
                "Set ALLOW_EXTERNAL_LLM=true in your .env file to enable external LLM calls."
            )
        project_id = getattr(config, "GEMINI_PROJECT_ID", "").strip()
        if not project_id:
            raise RuntimeError(
                "GEMINI_PROJECT_ID is not set. Add it to your .env file."
            )
        location = getattr(config, "GEMINI_LOCATION", "us-central1")
        model = getattr(config, "GEMINI_MODEL", "gemini-2.5-pro")
        logger.info("Using Gemini Vertex AI client — model: %s, project: %s", model, project_id)
        return GeminiLLMClient(project_id, location, model)

    # Default: Ollama
    base_url = getattr(config, "OLLAMA_BASE_URL", "http://localhost:11434")
    model = getattr(config, "OLLAMA_MODEL", "llama3")
    timeout = int(getattr(config, "LLM_TIMEOUT_SECONDS", 60))
    logger.info("Using Ollama client — model: %s, url: %s", model, base_url)
    return OllamaLLMClient(base_url, model, timeout)
