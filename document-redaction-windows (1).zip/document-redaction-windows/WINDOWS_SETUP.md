# Document Redaction App — Windows Setup Guide

## Prerequisites

- Windows 10 or 11 (64-bit)
- Internet access for the initial setup

---

## Step 1 — Install Python 3.11

1. Go to https://www.python.org/downloads/
2. Download **Python 3.11.x** (click "Download Python 3.11.x")
3. Run the installer
4. **IMPORTANT**: On the first screen, check **"Add Python to PATH"** before clicking Install
5. Verify the install — open **Command Prompt** (Win + R → type `cmd` → Enter):

```
python --version
```

Should print `Python 3.11.x`.

---

## Step 2 — Copy the App Files

Copy the entire `document-redaction-windows` folder to your Windows machine.
Suggested location: `C:\Apps\document-redaction\`

You can use a USB drive, OneDrive, or any file transfer method.

---

## Step 3 — Open a Command Prompt in the App Folder

1. Open File Explorer and navigate to the app folder
2. Click the address bar, type `cmd`, press Enter
   — this opens Command Prompt already in that folder

Or open Command Prompt and navigate manually:

```
cd C:\Apps\document-redaction
```

---

## Step 4 — Create a Virtual Environment

```
python -m venv .venv
```

Activate it:

```
.venv\Scripts\activate
```

Your prompt should now start with `(.venv)`.

> If you see "running scripts is disabled", run this first in PowerShell (as Administrator):
> `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`
> Then re-run the activate command.

---

## Step 5 — Install Dependencies

```
pip install -r requirements.txt
```

This installs Flask, PyMuPDF, python-docx, Presidio, spaCy, and all other dependencies.
It will take 2–5 minutes on first run.

---

## Step 6 — Download the spaCy Language Model

```
python -m spacy download en_core_web_lg
```

This downloads the English NLP model (~560 MB) required for name detection.

---

## Step 7 — Configure the App

Copy the example config file and edit it:

```
copy .env.example .env
notepad .env
```

Minimum changes required:

```
SECRET_KEY=any-random-string-you-choose
```

For Ollama (local AI — recommended):

```
LLM_ENABLED=true
OLLAMA_MODEL=llama3.2:3b
```

For Gemini (cloud AI — higher quality):

```
LLM_PROVIDER=gemini
ALLOW_EXTERNAL_LLM=true
GEMINI_PROJECT_ID=your-gcp-project-id
```

Save and close Notepad.

---

## Step 8 — Install Ollama (optional, for AI features)

If you want to use the AI Redaction Assistant or Smart Search:

1. Download Ollama from https://ollama.com/download/windows
2. Run the installer
3. Open a **new** Command Prompt and pull a model:

```
ollama pull llama3.2:3b
```

Or for better quality:

```
ollama pull qwen3.5:4b
```

Ollama runs as a background service automatically after install.
Verify it's running by opening http://localhost:11434 in your browser — should show "Ollama is running".

---

## Step 9 — Run the App

Make sure your virtual environment is active (`.venv\Scripts\activate`), then:

```
python app.py
```

You should see:

```
 * Running on http://0.0.0.0:5000
```

Open your browser and go to: **http://localhost:5000**

---

## Step 10 — Running on a Different Port

If port 5000 is already in use:

```
set PORT=5001
python app.py
```

Then open **http://localhost:5001**

---

## Stopping the App

Press **Ctrl + C** in the Command Prompt window.

---

## Starting the App Next Time

You only need Steps 9–10 from now on:

```
cd C:\Apps\document-redaction
.venv\Scripts\activate
python app.py
```

---

## Troubleshooting

### `python` not recognised
- You did not check "Add Python to PATH" during install.
- Fix: re-run the Python installer, choose "Modify", and check the PATH option.
- Or use `py` instead of `python` everywhere.

### `pip install` fails with Microsoft Visual C++ error
Some packages need the C++ build tools. Install them from:
https://visualstudio.microsoft.com/visual-cpp-build-tools/
Select "Desktop development with C++" and install.

### PyMuPDF install fails
Try:
```
pip install --upgrade pip
pip install PyMuPDF
```

### spaCy model download fails
Try with the full URL:
```
python -m spacy download en_core_web_lg --user
```

### App starts but shows "LLM not configured"
- Set `LLM_ENABLED=true` in your `.env`
- Make sure Ollama is running: open http://localhost:11434

### Ollama 404 error
The model name in `.env` doesn't match an installed model.
Check installed models:
```
ollama list
```
Update `OLLAMA_MODEL` in `.env` to match exactly.

### Port 5000 already in use
```
set PORT=5001 && python app.py
```

---

## File Structure Reference

```
document-redaction\
├── app.py                  ← Flask application entry point
├── config.py               ← All configuration settings
├── requirements.txt        ← Python dependencies
├── .env                    ← Your local config (create from .env.example)
├── .env.example            ← Config template
├── services\
│   ├── pii_detector.py     ← PII/PHI detection (regex + NLP)
│   ├── extractor.py        ← PDF/DOCX text extraction
│   ├── redactor_pdf.py     ← True PDF redaction via PyMuPDF
│   ├── redactor_docx.py    ← DOCX text replacement
│   ├── custom_matcher.py   ← Custom text search
│   ├── llm_client.py       ← Ollama / Gemini LLM interface
│   ├── llm_detector.py     ← LLM-based PII detection
│   └── ai_redaction_assistant.py  ← AI plan generation + smart search
├── templates\              ← HTML pages
├── static\                 ← CSS
├── uploads\                ← Temporary uploads (auto-deleted after redaction)
└── outputs\                ← Temporary outputs (auto-deleted after download)
```

---

## Summary of All Commands (Quick Reference)

```
# First-time setup
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m spacy download en_core_web_lg
copy .env.example .env
notepad .env

# Every time you want to run the app
.venv\Scripts\activate
python app.py
```
