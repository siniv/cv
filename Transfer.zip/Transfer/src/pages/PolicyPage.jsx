import React from 'react'
import { useNavigate } from 'react-router-dom'
import { policyData } from '../data/dummyData'
import VoiceAssistant from '../components/VoiceAssistant'

/**
 * PolicyPage Component
 * Displays detailed health insurance policy information
 * Including coverage, benefits, exclusions, and documents
 */
const PolicyPage = () => {
  const navigate = useNavigate()

  const handleBack = () => {
    navigate('/dashboard')
  }

  const handleDownload = (docName) => {
    alert(`Downloading: ${docName}\n\nThis is a demo - no actual download will occur.`)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleBack}
              className="text-gray-600 hover:text-gray-900 p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Policy Details</h1>
              <p className="text-sm text-gray-500">{policyData.policyNumber}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-8 py-8">
        {/* Policy Overview */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8 mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Policy Overview</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-gray-500 mb-1">Policyholder</p>
              <p className="font-semibold text-gray-900">{policyData.policyholderName}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Policy Number</p>
              <p className="font-semibold text-gray-900 font-mono">{policyData.policyNumber}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Plan Name</p>
              <p className="font-semibold text-gray-900">{policyData.planName}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Sum Insured</p>
              <p className="font-semibold text-gray-900 text-lg text-blue-600">{policyData.sumInsured}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Premium Amount</p>
              <p className="font-semibold text-gray-900">{policyData.premium} /year</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Valid Until</p>
              <p className="font-semibold text-gray-900">{policyData.validUntil}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Issue Date</p>
              <p className="font-semibold text-gray-900">{policyData.issueDate}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Renewal Date</p>
              <p className="font-semibold text-gray-900">{policyData.renewalDate}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Status</p>
              <span className="inline-block bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                {policyData.status}
              </span>
            </div>
          </div>
        </div>

        {/* Family Members */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8 mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Family Members Covered</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {policyData.familyMembers.map((member, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <p className="font-semibold text-gray-900 mb-1">{member.name}</p>
                <p className="text-sm text-gray-600 mb-1">{member.relation}</p>
                <p className="text-sm text-gray-500">Age: {member.age} years</p>
                <p className="text-sm text-blue-600 font-medium mt-2">{member.sumInsured}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Coverage Details */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8 mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Coverage Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(policyData.coverage).map(([key, value]) => (
              <div key={key} className="flex items-start space-x-3">
                <div className="text-green-500 mt-1">✓</div>
                <div>
                  <p className="font-medium text-gray-900 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </p>
                  <p className="text-sm text-gray-600">{value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Benefits */}
          <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Benefits</h2>
            <ul className="space-y-3">
              {policyData.benefits.map((benefit, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <div className="text-blue-500 mt-1">●</div>
                  <p className="text-gray-700">{benefit}</p>
                </li>
              ))}
            </ul>
          </div>

          {/* Exclusions */}
          <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Exclusions</h2>
            <ul className="space-y-3">
              {policyData.exclusions.map((exclusion, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <div className="text-red-500 mt-1">✕</div>
                  <p className="text-gray-700">{exclusion}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Documents */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8 mt-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Policy Documents</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {policyData.documents.map((doc, index) => (
              <div
                key={index}
                className="flex items-center justify-between border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:bg-blue-50 transition"
              >
                <div className="flex items-center space-x-3">
                  <div className="text-3xl">📄</div>
                  <div>
                    <p className="font-medium text-gray-900">{doc.name}</p>
                    <p className="text-sm text-gray-500">{doc.type} • {doc.size}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDownload(doc.name)}
                  className="text-blue-600 hover:text-blue-700 font-medium text-sm px-4 py-2 rounded-lg hover:bg-blue-100 transition"
                >
                  Download
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4 mt-8">
          <button
            onClick={handleBack}
            className="bg-gray-200 hover:bg-gray-300 text-gray-900 font-semibold px-6 py-3 rounded-lg transition"
          >
            Back to Dashboard
          </button>
          <button
            onClick={() => handleDownload('Policy PDF')}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition"
          >
            Download Policy PDF
          </button>
          <button
            onClick={() => navigate('/health-card')}
            className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-lg transition"
          >
            View Health Card
          </button>
        </div>
      </main>

      {/* Voice Assistant */}
      <VoiceAssistant />
    </div>
  )
}

export default PolicyPage
