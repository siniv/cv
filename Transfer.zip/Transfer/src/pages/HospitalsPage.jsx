import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { hospitalsData } from '../data/dummyData'
import VoiceAssistant from '../components/VoiceAssistant'

/**
 * HospitalsPage Component
 * Displays list of cashless network hospitals with search
 */
const HospitalsPage = () => {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')

  const handleBack = () => {
    navigate('/dashboard')
  }

  // Filter hospitals based on search query
  const filteredHospitals = hospitalsData.filter((hospital) => {
    const query = searchQuery.toLowerCase()
    return (
      hospital.name.toLowerCase().includes(query) ||
      hospital.city.toLowerCase().includes(query) ||
      hospital.specialties.some(s => s.toLowerCase().includes(query))
    )
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleBack}
              className="text-gray-600 hover:text-gray-900 p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Cashless Network Hospitals</h1>
              <p className="text-sm text-gray-500">Find hospitals for cashless treatment</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-8 py-8">
        {/* Search Bar */}
        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 mb-8">
          <div className="flex items-center space-x-4">
            <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by hospital name, city, or specialty..."
              className="flex-1 outline-none text-gray-900 placeholder-gray-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4">
          <p className="text-gray-600">
            Found <span className="font-semibold text-gray-900">{filteredHospitals.length}</span> hospitals
            {searchQuery && ` matching "${searchQuery}"`}
          </p>
        </div>

        {/* Hospitals List */}
        <div className="space-y-4">
          {filteredHospitals.length === 0 ? (
            <div className="bg-white rounded-xl shadow-md border border-gray-200 p-12 text-center">
              <div className="text-6xl mb-4">🏥</div>
              <p className="text-gray-600 mb-2">No hospitals found</p>
              <p className="text-sm text-gray-500">Try adjusting your search criteria</p>
            </div>
          ) : (
            filteredHospitals.map((hospital) => (
              <div
                key={hospital.id}
                className="bg-white rounded-xl shadow-md border border-gray-200 p-6 hover:shadow-lg transition"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-xl font-bold text-gray-900">{hospital.name}</h3>
                      {hospital.cashless && (
                        <span className="bg-green-100 text-green-800 text-xs font-semibold px-2 py-1 rounded-full">
                          Cashless Available
                        </span>
                      )}
                    </div>
                    <p className="text-gray-600 mb-2">
                      <span className="text-lg">📍</span> {hospital.address}
                    </p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>📞 {hospital.phone}</span>
                      <span>📏 {hospital.distance}</span>
                      <span>⭐ {hospital.rating}/5</span>
                    </div>
                  </div>
                  <div className="text-5xl">🏥</div>
                </div>

                {/* Specialties */}
                <div className="pt-4 border-t border-gray-200">
                  <p className="text-sm text-gray-500 mb-2">Specialties:</p>
                  <div className="flex flex-wrap gap-2">
                    {hospital.specialties.map((specialty, index) => (
                      <span
                        key={index}
                        className="bg-blue-50 text-blue-700 text-sm px-3 py-1 rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 mt-4 pt-4 border-t border-gray-200">
                  <button className="text-blue-600 hover:text-blue-700 font-medium text-sm px-4 py-2 rounded-lg hover:bg-blue-50 transition">
                    Get Directions
                  </button>
                  <button className="text-blue-600 hover:text-blue-700 font-medium text-sm px-4 py-2 rounded-lg hover:bg-blue-50 transition">
                    Call Hospital
                  </button>
                  <button className="text-blue-600 hover:text-blue-700 font-medium text-sm px-4 py-2 rounded-lg hover:bg-blue-50 transition">
                    View Details
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Info Box */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mt-8">
          <h3 className="font-semibold text-blue-900 mb-2">How Cashless Treatment Works</h3>
          <ul className="space-y-2 text-sm text-blue-700">
            <li className="flex items-start space-x-2">
              <span>1.</span>
              <span>Visit any network hospital listed above</span>
            </li>
            <li className="flex items-start space-x-2">
              <span>2.</span>
              <span>Present your health card at the hospital admission desk</span>
            </li>
            <li className="flex items-start space-x-2">
              <span>3.</span>
              <span>Hospital will verify your policy and provide cashless treatment</span>
            </li>
            <li className="flex items-start space-x-2">
              <span>4.</span>
              <span>Settlement happens directly between hospital and insurer</span>
            </li>
          </ul>
        </div>
      </main>

      {/* Voice Assistant */}
      <VoiceAssistant />
    </div>
  )
}

export default HospitalsPage
