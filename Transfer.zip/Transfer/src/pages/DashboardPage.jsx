import React from 'react'
import { useNavigate } from 'react-router-dom'
import { userProfile, policyData, quickActions } from '../data/dummyData'
import VoiceAssistant from '../components/VoiceAssistant'

/**
 * DashboardPage Component
 * Main landing page after login
 * Shows policy summary and quick action cards
 */
const DashboardPage = () => {
  const navigate = useNavigate()

  const handleLogout = () => {
    navigate('/login')
  }

  const handleQuickAction = (route) => {
    navigate(route)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-xl">🏥</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  Demo Health Insurance
                </h1>
                <p className="text-xs text-gray-500">Your health, our priority</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="text-sm text-gray-600 hover:text-gray-900 font-medium px-4 py-2 rounded-lg hover:bg-gray-100 transition"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-8 py-8">
        {/* Greeting */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome! 👋
          </h2>
          <p className="text-gray-600">
            Your AI-powered health insurance assistant
          </p>
        </div>

        {/* Policy Summary Card */}
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl shadow-xl p-8 mb-8 text-white">
          <div className="flex justify-between items-start mb-6">
            <div>
              <p className="text-blue-100 text-sm mb-2">Active Policy</p>
              <h3 className="text-2xl font-bold mb-1">{policyData.planName}</h3>
              <p className="text-blue-100">{policyData.insurerName}</p>
            </div>
            <div className="bg-green-500 text-white text-xs font-semibold px-3 py-1 rounded-full">
              {policyData.status}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <p className="text-blue-200 text-sm mb-1">Policyholder</p>
              <p className="font-semibold">{policyData.policyholderName}</p>
            </div>
            <div>
              <p className="text-blue-200 text-sm mb-1">Policy Number</p>
              <p className="font-semibold font-mono">{policyData.policyNumber}</p>
            </div>
            <div>
              <p className="text-blue-200 text-sm mb-1">Sum Insured</p>
              <p className="font-semibold text-xl">{policyData.sumInsured}</p>
            </div>
            <div>
              <p className="text-blue-200 text-sm mb-1">Valid Until</p>
              <p className="font-semibold">{policyData.validUntil}</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h3 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quickActions.map((action) => (
              <button
                key={action.id}
                onClick={() => handleQuickAction(action.route)}
                className="bg-white rounded-xl shadow-md border border-gray-200 p-6 hover:shadow-xl hover:border-blue-300 transition-all duration-200 transform hover:-translate-y-1 text-left group"
              >
                <div className="flex items-start space-x-4">
                  <div className="text-4xl">{action.icon}</div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition">
                      {action.title}
                    </h4>
                    <p className="text-sm text-gray-500">
                      Click to access
                    </p>
                  </div>
                  <svg
                    className="w-5 h-5 text-gray-400 group-hover:text-blue-600 transition"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Voice Command Tip */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
          <div className="flex items-start space-x-3">
            <div className="text-2xl">🎤</div>
            <div>
              <h4 className="font-semibold text-blue-900 mb-1">
                Try Voice Commands
              </h4>
              <p className="text-sm text-blue-700 mb-2">
                Click the microphone button in the bottom-right corner and try saying:
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-white text-blue-700 text-xs font-medium px-3 py-1 rounded-full">
                  "Show my policy"
                </span>
                <span className="bg-white text-blue-700 text-xs font-medium px-3 py-1 rounded-full">
                  "Go to claims"
                </span>
                <span className="bg-white text-blue-700 text-xs font-medium px-3 py-1 rounded-full">
                  "Find hospitals"
                </span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Voice Assistant */}
      <VoiceAssistant />
    </div>
  )
}

export default DashboardPage
