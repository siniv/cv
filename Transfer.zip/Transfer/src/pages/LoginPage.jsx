import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

/**
 * LoginPage Component
 * Simple demo login screen - no real authentication
 * Redirects to dashboard after login
 */
const LoginPage = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const navigate = useNavigate()

  const handleLogin = (e) => {
    e.preventDefault()
    // No real authentication - just navigate to dashboard
    navigate('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-8">
      <div className="max-w-md w-full">
        {/* Demo Disclaimer */}
        <div className="text-center mb-8">
          <div className="inline-block bg-yellow-100 border border-yellow-300 rounded-lg px-4 py-2 mb-4">
            <p className="text-sm text-yellow-800 font-medium">
              🎭 Demo app. Not connected to any real insurer.
            </p>
          </div>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-8 text-center">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl">🏥</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">
              Health Insurance Portal
            </h1>
            <p className="text-blue-100 text-sm">
              Your health, our priority
            </p>
          </div>

          {/* Form */}
          <div className="p-8">
            <form onSubmit={handleLogin} className="space-y-6">
              {/* Email/Mobile Input */}
              <div>
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Mobile Number or Email
                </label>
                <input
                  type="text"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter mobile or email"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                />
              </div>

              {/* Password Input */}
              <div>
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                />
              </div>

              {/* Helper Text */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-700">
                  💡 Use demo credentials or click Login to continue
                </p>
              </div>

              {/* Login Button */}
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg"
              >
                Login
              </button>

              {/* Links */}
              <div className="flex justify-between text-sm">
                <a href="#" className="text-blue-600 hover:text-blue-700">
                  Forgot Password?
                </a>
                <a href="#" className="text-blue-600 hover:text-blue-700">
                  Register New Policy
                </a>
              </div>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-sm text-gray-500">
            This is a demonstration prototype with dummy data
          </p>
        </div>
      </div>
    </div>
  )
}

export default LoginPage
