import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useClaimsContext } from '../context/ClaimsContext'
import { hospitalsData } from '../data/dummyData'
import VoiceAssistant from '../components/VoiceAssistant'

/**
 * NewClaimPage Component
 * Form to create a new insurance claim
 * Supports voice commands for filling fields and submitting
 */
const NewClaimPage = () => {
  const navigate = useNavigate()
  const { addClaim } = useClaimsContext()

  const [formData, setFormData] = useState({
    hospital: '',
    ailment: '',
  })

  const [errors, setErrors] = useState({})

  // Listen for voice submit command
  useEffect(() => {
    const handleVoiceSubmit = () => {
      console.log('[NewClaim] Voice submit triggered')
      handleSubmit()
    }

    window.addEventListener('voiceSubmitClaim', handleVoiceSubmit)

    return () => {
      window.removeEventListener('voiceSubmitClaim', handleVoiceSubmit)
    }
  }, [formData]) // Include formData in deps so it uses latest values

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }))
    }
  }

  const validateForm = () => {
    const newErrors = {}

    if (!formData.hospital) {
      newErrors.hospital = 'Please select a hospital'
    }

    if (!formData.ailment || formData.ailment.trim().length < 3) {
      newErrors.ailment = 'Please enter the reason for claim (minimum 3 characters)'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e) => {
    if (e) e.preventDefault()

    if (!validateForm()) {
      return
    }

    // Create new claim
    const newClaim = addClaim({
      hospital: formData.hospital,
      ailment: formData.ailment,
      claimType: 'Cashless',
    })

    // Show success message
    alert(`Claim Created Successfully!\n\nClaim ID: ${newClaim.claimId}\nHospital: ${newClaim.hospital}\nReason: ${newClaim.ailment}\n\nStatus: Draft`)

    // Navigate to claims page
    navigate('/claims')
  }

  const handleCancel = () => {
    navigate('/claims')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleCancel}
              className="text-gray-600 hover:text-gray-900 p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Start New Claim</h1>
              <p className="text-sm text-gray-500">File a new insurance claim</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-8 py-8">
        {/* Form Card */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Claim Information</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Hospital Selection */}
            <div>
              <label htmlFor="hospital" className="block text-sm font-medium text-gray-700 mb-2">
                Hospital <span className="text-red-500">*</span>
              </label>
              <select
                id="hospital"
                value={formData.hospital}
                onChange={(e) => handleChange('hospital', e.target.value)}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition ${
                  errors.hospital ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Select a hospital</option>
                {hospitalsData.map((hospital) => (
                  <option key={hospital.id} value={hospital.name}>
                    {hospital.name} - {hospital.city}
                  </option>
                ))}
              </select>
              {errors.hospital && (
                <p className="mt-1 text-sm text-red-600">{errors.hospital}</p>
              )}
              <p className="mt-1 text-xs text-gray-500">
                💬 Voice: Say "set hospital to UPMC" or "select [hospital name]"
              </p>
            </div>

            {/* Ailment/Reason */}
            <div>
              <label htmlFor="ailment" className="block text-sm font-medium text-gray-700 mb-2">
                Reason for Claim <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="ailment"
                value={formData.ailment}
                onChange={(e) => handleChange('ailment', e.target.value)}
                placeholder="e.g., Appendicitis, Fever, Injury"
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition ${
                  errors.ailment ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {errors.ailment && (
                <p className="mt-1 text-sm text-red-600">{errors.ailment}</p>
              )}
              <p className="mt-1 text-xs text-gray-500">
                💬 Voice: Say "reason is appendicitis" or "set reason to [ailment]"
              </p>
            </div>

            {/* Info Box */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-900 mb-2 text-sm">📋 What happens next?</h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Your claim will be created in Draft status</li>
                <li>• You can add more details and documents later</li>
                <li>• Submit for approval when ready</li>
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4 pt-4">
              <button
                type="button"
                onClick={handleCancel}
                className="px-6 py-3 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition shadow-md hover:shadow-lg"
              >
                Create Claim
              </button>
            </div>

            {/* Voice Command Hint */}
            <div className="pt-4 border-t border-gray-200">
              <p className="text-sm text-gray-600 text-center">
                💬 You can also say: <strong>"Submit claim"</strong> or <strong>"Create claim"</strong>
              </p>
            </div>
          </form>
        </div>
      </main>

      {/* Voice Assistant */}
      <VoiceAssistant />
    </div>
  )
}

export default NewClaimPage
