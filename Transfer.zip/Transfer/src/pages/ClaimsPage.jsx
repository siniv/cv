import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useClaimsContext } from '../context/ClaimsContext'
import VoiceAssistant from '../components/VoiceAssistant'

/**
 * ClaimsPage Component
 * Displays list of insurance claims with status
 */
const ClaimsPage = () => {
  const navigate = useNavigate()
  const { claims } = useClaimsContext()

  const handleBack = () => {
    navigate('/dashboard')
  }

  const handleNewClaim = () => {
    navigate('/new-claim')
  }

  const getStatusBadge = (status, statusColor) => {
    const colors = {
      green: 'bg-green-100 text-green-800',
      yellow: 'bg-yellow-100 text-yellow-800',
      red: 'bg-red-100 text-red-800',
    }

    return (
      <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${colors[statusColor]}`}>
        {status}
      </span>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={handleBack}
                className="text-gray-600 hover:text-gray-900 p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">My Claims</h1>
                <p className="text-sm text-gray-500">View and track your insurance claims</p>
              </div>
            </div>
            <button
              onClick={handleNewClaim}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition shadow-md hover:shadow-lg"
            >
              + Start New Claim
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-8 py-8">
        {/* Claims Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">Total Claims</p>
              <span className="text-2xl">📊</span>
            </div>
            <p className="text-3xl font-bold text-gray-900">{claims.length}</p>
          </div>
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">Settled Claims</p>
              <span className="text-2xl">✅</span>
            </div>
            <p className="text-3xl font-bold text-green-600">
              {claims.filter(c => c.status === 'Settled').length}
            </p>
          </div>
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">Under Review</p>
              <span className="text-2xl">⏳</span>
            </div>
            <p className="text-3xl font-bold text-yellow-600">
              {claims.filter(c => c.status === 'Under Review').length}
            </p>
          </div>
        </div>

        {/* Claims List */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Claim History</h2>
          {claims.map((claim) => (
            <div
              key={claim.claimId}
              className="bg-white rounded-xl shadow-md border border-gray-200 p-6 hover:shadow-lg transition"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-bold text-gray-900">{claim.claimId}</h3>
                    {getStatusBadge(claim.status, claim.statusColor)}
                  </div>
                  <p className="text-gray-600 mb-1">
                    <span className="font-medium">Hospital:</span> {claim.hospital}
                  </p>
                  <p className="text-gray-600">
                    <span className="font-medium">Ailment:</span> {claim.ailment}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500 mb-1">Claim Amount</p>
                  <p className="text-2xl font-bold text-blue-600">{claim.claimAmount}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-gray-200">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Admission Date</p>
                  <p className="font-medium text-gray-900">{claim.dateOfAdmission}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Discharge Date</p>
                  <p className="font-medium text-gray-900">{claim.dateOfDischarge}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Claim Type</p>
                  <p className="font-medium text-gray-900">{claim.claimType}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Approved Amount</p>
                  <p className="font-medium text-gray-900">{claim.approvedAmount}</p>
                </div>
              </div>

              {claim.status === 'Under Review' && (
                <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                  <p className="text-sm text-yellow-800">
                    ⏳ Your claim is under review. Expected resolution within 7 business days.
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Help Section */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mt-8">
          <h3 className="font-semibold text-blue-900 mb-2">Need Help with a Claim?</h3>
          <p className="text-sm text-blue-700 mb-3">
            Contact our claims support team for assistance
          </p>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center space-x-2">
              <span className="text-blue-600">📞</span>
              <span className="text-sm text-blue-900">1800-123-4567 (Toll-free)</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-blue-600">📧</span>
              <span className="text-sm text-blue-900">claims@demoinsurance.com</span>
            </div>
          </div>
        </div>
      </main>

      {/* Voice Assistant */}
      <VoiceAssistant />
    </div>
  )
}

export default ClaimsPage
