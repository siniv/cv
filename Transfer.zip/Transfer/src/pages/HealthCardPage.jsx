import React from 'react'
import { useNavigate } from 'react-router-dom'
import { healthCardData } from '../data/dummyData'
import VoiceAssistant from '../components/VoiceAssistant'

/**
 * HealthCardPage Component
 * Displays digital health insurance card
 */
const HealthCardPage = () => {
  const navigate = useNavigate()

  const handleBack = () => {
    navigate('/dashboard')
  }

  const handleDownload = () => {
    alert('Downloading Health Card\n\nThis is a demo - no actual download will occur.')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleBack}
              className="text-gray-600 hover:text-gray-900 p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Digital Health Card</h1>
              <p className="text-sm text-gray-500">Your digital insurance card</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-8 py-8">
        {/* Health Card */}
        <div className="mb-8">
          <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 rounded-2xl shadow-2xl p-8 text-white relative overflow-hidden">
            {/* Decorative Pattern */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -mr-32 -mt-32"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-white opacity-5 rounded-full -ml-24 -mb-24"></div>

            {/* Card Content */}
            <div className="relative z-10">
              {/* Header */}
              <div className="flex justify-between items-start mb-8">
                <div>
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mb-3">
                    <span className="text-2xl">🏥</span>
                  </div>
                  <h2 className="text-2xl font-bold mb-1">{healthCardData.insurerName}</h2>
                  <p className="text-blue-200 text-sm">Health Insurance Card</p>
                </div>
                <div className="text-right">
                  <div className="bg-white bg-opacity-20 rounded-lg px-3 py-1">
                    <p className="text-xs text-blue-100">Valid Until</p>
                    <p className="font-semibold">{healthCardData.validUntil}</p>
                  </div>
                </div>
              </div>

              {/* Member Info */}
              <div className="mb-6">
                <p className="text-blue-200 text-sm mb-1">Member Name</p>
                <p className="text-2xl font-bold">{healthCardData.memberName}</p>
              </div>

              {/* Card Number */}
              <div className="mb-6">
                <p className="text-blue-200 text-sm mb-1">Card Number</p>
                <p className="text-xl font-mono tracking-wider">{healthCardData.cardNumber}</p>
              </div>

              {/* TPA Info */}
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <p className="text-blue-200 text-sm mb-1">TPA</p>
                  <p className="font-medium">{healthCardData.tpaName}</p>
                </div>
                <div>
                  <p className="text-blue-200 text-sm mb-1">TPA Helpline</p>
                  <p className="font-medium">{healthCardData.tpaHelpline}</p>
                </div>
              </div>

              {/* Emergency Contact */}
              <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center space-x-3">
                  <div className="text-3xl">🚨</div>
                  <div>
                    <p className="text-blue-200 text-sm">24x7 Emergency Helpline</p>
                    <p className="text-xl font-bold">{healthCardData.emergencyHelpline}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8 mb-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">How to Use Your Health Card</h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">1</span>
              </div>
              <div>
                <p className="font-medium text-gray-900 mb-1">For Cashless Hospitalization</p>
                <p className="text-gray-600 text-sm">
                  Show this card at any network hospital during admission for cashless treatment
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">2</span>
              </div>
              <div>
                <p className="font-medium text-gray-900 mb-1">For Reimbursement Claims</p>
                <p className="text-gray-600 text-sm">
                  Submit this card number along with your claim documents
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">3</span>
              </div>
              <div>
                <p className="font-medium text-gray-900 mb-1">Emergency Situations</p>
                <p className="text-gray-600 text-sm">
                  Call the emergency helpline for immediate assistance and guidance
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Important Notes */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 mb-6">
          <h3 className="font-semibold text-yellow-900 mb-3">Important Notes</h3>
          <ul className="space-y-2 text-sm text-yellow-800">
            <li className="flex items-start space-x-2">
              <span>•</span>
              <span>Always carry this card when visiting network hospitals</span>
            </li>
            <li className="flex items-start space-x-2">
              <span>•</span>
              <span>Inform the hospital about your insurance coverage during admission</span>
            </li>
            <li className="flex items-start space-x-2">
              <span>•</span>
              <span>Pre-authorization is required for planned hospitalizations</span>
            </li>
            <li className="flex items-start space-x-2">
              <span>•</span>
              <span>Keep a copy of this card on your mobile device</span>
            </li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4">
          <button
            onClick={handleBack}
            className="bg-gray-200 hover:bg-gray-300 text-gray-900 font-semibold px-6 py-3 rounded-lg transition"
          >
            Back to Dashboard
          </button>
          <button
            onClick={handleDownload}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition shadow-md hover:shadow-lg"
          >
            Download Card (PDF)
          </button>
          <button
            onClick={() => alert('Share Health Card\n\nThis is a demo - no actual sharing will occur.')}
            className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-lg transition shadow-md hover:shadow-lg"
          >
            Share via Email
          </button>
        </div>
      </main>

      {/* Voice Assistant */}
      <VoiceAssistant />
    </div>
  )
}

export default HealthCardPage
