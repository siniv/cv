import React, { useState, useEffect } from 'react'
import {
  getLLMConfig,
  setLLMProvider,
  testOllamaConnection,
  testGeminiConnection
} from '../utils/llmService'
import { getSettings, setSetting } from '../utils/settingsService'

/**
 * LLMSettings Component
 * Allows user to switch between LLM providers and configure safety settings
 */
const LLMSettings = ({ onClose }) => {
  const [config, setConfig] = useState(getLLMConfig())
  const [currentProvider, setCurrentProvider] = useState('simple')
  const [ollamaStatus, setOllamaStatus] = useState('unchecked')
  const [geminiStatus, setGeminiStatus] = useState('unchecked')
  const [settings, setSettings] = useState(getSettings())

  useEffect(() => {
    const cfg = getLLMConfig()
    setConfig(cfg)
    setCurrentProvider(cfg.provider)
    setSettings(getSettings())
  }, [])

  const handleToggleGuardrails = () => {
    const newValue = !settings.guardrailsEnabled
    setSetting('guardrailsEnabled', newValue)
    setSettings(prev => ({ ...prev, guardrailsEnabled: newValue }))
  }

  const handleToggleEditMode = () => {
    const newValue = !settings.editBeforeSubmit
    setSetting('editBeforeSubmit', newValue)
    setSettings(prev => ({ ...prev, editBeforeSubmit: newValue }))
  }

  const handleToggleWakeWord = () => {
    const newValue = !settings.wakeWordEnabled
    setSetting('wakeWordEnabled', newValue)
    setSettings(prev => ({ ...prev, wakeWordEnabled: newValue }))
  }

  const handleToggleSmartCorrection = () => {
    const newValue = !settings.smartCorrection
    setSetting('smartCorrection', newValue)
    setSettings(prev => ({ ...prev, smartCorrection: newValue }))
  }

  const handleProviderChange = (provider) => {
    setLLMProvider(provider)
    setCurrentProvider(provider)
  }

  const handleTestOllama = async () => {
    setOllamaStatus('testing')
    const isConnected = await testOllamaConnection()
    setOllamaStatus(isConnected ? 'connected' : 'failed')
  }

  const handleTestGemini = async () => {
    setGeminiStatus('testing')
    const isConnected = await testGeminiConnection()
    setGeminiStatus(isConnected ? 'connected' : 'failed')
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'connected':
        return <span className="text-green-600 text-sm">✓ Connected</span>
      case 'failed':
        return <span className="text-red-600 text-sm">✗ Failed</span>
      case 'testing':
        return <span className="text-yellow-600 text-sm">⏳ Testing...</span>
      default:
        return null
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-8 pb-4 flex-shrink-0">
          <h2 className="text-2xl font-bold text-gray-900">Voice Command Settings</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl"
          >
            ×
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto px-8 pb-4">
          {/* Description */}
          <p className="text-gray-600 mb-6">
            Choose how voice commands should be processed. You can use simple pattern matching or AI-powered intent recognition.
          </p>

        {/* Provider Options */}
        <div className="space-y-4">
          {/* Simple Pattern Matching */}
          <div
            className={`border-2 rounded-lg p-4 cursor-pointer transition ${
              currentProvider === 'simple'
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => handleProviderChange('simple')}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <input
                    type="radio"
                    checked={currentProvider === 'simple'}
                    onChange={() => handleProviderChange('simple')}
                    className="w-4 h-4"
                  />
                  <h3 className="font-semibold text-gray-900">Simple Pattern Matching</h3>
                  <span className="bg-green-100 text-green-800 text-xs font-semibold px-2 py-1 rounded">
                    Default
                  </span>
                </div>
                <p className="text-sm text-gray-600 ml-6">
                  Fast, offline, keyword-based matching. Works instantly without any setup.
                </p>
              </div>
            </div>
          </div>

          {/* Ollama */}
          <div
            className={`border-2 rounded-lg p-4 cursor-pointer transition ${
              currentProvider === 'ollama'
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => handleProviderChange('ollama')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <input
                    type="radio"
                    checked={currentProvider === 'ollama'}
                    onChange={() => handleProviderChange('ollama')}
                    className="w-4 h-4"
                  />
                  <h3 className="font-semibold text-gray-900">Ollama (Local AI)</h3>
                  <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2 py-1 rounded">
                    Private
                  </span>
                </div>
                <p className="text-sm text-gray-600 ml-6">
                  Runs locally on your machine. Better understanding of natural language commands.
                  Requires Ollama installed with llama3.2 or similar model.
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3 ml-6">
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  handleTestOllama()
                }}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Test Connection
              </button>
              {getStatusBadge(ollamaStatus)}
            </div>
          </div>

          {/* Gemini */}
          <div
            className={`border-2 rounded-lg p-4 cursor-pointer transition ${
              currentProvider === 'gemini'
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => handleProviderChange('gemini')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <input
                    type="radio"
                    checked={currentProvider === 'gemini'}
                    onChange={() => handleProviderChange('gemini')}
                    className="w-4 h-4"
                  />
                  <h3 className="font-semibold text-gray-900">Google Gemini</h3>
                  <span className="bg-purple-100 text-purple-800 text-xs font-semibold px-2 py-1 rounded">
                    Cloud
                  </span>
                </div>
                <p className="text-sm text-gray-600 ml-6">
                  Google's Gemini AI via Vertex AI for advanced natural language understanding.
                  Requires Google Cloud project ID and location (set in .env file).
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3 ml-6">
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  handleTestGemini()
                }}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Test Connection
              </button>
              {getStatusBadge(geminiStatus)}
            </div>
          </div>
        </div>

        {/* Safety Settings */}
        <div className="mt-8 pt-6 border-t border-gray-300">
          <h3 className="font-semibold text-gray-900 mb-4">Safety Settings</h3>

          {/* Guardrails Toggle */}
          <div className="flex items-start justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="font-medium text-gray-900">Content Guardrails</h4>
                <span className={`text-xs font-semibold px-2 py-1 rounded ${
                  settings.guardrailsEnabled
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {settings.guardrailsEnabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                Block medical advice, non-insurance questions, and out-of-scope requests
              </p>
              <ul className="mt-2 text-xs text-gray-500 space-y-1">
                <li>• Prevents medical diagnoses and medication recommendations</li>
                <li>• Blocks weather, news, and unrelated topics</li>
                <li>• Ensures responses stay insurance-focused</li>
              </ul>
            </div>
            <button
              onClick={handleToggleGuardrails}
              className={`ml-4 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                settings.guardrailsEnabled ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.guardrailsEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {!settings.guardrailsEnabled && (
            <div className="mt-3 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <p className="text-sm text-yellow-800">
                ⚠️ <strong>Warning:</strong> Guardrails are disabled. The assistant may answer questions outside the insurance domain.
              </p>
            </div>
          )}

          {/* Wake Word Toggle */}
          <div className="flex items-start justify-between p-4 bg-gray-50 rounded-lg mt-4">
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="font-medium text-gray-900">Wake Word: "Genie"</h4>
                <span className={`text-xs font-semibold px-2 py-1 rounded ${
                  settings.wakeWordEnabled
                    ? 'bg-purple-100 text-purple-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {settings.wakeWordEnabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                Require "Genie" wake word before processing commands
              </p>
              <ul className="mt-2 text-xs text-gray-500 space-y-1">
                <li>• Say "Genie, what's my policy number?"</li>
                <li>• Prevents accidental activations</li>
                <li>• More natural conversation style</li>
              </ul>
            </div>
            <button
              onClick={handleToggleWakeWord}
              className={`ml-4 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 ${
                settings.wakeWordEnabled ? 'bg-purple-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.wakeWordEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Edit Before Submit Toggle */}
          <div className="flex items-start justify-between p-4 bg-gray-50 rounded-lg mt-4">
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="font-medium text-gray-900">Edit Before Submit</h4>
                <span className={`text-xs font-semibold px-2 py-1 rounded ${
                  settings.editBeforeSubmit
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {settings.editBeforeSubmit ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                Review and edit voice transcriptions before they're processed
              </p>
              <ul className="mt-2 text-xs text-gray-500 space-y-1">
                <li>• Fix speech recognition errors</li>
                <li>• Confirm before action</li>
                <li>• More control, slightly slower</li>
              </ul>
            </div>
            <button
              onClick={handleToggleEditMode}
              className={`ml-4 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                settings.editBeforeSubmit ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.editBeforeSubmit ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Smart Correction Toggle */}
          <div className="flex items-start justify-between p-4 bg-gray-50 rounded-lg mt-4">
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="font-medium text-gray-900">Smart Correction</h4>
                <span className={`text-xs font-semibold px-2 py-1 rounded ${
                  settings.smartCorrection
                    ? 'bg-purple-100 text-purple-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {settings.smartCorrection ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                Use AI to correct unclear speech transcriptions based on context
              </p>
              <ul className="mt-2 text-xs text-gray-500 space-y-1">
                <li>• Fixes garbled or unclear voice input</li>
                <li>• Understands insurance terms and context</li>
                <li>• Shows what was heard vs. what was understood</li>
              </ul>
            </div>
            <button
              onClick={handleToggleSmartCorrection}
              className={`ml-4 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 ${
                settings.smartCorrection ? 'bg-purple-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.smartCorrection ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Setup Instructions */}
        <div className="mt-6 bg-gray-50 rounded-lg p-4">
          <h4 className="font-semibold text-gray-900 mb-2 text-sm">Setup Instructions:</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• <strong>Ollama:</strong> Install from ollama.ai and run: <code className="bg-gray-200 px-1 rounded">ollama run llama3.2</code></li>
            <li>• <strong>Gemini:</strong> Set up Google Cloud project, enable Vertex AI, add project ID & location to .env</li>
            <li>• <strong>Simple:</strong> No setup required - works out of the box</li>
          </ul>
        </div>

        </div>

        {/* Fixed Footer with Done Button */}
        <div className="border-t border-gray-200 p-6 flex justify-end flex-shrink-0">
          <button
            onClick={onClose}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  )
}

export default LLMSettings
