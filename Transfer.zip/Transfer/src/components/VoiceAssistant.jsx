import React, { useState, useEffect } from 'react'
import { useVoiceCommands } from '../hooks/useVoiceCommands'
import { voiceCommandHelp } from '../data/dummyData'
import { getSetting } from '../utils/settingsService'
import LLMSettings from './LLMSettings'

/**
 * VoiceAssistant Component
 * Provides voice command interface with visual feedback
 * Shows listening status, recognized commands, and help
 */
const VoiceAssistant = () => {
  const [showHelp, setShowHelp] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const {
    isListening,
    lastCommand,
    recognizedText,
    status,
    isSupported,
    error,
    conversation,
    isSpeaking,
    isMuted,
    pendingCommand,
    editableText,
    correctionInfo,
    toggleListening,
    toggleMute,
    stopSpeaking,
    clearConversation,
    confirmCommand,
    cancelCommand,
    updateEditableText,
  } = useVoiceCommands()

  const getStatusMessage = () => {
    const wakeWordEnabled = getSetting('wakeWordEnabled')

    if (isSpeaking) {
      return '🔊 Speaking answer...'
    }

    switch (status) {
      case 'listening':
        return wakeWordEnabled
          ? '🎤 Listening for "Genie"...'
          : '🎤 Always listening... speak anytime'
      case 'processing':
        return `Processing: "${recognizedText}"`
      case 'pending-edit':
        return 'Edit command below and confirm'
      case 'answering':
        return 'Finding answer...'
      case 'recognized':
        return `✓ Navigating...`
      case 'not-recognized':
        return `✗ Not recognized. Try again or say "help"`
      default:
        if (isListening) {
          return wakeWordEnabled
            ? '🎤 Listening for "Genie"...'
            : '🎤 Always listening... speak anytime'
        }
        return wakeWordEnabled
          ? 'Click mic and say "Genie"'
          : 'Click microphone to start'
    }
  }

  const getStatusColor = () => {
    if (isSpeaking) {
      return 'text-purple-600'
    }

    switch (status) {
      case 'listening':
        return 'text-blue-600'
      case 'processing':
      case 'answering':
        return 'text-yellow-600'
      case 'recognized':
        return 'text-green-600'
      case 'not-recognized':
        return 'text-red-600'
      default:
        return 'text-gray-600'
    }
  }

  if (!isSupported) {
    return (
      <div className="fixed bottom-6 right-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4 shadow-lg max-w-sm">
        <p className="text-sm text-yellow-800">
          Voice commands are not supported in this browser. Please use Chrome, Edge, or Safari.
        </p>
      </div>
    )
  }

  return (
    <>
      {/* LLM Settings Modal */}
      {showSettings && <LLMSettings onClose={() => setShowSettings(false)} />}

      <div className="fixed bottom-6 right-6 z-50">
        {/* Conversation History Panel */}
        {conversation.length > 0 && (
          <div className="mb-4 bg-white rounded-lg shadow-xl border border-gray-200 p-6 w-96 max-h-96 overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-900 text-lg">Conversation</h3>
              <button
                onClick={clearConversation}
                className="text-sm text-red-600 hover:text-red-700 font-medium"
              >
                Clear
              </button>
            </div>
            <div className="space-y-3">
              {conversation.map((entry, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg ${
                    entry.type === 'question'
                      ? 'bg-blue-50 border border-blue-200'
                      : 'bg-green-50 border border-green-200'
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    <span className="text-lg flex-shrink-0">
                      {entry.type === 'question' ? '❓' : '💬'}
                    </span>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">{entry.text}</p>
                      {entry.source && (
                        <p className="text-xs text-gray-500 mt-1">
                          {entry.source === 'rule-based' ? '⚡ Instant' : '🤖 AI'}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Voice Command Help Panel */}
        {showHelp && (
        <div className="mb-4 bg-white rounded-lg shadow-xl border border-gray-200 p-6 w-96">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-gray-900 text-lg">Voice Commands</h3>
            <button
              onClick={() => setShowHelp(false)}
              className="text-gray-400 hover:text-gray-600 text-xl"
            >
              ×
            </button>
          </div>
          <div className="space-y-3">
            {voiceCommandHelp.map((item, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0 w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3"></div>
                <div>
                  <p className="font-medium text-gray-900 text-sm">{item.command}</p>
                  <p className="text-gray-600 text-xs">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-xs text-gray-500 italic">
              Tip: Speak clearly and wait for the microphone to stop listening before expecting a response.
            </p>
          </div>
        </div>
      )}

        {/* Voice Assistant Control Card */}
        <div className="bg-white rounded-lg shadow-xl border border-gray-200 p-6 w-96">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <h3 className="font-semibold text-gray-900">Voice Assistant</h3>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setShowSettings(true)}
                className="text-gray-600 hover:text-gray-900 p-1"
                title="Settings"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </button>
              <button
                onClick={() => setShowHelp(!showHelp)}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                {showHelp ? 'Hide' : 'Show'} Help
              </button>
            </div>
          </div>

        {/* Microphone Button and Controls */}
        <div className="flex flex-col items-center mb-4">
          <button
            onClick={toggleListening}
            disabled={status === 'processing' || status === 'answering'}
            className={`
              w-20 h-20 rounded-full flex items-center justify-center
              transition-all duration-300 transform hover:scale-105
              ${
                isListening
                  ? 'bg-red-500 hover:bg-red-600 shadow-lg shadow-red-200 animate-pulse'
                  : 'bg-blue-500 hover:bg-blue-600 shadow-lg shadow-blue-200'
              }
              ${status === 'processing' || status === 'answering' ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            <svg
              className="w-10 h-10 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              {isListening ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"
                />
              )}
            </svg>
          </button>

          {/* TTS Controls */}
          <div className="flex items-center space-x-2 mt-3">
            <button
              onClick={toggleMute}
              className={`p-2 rounded-lg transition ${
                isMuted
                  ? 'bg-red-100 text-red-600 hover:bg-red-200'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isMuted ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                )}
              </svg>
            </button>

            {isSpeaking && (
              <button
                onClick={stopSpeaking}
                className="p-2 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 transition"
                title="Stop speaking"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* Status Message */}
        <div className="text-center mb-4">
          <p className={`text-sm font-medium ${getStatusColor()}`}>
            {getStatusMessage()}
          </p>
        </div>

        {/* Edit Command Interface */}
        {pendingCommand && status === 'pending-edit' && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-3">
            <p className="text-xs text-blue-600 font-medium mb-2">Edit your command:</p>
            <input
              type="text"
              value={editableText}
              onChange={(e) => updateEditableText(e.target.value)}
              className="w-full px-3 py-2 border border-blue-300 rounded-lg mb-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={confirmCommand}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition"
              >
                ✓ Confirm
              </button>
              <button
                onClick={cancelCommand}
                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 text-sm font-medium px-4 py-2 rounded-lg transition"
              >
                ✕ Cancel
              </button>
            </div>
          </div>
        )}

        {/* Recognized Text Display */}
        {recognizedText && status !== 'idle' && status !== 'pending-edit' && (
          <div className="bg-gray-50 rounded-lg p-3 mb-3">
            <p className="text-xs text-gray-500 mb-1">You said:</p>
            <p className="text-sm font-medium text-gray-900">"{recognizedText}"</p>
          </div>
        )}

        {/* Smart Correction Info */}
        {correctionInfo && status !== 'idle' && (
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 mb-3">
            <p className="text-xs text-purple-600 font-medium mb-1">🔮 Smart correction applied:</p>
            <p className="text-xs text-gray-600 mb-1">
              Heard: <span className="font-mono text-gray-800">"{correctionInfo.original}"</span>
            </p>
            <p className="text-xs text-purple-700">
              Understood: <span className="font-mono font-semibold">"{correctionInfo.corrected}"</span>
            </p>
          </div>
        )}

        {/* Last Successful Command */}
        {lastCommand && status === 'idle' && (
          <div className="bg-green-50 rounded-lg p-3">
            <p className="text-xs text-green-600 mb-1">Last command:</p>
            <p className="text-sm font-medium text-green-900">"{lastCommand}"</p>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 rounded-lg p-3 mt-3">
            <p className="text-xs text-red-600 mb-1">Error:</p>
            <p className="text-sm text-red-900">{error}</p>
          </div>
        )}

        {/* Quick Tips */}
        {!isListening && !recognizedText && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-xs text-gray-500 mb-2">Navigation:</p>
            <p className="text-xs text-gray-600 mb-2">
              "Show my policy" • "Go to claims"
            </p>
            <p className="text-xs text-gray-500 mb-2">Ask questions:</p>
            <p className="text-xs text-gray-600">
              "What's my policy number?" • "How many claims?"
            </p>
          </div>
        )}
        </div>
      </div>
    </>
  )
}

export default VoiceAssistant
