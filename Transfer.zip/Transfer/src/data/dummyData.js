// Dummy data for the health insurance app

export const userProfile = {
  name: 'Michael Anderson',
  email: 'demo@example.com',
  phone: '+1 (412) 555-0123',
}

export const policyData = {
  policyholderName: 'Michael Anderson',
  insurerName: 'Demo Health Insurance',
  policyNumber: 'DEMO-HI-2026-001',
  planName: 'Family Health Plus',
  sumInsured: '$100,000',
  sumInsuredValue: 100000,
  premium: '$1,850',
  premiumValue: 1850,
  validUntil: '31 Dec 2026',
  renewalDate: '01 Jan 2027',
  status: 'Active',
  issueDate: '01 Jan 2025',
  policyType: 'Individual + Family Floater',

  familyMembers: [
    { name: 'Michael Anderson', relation: 'Self', age: 35, sumInsured: '$100,000' },
    { name: 'Sarah Anderson', relation: 'Spouse', age: 32, sumInsured: '$100,000' },
    { name: 'Ethan Anderson', relation: 'Son', age: 5, sumInsured: '$100,000' },
  ],

  coverage: {
    roomRentLimit: '$500 per day',
    coPay: '10% for senior citizens',
    waitingPeriod: '30 days for diseases, 2 years for pre-existing',
    icuCoverage: '$1,000 per day',
    maternityBenefit: 'Covered after 9 months',
    ambulanceCover: '$200 per hospitalization',
  },

  benefits: [
    'Cashless hospitalization at 10,000+ network hospitals',
    'Pre and post hospitalization (60 days / 90 days)',
    'Daycare procedures covered',
    'Annual health check-up',
    'No claim bonus - 10% increase every claim-free year',
    'AYUSH treatment covered',
    'COVID-19 treatment covered',
    'Organ donor expenses covered',
  ],

  exclusions: [
    'Cosmetic or plastic surgery',
    'Dental treatment (unless due to accident)',
    'Congenital diseases',
    'Self-inflicted injuries',
    'War or nuclear contamination',
    'Treatment outside USA',
  ],

  documents: [
    { name: 'Policy Document', type: 'PDF', size: '2.5 MB' },
    { name: 'Health Card', type: 'PDF', size: '500 KB' },
    { name: 'Claim Form', type: 'PDF', size: '1.2 MB' },
    { name: 'Network Hospital List', type: 'PDF', size: '5.8 MB' },
  ],
}

export const claimsData = [
  {
    claimId: 'CLM-2026-0245',
    hospital: 'UPMC Shadyside Hospital, Pittsburgh',
    dateOfAdmission: '15 Apr 2026',
    dateOfDischarge: '18 Apr 2026',
    claimAmount: '$4,500',
    claimAmountValue: 4500,
    approvedAmount: '$4,500',
    status: 'Settled',
    statusColor: 'green',
    claimType: 'Cashless',
    ailment: 'Viral Fever',
  },
  {
    claimId: 'CLM-2026-0189',
    hospital: 'Allegheny General Hospital, Pittsburgh',
    dateOfAdmission: '10 Mar 2026',
    dateOfDischarge: '12 Mar 2026',
    claimAmount: '$2,850',
    claimAmountValue: 2850,
    approvedAmount: '$2,500',
    status: 'Settled',
    statusColor: 'green',
    claimType: 'Reimbursement',
    ailment: 'Gastroenteritis',
  },
  {
    claimId: 'CLM-2026-0512',
    hospital: 'UPMC Presbyterian Hospital, Pittsburgh',
    dateOfAdmission: '20 May 2026',
    dateOfDischarge: '22 May 2026',
    claimAmount: '$6,200',
    claimAmountValue: 6200,
    approvedAmount: 'Pending',
    status: 'Under Review',
    statusColor: 'yellow',
    claimType: 'Cashless',
    ailment: 'Appendicitis',
  },
]

export const hospitalsData = [
  {
    id: 1,
    name: 'UPMC Presbyterian Hospital',
    city: 'Pittsburgh',
    address: '200 Lothrop Street, Oakland, Pittsburgh, PA 15213',
    distance: '2.5 miles',
    phone: '(412) 647-2345',
    cashless: true,
    specialties: ['Cardiology', 'Neurology', 'Transplant Services'],
    rating: 4.6,
  },
  {
    id: 2,
    name: 'Allegheny General Hospital',
    city: 'Pittsburgh',
    address: '320 East North Avenue, Pittsburgh, PA 15212',
    distance: '3.2 miles',
    phone: '(412) 359-3131',
    cashless: true,
    specialties: ['Oncology', 'Cardiology', 'Emergency Medicine'],
    rating: 4.5,
  },
  {
    id: 3,
    name: 'UPMC Shadyside Hospital',
    city: 'Pittsburgh',
    address: '5230 Centre Avenue, Shadyside, Pittsburgh, PA 15232',
    distance: '1.8 miles',
    phone: '(412) 623-2121',
    cashless: true,
    specialties: ['Orthopedics', 'Women\'s Health', 'Surgery'],
    rating: 4.7,
  },
  {
    id: 4,
    name: 'West Penn Hospital',
    city: 'Pittsburgh',
    address: '4800 Friendship Avenue, Pittsburgh, PA 15224',
    distance: '4.1 miles',
    phone: '(412) 578-5000',
    cashless: true,
    specialties: ['Trauma Care', 'Neurosciences', 'Rehabilitation'],
    rating: 4.3,
  },
  {
    id: 5,
    name: "UPMC Children's Hospital",
    city: 'Pittsburgh',
    address: '4401 Penn Avenue, Pittsburgh, PA 15224',
    distance: '2.9 miles',
    phone: '(412) 692-5325',
    cashless: true,
    specialties: ['Pediatrics', 'Neonatology', 'Pediatric Surgery'],
    rating: 4.8,
  },
  {
    id: 6,
    name: 'UPMC Mercy Hospital',
    city: 'Pittsburgh',
    address: '1400 Locust Street, Uptown, Pittsburgh, PA 15219',
    distance: '1.5 miles',
    phone: '(412) 232-8111',
    cashless: true,
    specialties: ['Cardiology', 'Diabetes Care', 'Sports Medicine'],
    rating: 4.4,
  },
  {
    id: 7,
    name: 'UPMC Magee-Womens Hospital',
    city: 'Pittsburgh',
    address: '300 Halket Street, Oakland, Pittsburgh, PA 15213',
    distance: '2.3 miles',
    phone: '(412) 641-1000',
    cashless: true,
    specialties: ['Obstetrics', 'Gynecology', 'Reproductive Medicine'],
    rating: 4.6,
  },
  {
    id: 8,
    name: 'St. Clair Hospital',
    city: 'Pittsburgh',
    address: '1000 Bower Hill Road, Mt. Lebanon, Pittsburgh, PA 15243',
    distance: '6.7 miles',
    phone: '(412) 942-4000',
    cashless: true,
    specialties: ['Cardiac Care', 'Orthopedics', 'General Surgery'],
    rating: 4.5,
  },
]

export const healthCardData = {
  cardNumber: policyData.policyNumber,
  memberName: userProfile.name,
  validUntil: policyData.validUntil,
  insurerName: policyData.insurerName,
  emergencyHelpline: '1-800-555-1234',
  tpaName: 'Demo TPA Services',
  tpaHelpline: '1-800-555-5678',
}

export const quickActions = [
  {
    id: 'policy',
    title: 'View Policy Details',
    icon: '📄',
    route: '/policy',
    voiceCommands: ['show my policy', 'open policy details', 'view policy', 'policy details'],
  },
  {
    id: 'claims',
    title: 'Claims',
    icon: '💰',
    route: '/claims',
    voiceCommands: ['show claims', 'go to claims', 'open claims', 'view claims'],
  },
  {
    id: 'hospitals',
    title: 'Cashless Hospitals',
    icon: '🏥',
    route: '/hospitals',
    voiceCommands: ['find hospitals', 'show hospitals', 'open hospitals', 'cashless hospitals'],
  },
  {
    id: 'health-card',
    title: 'Download Health Card',
    icon: '💳',
    route: '/health-card',
    voiceCommands: ['show health card', 'download health card', 'open health card', 'view health card'],
  },
  {
    id: 'wellness',
    title: 'Wellness Benefits',
    icon: '🧘',
    route: '/wellness',
    voiceCommands: ['wellness benefits', 'show wellness', 'health tips'],
  },
]

// Voice command mappings for navigation
export const voiceCommandMap = {
  // Dashboard
  'go to dashboard': '/dashboard',
  'show dashboard': '/dashboard',
  'home': '/dashboard',
  'go home': '/dashboard',
  'main page': '/dashboard',

  // Policy
  'show my policy': '/policy',
  'open policy details': '/policy',
  'view policy': '/policy',
  'policy details': '/policy',
  'show policy': '/policy',
  'go to policy': '/policy',

  // Claims
  'show claims': '/claims',
  'go to claims': '/claims',
  'open claims': '/claims',
  'view claims': '/claims',
  'my claims': '/claims',

  // Hospitals
  'find hospitals': '/hospitals',
  'show hospitals': '/hospitals',
  'open hospitals': '/hospitals',
  'cashless hospitals': '/hospitals',
  'network hospitals': '/hospitals',
  'go to hospitals': '/hospitals',

  // Health Card
  'show health card': '/health-card',
  'download health card': '/health-card',
  'open health card': '/health-card',
  'view health card': '/health-card',
  'health card': '/health-card',
  'go to health card': '/health-card',

  // Navigation
  'go back': 'back',
  'back': 'back',
  'previous page': 'back',

  // Logout
  'logout': '/login',
  'log out': '/login',
  'sign out': '/login',
  'exit': '/login',
}

export const voiceCommandHelp = [
  { command: '"Go to dashboard"', description: 'Return to main page' },
  { command: '"Show my policy"', description: 'View policy details' },
  { command: '"Go to claims"', description: 'View your claims' },
  { command: '"Find hospitals"', description: 'Search cashless hospitals' },
  { command: '"Show health card"', description: 'View digital health card' },
  { command: '"Go back"', description: 'Navigate to previous page' },
  { command: '"Logout"', description: 'Sign out of app' },
]
