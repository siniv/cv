import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { recognizeVoiceIntent } from '../utils/llmService'
import { classifyIntent, answerQuestion, correctTranscription } from '../utils/qaService'
import { ttsService } from '../utils/textToSpeech'
import { getSetting } from '../utils/settingsService'

/**
 * Custom hook for voice command recognition, navigation, and Q&A
 * Uses the Web Speech API (SpeechRecognition) to listen for voice commands
 * LLM (Ollama or Gemini) to understand intent
 * Hybrid Q&A (rule-based + LLM) to answer questions
 * Text-to-Speech to speak responses
 *
 * @returns {Object} Voice command state and controls
 */
export const useVoiceCommands = () => {
  const [isListening, setIsListening] = useState(false)
  const [lastCommand, setLastCommand] = useState('')
  const [recognizedText, setRecognizedText] = useState('')
  const [status, setStatus] = useState('idle') // idle, listening, processing, recognized, not-recognized, answering
  const [isSupported, setIsSupported] = useState(false)
  const [error, setError] = useState(null)
  const [conversation, setConversation] = useState([]) // Q&A conversation history
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [pendingCommand, setPendingCommand] = useState(null) // For edit mode
  const [editableText, setEditableText] = useState('')
  const [correctionInfo, setCorrectionInfo] = useState(null) // For showing corrections

  const recognitionRef = useRef(null)
  const navigate = useNavigate()

  // Check if Web Speech API is supported
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

    if (SpeechRecognition) {
      setIsSupported(true)

      // Initialize speech recognition
      const recognition = new SpeechRecognition()
      recognition.continuous = true // Keep listening until manually stopped
      recognition.interimResults = false // Only final results
      recognition.lang = 'en-US' // US English
      recognition.maxAlternatives = 1

      // Event: When speech is recognized
      recognition.onresult = async (event) => {
        let transcript = event.results[event.results.length - 1][0].transcript.trim()
        setRecognizedText(transcript)

        // Check if wake word is enabled
        const wakeWordEnabled = getSetting('wakeWordEnabled')

        if (wakeWordEnabled) {
          const lowerTranscript = transcript.toLowerCase()

          // Check if transcript starts with "genie" or "hey genie" or "ok genie"
          const wakeWords = ['genie', 'hey genie', 'ok genie', 'hi genie']
          let hasWakeWord = false
          let commandText = transcript

          for (const wakeWord of wakeWords) {
            if (lowerTranscript.startsWith(wakeWord)) {
              hasWakeWord = true
              // Extract command after wake word
              commandText = transcript.substring(wakeWord.length).trim()
              // Remove common separators like comma
              if (commandText.startsWith(',')) {
                commandText = commandText.substring(1).trim()
              }
              break
            }
          }

          if (!hasWakeWord) {
            console.log('[Voice] No wake word detected, ignoring:', transcript)
            setStatus('idle')
            return // Ignore commands without wake word
          }

          if (!commandText) {
            console.log('[Voice] Wake word detected but no command')
            setStatus('idle')
            return
          }

          console.log('[Voice] Wake word detected! Command:', commandText)
          transcript = commandText // Use the extracted command
        }

        // Apply smart correction if enabled
        const smartCorrectionEnabled = getSetting('smartCorrection')
        if (smartCorrectionEnabled) {
          setStatus('processing')
          try {
            const correctionResult = await correctTranscription(transcript)
            if (correctionResult.wasCorrected) {
              console.log('[Voice] Corrected:', correctionResult.original, '→', correctionResult.corrected)
              setCorrectionInfo({
                original: correctionResult.original,
                corrected: correctionResult.corrected,
              })
              transcript = correctionResult.corrected
            } else {
              setCorrectionInfo(null)
            }
          } catch (err) {
            console.error('[Voice] Correction failed:', err)
            setCorrectionInfo(null)
            // Continue with original transcript
          }
        } else {
          setCorrectionInfo(null)
        }

        // Check if edit mode is enabled
        const editBeforeSubmit = getSetting('editBeforeSubmit')

        if (editBeforeSubmit) {
          // Pause for editing
          setEditableText(transcript)
          setPendingCommand(transcript)
          setStatus('pending-edit')
          return // Don't process yet
        }

        setStatus('processing')

        // Classify if this is navigation, Q&A, or action
        const intent = classifyIntent(transcript)
        console.log('[Voice] Intent:', intent, 'for:', transcript)

        if (intent.type === 'action') {
          // Action flow
          setLastCommand(transcript)
          setStatus('recognized')

          if (intent.route) {
            // Navigate to action page (e.g., new claim form)
            setTimeout(() => {
              navigate(intent.route)
              setStatus('idle')
            }, 800)
          } else if (intent.action === 'submitClaim') {
            // Trigger submit action on current page
            // This will be handled by the form component listening to window events
            window.dispatchEvent(new CustomEvent('voiceSubmitClaim'))
            setStatus('idle')
          }
        } else if (intent.type === 'navigation') {
          // Navigation flow
          const route = await recognizeVoiceIntent(transcript)

          if (route && route !== 'unknown') {
            setLastCommand(transcript)
            setStatus('recognized')

            // Navigate after a short delay
            setTimeout(() => {
              if (route === 'back') {
                navigate(-1)
              } else {
                navigate(route)
              }
              setStatus('idle')
              // Don't stop listening - continuous mode
            }, 800)
          } else {
            setStatus('not-recognized')
            setTimeout(() => {
              setStatus('idle')
              // Don't stop listening - continuous mode
            }, 2000)
          }
        } else {
          // Q&A flow
          setStatus('answering')

          // Add question to conversation
          const questionEntry = {
            type: 'question',
            text: transcript,
            timestamp: new Date().toISOString(),
          }
          setConversation(prev => [...prev, questionEntry])

          try {
            // Get answer with timeout
            const timeoutPromise = new Promise((_, reject) =>
              setTimeout(() => reject(new Error('Timeout')), 30000) // 30 second timeout
            )

            const result = await Promise.race([
              answerQuestion(transcript),
              timeoutPromise
            ])

            // Add answer to conversation
            const answerEntry = {
              type: 'answer',
              text: result.answer,
              source: result.source,
              timestamp: new Date().toISOString(),
            }
            setConversation(prev => [...prev, answerEntry])

            // Speak the answer
            setIsSpeaking(true)
            try {
              await ttsService.speak(result.answer)
            } catch (err) {
              console.error('[Voice] TTS error:', err)
            }
            setIsSpeaking(false)

          } catch (err) {
            console.error('[Voice] Q&A error:', err)

            // Add error answer to conversation
            const errorEntry = {
              type: 'answer',
              text: err.message === 'Timeout'
                ? 'Request timed out. Please try again.'
                : 'I encountered an error processing your question. Please try again.',
              source: 'error',
              timestamp: new Date().toISOString(),
            }
            setConversation(prev => [...prev, errorEntry])

            // Speak error message
            setIsSpeaking(true)
            try {
              await ttsService.speak(errorEntry.text)
            } catch (ttsErr) {
              console.error('[Voice] TTS error:', ttsErr)
            }
            setIsSpeaking(false)
          }

          setStatus('idle')
          // Don't stop listening - continuous mode
        }
      }

      // Event: When speech recognition starts
      recognition.onstart = () => {
        setIsListening(true)
        setStatus('listening')
        setError(null)
      }

      // Event: When speech recognition ends
      recognition.onend = () => {
        // In continuous mode, auto-restart if still supposed to be listening
        // (unless user manually stopped it)
        if (isListening && !recognitionRef.current.manualStop) {
          console.log('[Voice] Recognition ended, auto-restarting...')
          try {
            recognitionRef.current.start()
          } catch (err) {
            console.log('[Voice] Auto-restart failed, setting to idle')
            setIsListening(false)
            setStatus('idle')
          }
        } else {
          setIsListening(false)
          if (status === 'listening') {
            setStatus('idle')
          }
        }
      }

      // Event: When an error occurs
      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error)
        setError(event.error)
        setStatus('idle')
        setIsListening(false)
      }

      recognitionRef.current = recognition
    } else {
      setIsSupported(false)
      console.warn('Web Speech API is not supported in this browser')
    }

    // Cleanup
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort()
      }
    }
  }, [navigate, status])

  /**
   * Start listening for voice commands
   */
  const startListening = useCallback(() => {
    if (!isSupported) {
      setError('Voice commands are not supported in this browser')
      return
    }

    if (isListening) {
      return
    }

    try {
      setRecognizedText('')
      recognitionRef.current.manualStop = false // Clear manual stop flag
      recognitionRef.current.start()
    } catch (err) {
      console.error('Error starting recognition:', err)
      setError('Failed to start voice recognition')
    }
  }, [isSupported, isListening])

  /**
   * Stop listening
   */
  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.manualStop = true // Set flag to prevent auto-restart
      recognitionRef.current.stop()
    }
  }, [isListening])

  /**
   * Toggle listening state
   */
  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }, [isListening, startListening, stopListening])

  /**
   * Toggle mute state for TTS
   */
  const toggleMute = useCallback(() => {
    const newMutedState = !isMuted
    setIsMuted(newMutedState)
    ttsService.setMuted(newMutedState)
  }, [isMuted])

  /**
   * Stop speaking
   */
  const stopSpeaking = useCallback(() => {
    ttsService.cancel()
    setIsSpeaking(false)
  }, [])

  /**
   * Clear conversation history
   */
  const clearConversation = useCallback(() => {
    setConversation([])
  }, [])

  /**
   * Process pending command (after edit/confirm)
   */
  const processPendingCommand = useCallback(async (transcript) => {
    setStatus('processing')
    setPendingCommand(null)

    // Classify if this is navigation, Q&A, or action
    const intent = classifyIntent(transcript)
    console.log('[Voice] Processing edited command:', intent, 'for:', transcript)

    // Copy the same processing logic from onresult
    if (intent.type === 'action') {
      setLastCommand(transcript)
      setStatus('recognized')

      if (intent.route) {
        setTimeout(() => {
          navigate(intent.route)
          setStatus('idle')
        }, 800)
      } else if (intent.action === 'submitClaim') {
        window.dispatchEvent(new CustomEvent('voiceSubmitClaim'))
        setStatus('idle')
      }
    } else if (intent.type === 'navigation') {
      const route = await recognizeVoiceIntent(transcript)

      if (route && route !== 'unknown') {
        setLastCommand(transcript)
        setStatus('recognized')

        setTimeout(() => {
          if (route === 'back') {
            navigate(-1)
          } else {
            navigate(route)
          }
          setStatus('idle')
        }, 800)
      } else {
        setStatus('not-recognized')
        setTimeout(() => {
          setStatus('idle')
        }, 2000)
      }
    } else {
      setStatus('answering')

      const questionEntry = {
        type: 'question',
        text: transcript,
        timestamp: new Date().toISOString(),
      }
      setConversation(prev => [...prev, questionEntry])

      try {
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Timeout')), 30000)
        )

        const result = await Promise.race([
          answerQuestion(transcript),
          timeoutPromise
        ])

        const answerEntry = {
          type: 'answer',
          text: result.answer,
          source: result.source,
          timestamp: new Date().toISOString(),
        }
        setConversation(prev => [...prev, answerEntry])

        setIsSpeaking(true)
        try {
          await ttsService.speak(result.answer)
        } catch (err) {
          console.error('[Voice] TTS error:', err)
        }
        setIsSpeaking(false)

      } catch (err) {
        console.error('[Voice] Q&A error:', err)

        const errorEntry = {
          type: 'answer',
          text: err.message === 'Timeout'
            ? 'Request timed out. Please try again.'
            : 'I encountered an error processing your question. Please try again.',
          source: 'error',
          timestamp: new Date().toISOString(),
        }
        setConversation(prev => [...prev, errorEntry])

        setIsSpeaking(true)
        try {
          await ttsService.speak(errorEntry.text)
        } catch (ttsErr) {
          console.error('[Voice] TTS error:', ttsErr)
        }
        setIsSpeaking(false)
      }

      setStatus('idle')
    }
  }, [navigate])

  /**
   * Confirm pending command
   */
  const confirmCommand = useCallback(() => {
    if (editableText) {
      processPendingCommand(editableText)
    }
  }, [editableText, processPendingCommand])

  /**
   * Cancel pending command
   */
  const cancelCommand = useCallback(() => {
    setPendingCommand(null)
    setEditableText('')
    setStatus('idle')
  }, [])

  /**
   * Update editable text
   */
  const updateEditableText = useCallback((text) => {
    setEditableText(text)
  }, [])

  return {
    isListening,
    lastCommand,
    recognizedText,
    status,
    isSupported,
    error,
    conversation,
    isSpeaking,
    isMuted,
    pendingCommand,
    editableText,
    correctionInfo,
    startListening,
    stopListening,
    toggleListening,
    toggleMute,
    stopSpeaking,
    clearConversation,
    confirmCommand,
    cancelCommand,
    updateEditableText,
  }
}
