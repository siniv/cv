import React, { createContext, useContext, useState } from 'react'
import { claimsData as initialClaimsData } from '../data/dummyData'

const ClaimsContext = createContext()

export function useClaimsContext() {
  const context = useContext(ClaimsContext)
  if (!context) {
    throw new Error('useClaimsContext must be used within ClaimsProvider')
  }
  return context
}

export function ClaimsProvider({ children }) {
  const [claims, setClaims] = useState(initialClaimsData)

  const addClaim = (claimData) => {
    const newClaim = {
      claimId: `CLM-2026-${String(1000 + claims.length).padStart(4, '0')}`,
      hospital: claimData.hospital || 'To be assigned',
      dateOfAdmission: claimData.dateOfAdmission || new Date().toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }),
      dateOfDischarge: claimData.dateOfDischarge || 'Pending',
      claimAmount: claimData.claimAmount || '$0',
      claimAmountValue: claimData.claimAmountValue || 0,
      approvedAmount: 'Pending',
      status: 'Draft',
      statusColor: 'yellow',
      claimType: claimData.claimType || 'Cashless',
      ailment: claimData.ailment || 'To be specified',
    }

    setClaims(prev => [...prev, newClaim])
    return newClaim
  }

  const updateClaim = (claimId, updates) => {
    setClaims(prev =>
      prev.map(claim =>
        claim.claimId === claimId ? { ...claim, ...updates } : claim
      )
    )
  }

  const deleteClaim = (claimId) => {
    setClaims(prev => prev.filter(claim => claim.claimId !== claimId))
  }

  return (
    <ClaimsContext.Provider value={{ claims, addClaim, updateClaim, deleteClaim }}>
      {children}
    </ClaimsContext.Provider>
  )
}
