import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { ClaimsProvider } from './context/ClaimsContext'
import LoginPage from './pages/LoginPage'
import DashboardPage from './pages/DashboardPage'
import PolicyPage from './pages/PolicyPage'
import ClaimsPage from './pages/ClaimsPage'
import NewClaimPage from './pages/NewClaimPage'
import HospitalsPage from './pages/HospitalsPage'
import HealthCardPage from './pages/HealthCardPage'

/**
 * Main App Component
 * Sets up routing and context providers for the health insurance application
 */
function App() {
  return (
    <Router>
      <ClaimsProvider>
        <Routes>
          {/* Login Route */}
          <Route path="/login" element={<LoginPage />} />

          {/* Dashboard Route */}
          <Route path="/dashboard" element={<DashboardPage />} />

          {/* Policy Details Route */}
          <Route path="/policy" element={<PolicyPage />} />

          {/* Claims Route */}
          <Route path="/claims" element={<ClaimsPage />} />

          {/* New Claim Route */}
          <Route path="/new-claim" element={<NewClaimPage />} />

          {/* Hospitals Route */}
          <Route path="/hospitals" element={<HospitalsPage />} />

          {/* Health Card Route */}
          <Route path="/health-card" element={<HealthCardPage />} />

          {/* Default Route - Redirect to Login */}
          <Route path="/" element={<Navigate to="/login" replace />} />

          {/* 404 - Redirect to Dashboard */}
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </ClaimsProvider>
    </Router>
  )
}

export default App
