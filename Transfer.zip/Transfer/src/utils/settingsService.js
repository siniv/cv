/**
 * Settings Service
 * Manages app settings using localStorage
 */

const SETTINGS_KEY = 'voiceapp_settings'

const DEFAULT_SETTINGS = {
  guardrailsEnabled: true, // Safety guardrails for medical advice, etc.
  editBeforeSubmit: false, // Allow editing transcription before processing
  wakeWordEnabled: false, // Require "genie" wake word before commands
  smartCorrection: true, // Use LLM to correct unclear transcriptions
}

/**
 * Get all settings
 */
export function getSettings() {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY)
    if (stored) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) }
    }
  } catch (error) {
    console.error('[Settings] Error loading settings:', error)
  }
  return DEFAULT_SETTINGS
}

/**
 * Update settings
 */
export function updateSettings(updates) {
  try {
    const current = getSettings()
    const updated = { ...current, ...updates }
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated))
    return updated
  } catch (error) {
    console.error('[Settings] Error saving settings:', error)
    return getSettings()
  }
}

/**
 * Get specific setting
 */
export function getSetting(key) {
  const settings = getSettings()
  return settings[key]
}

/**
 * Set specific setting
 */
export function setSetting(key, value) {
  return updateSettings({ [key]: value })
}

/**
 * Reset to defaults
 */
export function resetSettings() {
  try {
    localStorage.removeItem(SETTINGS_KEY)
    return DEFAULT_SETTINGS
  } catch (error) {
    console.error('[Settings] Error resetting settings:', error)
    return DEFAULT_SETTINGS
  }
}

/**
 * Check if guardrails are enabled
 */
export function areGuardrailsEnabled() {
  return getSetting('guardrailsEnabled')
}
