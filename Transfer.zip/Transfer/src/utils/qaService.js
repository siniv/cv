/**
 * Q&A Service
 * Hybrid approach: Rule-based (fast) + LLM fallback (smart)
 */

import { policyData, claimsData, hospitalsData, healthCardData, userProfile } from '../data/dummyData'
import { recognizeVoiceIntent, getLLMConfig } from './llmService'
import { areGuardrailsEnabled, getSetting } from './settingsService'

/**
 * Rule-based Q&A patterns
 * Maps question patterns to data extraction and response templates
 */
const QA_RULES = [
  // Policy Number
  {
    patterns: ['policy number', 'what is my policy number', 'my policy number', 'policy id'],
    extract: () => policyData.policyNumber,
    template: (data) => `Your policy number is ${data}.`,
  },

  // Sum Insured
  {
    patterns: ['sum insured', 'coverage amount', 'insured amount', 'how much coverage'],
    extract: () => policyData.sumInsured,
    template: (data) => `Your sum insured is ${data}.`,
  },

  // Policy Expiry
  {
    patterns: ['when does my policy expire', 'expiry date', 'valid until', 'policy validity'],
    extract: () => policyData.validUntil,
    template: (data) => `Your policy is valid until ${data}.`,
  },

  // Premium
  {
    patterns: ['premium', 'how much do i pay', 'premium amount', 'policy cost'],
    extract: () => policyData.premium,
    template: (data) => `Your annual premium is ${data}.`,
  },

  // Claims Count
  {
    patterns: ['how many claims', 'number of claims', 'total claims', 'my claims count'],
    extract: () => claimsData.length,
    template: (data) => `You have ${data} ${data === 1 ? 'claim' : 'claims'} in your history.`,
  },

  // Pending Claims
  {
    patterns: ['pending claims', 'claims under review', 'processing claims'],
    extract: () => claimsData.filter(c => c.status === 'Under Review'),
    template: (data) => {
      if (data.length === 0) return 'You have no pending claims.'
      return `You have ${data.length} claim${data.length > 1 ? 's' : ''} under review.`
    },
  },

  // Settled Claims
  {
    patterns: ['settled claims', 'approved claims', 'completed claims', 'claims settled', 'how many settled'],
    extract: () => claimsData.filter(c => c.status === 'Settled'),
    template: (data) => {
      if (data.length === 0) return 'You have no settled claims.'
      const totalAmount = data.reduce((sum, claim) => sum + claim.claimAmountValue, 0)
      return `You have ${data.length} settled claim${data.length > 1 ? 's' : ''}, with a total approved amount of $${totalAmount.toLocaleString()}.`
    },
  },

  // Last Claim (More variations)
  {
    patterns: ['last claim', 'my last claim', 'most recent claim', 'newest claim', 'latest claim from history'],
    extract: () => claimsData[claimsData.length - 1],
    template: (data) =>
      `Your most recent claim is ${data.claimId} for ${data.ailment} at ${data.hospital}. Amount: ${data.claimAmount}, Status: ${data.status}.`,
  },

  // First Claim
  {
    patterns: ['first claim', 'oldest claim', 'earliest claim'],
    extract: () => claimsData[0],
    template: (data) =>
      `Your earliest claim is ${data.claimId} for ${data.ailment} at ${data.hospital}. Amount: ${data.claimAmount}, Status: ${data.status}.`,
  },

  // Claim Details by Hospital
  {
    patterns: ['claims at upmc', 'claims at allegheny', 'upmc claims', 'allegheny claims'],
    extract: () => {
      const hospital = claimsData.filter(c =>
        c.hospital.toLowerCase().includes('upmc') ||
        c.hospital.toLowerCase().includes('allegheny')
      )
      return hospital
    },
    template: (data) => {
      if (data.length === 0) return 'You have no claims at UPMC or Allegheny hospitals.'
      return `You have ${data.length} claim${data.length > 1 ? 's' : ''} at Pittsburgh hospitals.`
    },
  },

  // Total Claim Amount
  {
    patterns: ['total claim amount', 'how much claimed', 'total claims value', 'sum of claims'],
    extract: () => {
      const total = claimsData.reduce((sum, claim) => sum + claim.claimAmountValue, 0)
      return total
    },
    template: (data) => `Your total claim amount across all claims is $${data.toLocaleString()}.`,
  },

  // Hospitals Count
  {
    patterns: ['how many hospitals', 'number of hospitals', 'hospital count'],
    extract: () => hospitalsData.length,
    template: (data) => `There are ${data} cashless network hospitals available.`,
  },

  // Family Members
  {
    patterns: ['family members', 'who is covered', 'covered members', 'insured members'],
    extract: () => policyData.familyMembers,
    template: (data) => {
      const names = data.map(m => m.name).join(', ')
      return `Your policy covers ${data.length} members: ${names}.`
    },
  },

  // Emergency Helpline
  {
    patterns: ['emergency number', 'helpline', 'emergency contact', 'support number'],
    extract: () => healthCardData.emergencyHelpline,
    template: (data) => `The 24x7 emergency helpline number is ${data}.`,
  },

  // Plan Name
  {
    patterns: ['plan name', 'policy plan', 'what plan', 'insurance plan'],
    extract: () => policyData.planName,
    template: (data) => `You are on the ${data} plan.`,
  },

  // Renewal Date
  {
    patterns: ['renewal date', 'when to renew', 'renewal time'],
    extract: () => policyData.renewalDate,
    template: (data) => `Your policy renewal date is ${data}.`,
  },
]

/**
 * Out-of-scope question patterns
 * These should NOT be answered - they're beyond the app's scope
 */
const OUT_OF_SCOPE_PATTERNS = {
  medicalAdvice: [
    'symptom', 'diagnose', 'diagnosis', 'treatment', 'medicine', 'medication',
    'drug', 'prescription', 'cure', 'disease', 'illness', 'pain', 'fever',
    'headache', 'cough', 'cold', 'what should i take', 'should i take',
    'recommend medicine', 'suggest treatment', 'medical advice'
  ],
  nonInsurance: [
    'weather', 'news', 'stock', 'recipe', 'movie', 'song',
    'sports', 'game', 'directions', 'restaurant', 'hotel'
  ],
  personalInfo: [
    'age', 'address', 'phone number', 'email', 'ssn', 'social security'
  ]
}

/**
 * Check if question is out of scope
 */
function isOutOfScope(text) {
  const lowerText = text.toLowerCase()

  // Check medical advice patterns
  const isMedicalAdvice = OUT_OF_SCOPE_PATTERNS.medicalAdvice.some(
    pattern => lowerText.includes(pattern)
  )

  if (isMedicalAdvice) {
    return {
      isOutOfScope: true,
      reason: 'medical',
      message: "Sorry, that is not part of this portal."
    }
  }

  // Check non-insurance patterns
  const isNonInsurance = OUT_OF_SCOPE_PATTERNS.nonInsurance.some(
    pattern => lowerText.includes(pattern)
  )

  if (isNonInsurance) {
    return {
      isOutOfScope: true,
      reason: 'non-insurance',
      message: "Sorry, that is not part of this portal."
    }
  }

  return { isOutOfScope: false }
}

/**
 * Action command patterns
 * For triggering UI actions (not navigation or Q&A)
 */
const ACTION_PATTERNS = {
  startNewClaim: [
    'start new claim', 'file a claim', 'create claim', 'new claim',
    'click start new claim', 'click on start new claim', 'file claim',
    'start claim', 'create new claim', 'submit new claim'
  ],
  submitClaim: [
    'submit claim', 'submit the claim', 'create claim', 'save claim',
    'click submit', 'click on submit', 'send claim'
  ],
  cancelForm: [
    'cancel', 'go back', 'exit form', 'close form', 'nevermind'
  ],
}

/**
 * Classify if the command is navigation, Q&A, or action
 */
export function classifyIntent(text) {
  const lowerText = text.toLowerCase()

  // Check for action commands first (highest priority in certain contexts)
  const isStartClaim = ACTION_PATTERNS.startNewClaim.some(pattern =>
    lowerText.includes(pattern)
  )
  if (isStartClaim) {
    return { type: 'action', action: 'startNewClaim', route: '/new-claim' }
  }

  const isSubmitClaim = ACTION_PATTERNS.submitClaim.some(pattern =>
    lowerText.includes(pattern)
  )
  if (isSubmitClaim) {
    return { type: 'action', action: 'submitClaim' }
  }

  // Navigation keywords
  const navKeywords = [
    'go to', 'show', 'open', 'navigate', 'take me to',
    'dashboard', 'logout', 'exit'
  ]

  // Question keywords
  const questionKeywords = [
    'what', 'when', 'where', 'how', 'who', 'which',
    'does', 'do', 'is', 'are', 'can', 'will', 'would', 'should',
    'tell me', 'explain', 'describe', 'list'
  ]

  // Check for navigation
  const isNavigation = navKeywords.some(kw => lowerText.includes(kw))

  // Check for question
  const isQuestion = questionKeywords.some(kw => lowerText.includes(kw)) || lowerText.includes('?')

  if (isNavigation && !isQuestion) {
    return { type: 'navigation' }
  }

  if (isQuestion) {
    return { type: 'qa' }
  }

  // Default: try rule-based matching
  const hasRuleMatch = QA_RULES.some(rule =>
    rule.patterns.some(pattern => lowerText.includes(pattern))
  )

  return { type: hasRuleMatch ? 'qa' : 'navigation' }
}

/**
 * Try to answer using rule-based patterns
 */
function tryRuleBasedAnswer(question) {
  const lowerQuestion = question.toLowerCase()

  for (const rule of QA_RULES) {
    // Check if question matches any pattern
    const matches = rule.patterns.some(pattern => lowerQuestion.includes(pattern))

    if (matches) {
      try {
        const data = rule.extract()
        const answer = rule.template(data)
        console.log('[Q&A] Rule-based match found:', answer)
        return answer
      } catch (error) {
        console.error('[Q&A] Error in rule extraction:', error)
        return null
      }
    }
  }

  return null
}

/**
 * Get context data for LLM
 */
function getContextForLLM(question) {
  const lowerQuestion = question.toLowerCase()

  let context = {
    userProfile,
    policyData: {
      policyNumber: policyData.policyNumber,
      planName: policyData.planName,
      sumInsured: policyData.sumInsured,
      validUntil: policyData.validUntil,
      premium: policyData.premium,
      familyMembers: policyData.familyMembers,
    }
  }

  // Add relevant data based on question keywords
  if (lowerQuestion.includes('claim')) {
    context.claims = claimsData
  }

  if (lowerQuestion.includes('hospital')) {
    context.hospitals = hospitalsData.slice(0, 3) // Send top 3 to keep prompt small
  }

  // Include benefits for coverage questions or specific conditions
  if (lowerQuestion.includes('benefit') ||
      lowerQuestion.includes('coverage') ||
      lowerQuestion.includes('cover') ||
      lowerQuestion.includes('covid') ||
      lowerQuestion.includes('ayush') ||
      lowerQuestion.includes('maternity') ||
      lowerQuestion.includes('does my policy') ||
      lowerQuestion.includes('what does')) {
    context.benefits = policyData.benefits
    context.coverage = policyData.coverage
    console.log('[Q&A] Including benefits in context:', policyData.benefits)
  }

  if (lowerQuestion.includes('exclusion') || lowerQuestion.includes('not covered')) {
    context.exclusions = policyData.exclusions
  }

  if (lowerQuestion.includes('card') || lowerQuestion.includes('helpline')) {
    context.healthCard = healthCardData
  }

  return context
}

/**
 * Use LLM to answer complex questions
 */
async function tryLLMAnswer(question) {
  const config = getLLMConfig()

  // Only use LLM if Ollama or Gemini is configured
  if (config.provider === 'simple') {
    console.log('[Q&A] LLM provider is set to simple, skipping LLM')
    return null
  }

  try {
    console.log('[Q&A] Attempting LLM answer with provider:', config.provider)
    const context = getContextForLLM(question)

    // Prepare prompt for LLM
    const prompt = `You are a helpful health insurance assistant. Answer the user's question based ONLY on the provided policy data.

Policy Data:
${JSON.stringify(context, null, 2)}

User Question: ${question}

CRITICAL RULES:
- ONLY answer questions about insurance policy, claims, coverage, and hospitals
- DO NOT provide medical advice, diagnoses, or medication recommendations
- DO NOT answer questions unrelated to insurance
- Provide clear, concise answers in 1-3 sentences
- Use natural language, as if speaking to the user
- Only use information from the provided data above
- If you don't have the information, say: "I don't have that information in your policy data"
- If the question is asking for medical advice, respond: "I cannot provide medical advice. Please consult a healthcare professional."

Answer:`

    // Call LLM through the existing llmService
    const answer = await callLLMForQA(prompt, config)

    console.log('[Q&A] LLM answer received:', answer)
    return answer
  } catch (error) {
    console.error('[Q&A] LLM error:', error)
    // Return error message instead of null
    return "I'm having trouble connecting to the AI service. Please try again or check if Ollama is running."
  }
}

/**
 * Call LLM API for Q&A
 */
async function callLLMForQA(prompt, config) {
  if (config.provider === 'ollama') {
    // Call Ollama
    const response = await fetch('http://localhost:11434/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3.2:3b',
        prompt: prompt,
        stream: false,
        options: {
          temperature: 0.7,
          num_predict: 150,
        },
      }),
    })

    if (!response.ok) throw new Error('Ollama API error')

    const data = await response.json()
    return data.response.trim()
  }

  if (config.provider === 'gemini') {
    // Call Gemini via Vertex AI
    const projectId = import.meta.env.VITE_GEMINI_PROJECT_ID
    const location = import.meta.env.VITE_GEMINI_LOCATION || 'us-central1'

    if (!projectId) {
      throw new Error('Gemini project ID not found')
    }

    const endpoint = `https://${location}-aiplatform.googleapis.com/v1/projects/${projectId}/locations/${location}/publishers/google/models/gemini-1.5-flash:generateContent`

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 150,
        },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('Gemini Vertex AI error:', errorText)
      throw new Error('Gemini API error')
    }

    const data = await response.json()
    return data.candidates[0]?.content?.parts[0]?.text?.trim() || null
  }

  return null
}

/**
 * Main Q&A function - Hybrid approach
 * Tries rule-based first, falls back to LLM
 */
/**
 * Correct unclear transcription using LLM
 * Helps when speech recognition misunderstands the user
 */
export async function correctTranscription(rawText) {
  const smartCorrectionEnabled = getSetting('smartCorrection')

  if (!smartCorrectionEnabled) {
    return { corrected: rawText, wasCorrected: false }
  }

  const config = getLLMConfig()

  // Only use LLM if Ollama or Gemini is configured
  if (config.provider === 'simple') {
    return { corrected: rawText, wasCorrected: false }
  }

  try {
    console.log('[Correction] Attempting to correct:', rawText)

    const prompt = `You are a speech recognition error correction assistant for a health insurance app.

The user tried to say something, but the speech recognition may have misheard them. Your job is to figure out what they ACTUALLY meant to say.

Context: This is a health insurance app where users can:
- Ask about their policy (policy number, coverage, benefits, exclusions)
- Ask about claims (how many, status, amounts)
- Ask about hospitals (locations, cashless network)
- Navigate (go to claims, show policy, find hospitals, show health card)

Common insurance terms: policy, claims, coverage, premium, benefits, hospitals, deductible, copay, COVID, maternity, AYUSH

Transcribed text (possibly incorrect): "${rawText}"

Instructions:
- If the transcription looks correct, return it as-is
- If it looks garbled or contains obvious errors, correct it to what the user LIKELY meant
- Consider common speech recognition errors (homophones, mumblings, partial words)
- Return ONLY the corrected text, nothing else
- Keep it concise (under 20 words)
- If it mentions insurance concepts, assume they're asking about their policy

Corrected text:`

    const corrected = await callLLMForQA(prompt, config)

    if (corrected && corrected.trim() !== rawText.trim()) {
      console.log('[Correction] Text corrected:', rawText, '→', corrected)
      return { corrected: corrected.trim(), wasCorrected: true, original: rawText }
    }

    return { corrected: rawText, wasCorrected: false }
  } catch (error) {
    console.error('[Correction] Error:', error)
    return { corrected: rawText, wasCorrected: false }
  }
}

/**
 * Main Q&A function - Hybrid approach
 * Tries rule-based first, falls back to LLM
 */
export async function answerQuestion(question) {
  console.log('[Q&A] ========================================')
  console.log('[Q&A] Question received:', question)

  try {
    // Step 0: Check if question is out of scope (only if guardrails enabled)
    const guardrailsEnabled = areGuardrailsEnabled()
    console.log('[Q&A] Guardrails enabled:', guardrailsEnabled)

    if (guardrailsEnabled) {
      const scopeCheck = isOutOfScope(question)
      if (scopeCheck.isOutOfScope) {
        console.log('[Q&A] Blocked by guardrails:', scopeCheck.reason)
        return {
          answer: scopeCheck.message,
          source: 'out-of-scope',
          confidence: 'high'
        }
      }
    }

    // Step 1: Try rule-based (instant)
    console.log('[Q&A] Trying rule-based matching...')
    const ruleAnswer = tryRuleBasedAnswer(question)
    if (ruleAnswer) {
      console.log('[Q&A] ✓ Rule-based answer found')
      return {
        answer: ruleAnswer,
        source: 'rule-based',
        confidence: 'high'
      }
    }

    // Step 2: Try LLM (smart)
    console.log('[Q&A] Trying LLM...')
    const llmAnswer = await tryLLMAnswer(question)
    if (llmAnswer) {
      console.log('[Q&A] ✓ LLM answer received')
      return {
        answer: llmAnswer,
        source: 'llm',
        confidence: 'high'
      }
    }

    // Step 3: Default fallback
    console.log('[Q&A] No answer found, using fallback')
    return {
      answer: "Sorry, that is not part of this portal.",
      source: 'fallback',
      confidence: 'low'
    }
  } catch (error) {
    // Safety catch - ALWAYS return something
    console.error('[Q&A] Unexpected error:', error)
    return {
      answer: "I encountered an error processing your question. Please try again.",
      source: 'error',
      confidence: 'low'
    }
  }
}
