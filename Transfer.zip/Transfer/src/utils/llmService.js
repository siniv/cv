/**
 * LLM Service for Voice Command Intent Recognition
 * Supports Ollama (local) and Gemini API
 */

// Configuration
const LLM_CONFIG = {
  provider: 'simple', // 'ollama', 'gemini', or 'simple' (default pattern matching)

  // Ollama config (runs locally)
  ollama: {
    baseUrl: 'http://localhost:11434',
    model: 'llama3.2:3b', // or any other model you have installed
  },

  // Gemini config (Vertex AI - requires project ID and location)
  gemini: {
    projectId: import.meta.env.VITE_GEMINI_PROJECT_ID || '',
    location: import.meta.env.VITE_GEMINI_LOCATION || 'us-central1',
    model: 'gemini-1.5-flash',
  },
}

// System prompt for intent recognition
const SYSTEM_PROMPT = `You are a voice command intent classifier for a health insurance app.
Given a user's voice command, identify the intent and return ONLY the route path or action.

Available routes:
- /dashboard (dashboard, home, main page)
- /policy (policy, policy details, view policy, show policy)
- /claims (claims, view claims, show claims, my claims)
- /hospitals (hospitals, find hospitals, network hospitals, cashless hospitals)
- /health-card (health card, download card, show card, view card)
- back (go back, previous, return)
- /login (logout, log out, sign out, exit)

Return ONLY the route path (e.g., "/policy" or "back"), nothing else.
If the command doesn't match any intent, return "unknown".

Examples:
- "show my policy" → /policy
- "I want to see claims" → /claims
- "find nearby hospitals" → /hospitals
- "go back" → back
- "what's the weather" → unknown`

/**
 * Ollama API call for intent recognition
 */
async function recognizeIntentWithOllama(voiceText) {
  try {
    const response = await fetch(`${LLM_CONFIG.ollama.baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: LLM_CONFIG.ollama.model,
        prompt: `${SYSTEM_PROMPT}\n\nUser command: "${voiceText}"\nRoute:`,
        stream: false,
        options: {
          temperature: 0.1,
          num_predict: 20,
        },
      }),
    })

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status}`)
    }

    const data = await response.json()
    const intent = data.response.trim().toLowerCase()

    // Validate and clean the response
    if (intent.startsWith('/') || intent === 'back' || intent === 'unknown') {
      return intent
    }

    return 'unknown'
  } catch (error) {
    console.error('Ollama error:', error)
    return null
  }
}

/**
 * Gemini API call for intent recognition (via Vertex AI)
 */
async function recognizeIntentWithGemini(voiceText) {
  const { projectId, location, model } = LLM_CONFIG.gemini

  if (!projectId) {
    console.error('Gemini project ID not found. Set VITE_GEMINI_PROJECT_ID in .env file')
    return null
  }

  try {
    // Vertex AI endpoint
    const endpoint = `https://${location}-aiplatform.googleapis.com/v1/projects/${projectId}/locations/${location}/publishers/google/models/${model}:generateContent`

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Note: In production, you'd need authentication headers here
        // For local dev with gcloud auth, the browser may handle this
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `${SYSTEM_PROMPT}\n\nUser command: "${voiceText}"\nRoute:`
          }]
        }],
        generationConfig: {
          temperature: 0.1,
          maxOutputTokens: 20,
        },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('Gemini Vertex AI error:', response.status, errorText)
      throw new Error(`Gemini API error: ${response.status}`)
    }

    const data = await response.json()
    const intent = data.candidates[0]?.content?.parts[0]?.text?.trim().toLowerCase()

    if (!intent) {
      return 'unknown'
    }

    // Validate and clean the response
    if (intent.startsWith('/') || intent === 'back' || intent === 'unknown') {
      return intent
    }

    return 'unknown'
  } catch (error) {
    console.error('Gemini error:', error)
    return null
  }
}

/**
 * Simple pattern matching fallback (no LLM required)
 */
function recognizeIntentWithPatternMatching(voiceText) {
  const text = voiceText.toLowerCase().trim()

  // Command mappings
  const commandMap = {
    '/dashboard': ['dashboard', 'home', 'main page', 'go home'],
    '/policy': ['policy', 'policy details', 'view policy', 'show policy', 'my policy', 'show my policy'],
    '/claims': ['claims', 'view claims', 'show claims', 'my claims', 'go to claims'],
    '/hospitals': ['hospitals', 'find hospitals', 'network hospitals', 'cashless hospitals', 'show hospitals'],
    '/health-card': ['health card', 'download card', 'show card', 'view card', 'download health card', 'show health card'],
    'back': ['back', 'go back', 'previous', 'previous page'],
    '/login': ['logout', 'log out', 'sign out', 'exit'],
  }

  // Try exact match first
  for (const [route, commands] of Object.entries(commandMap)) {
    for (const command of commands) {
      if (text === command || text.includes(command)) {
        return route
      }
    }
  }

  return 'unknown'
}

/**
 * Main function to recognize intent from voice text
 * Uses configured LLM provider or falls back to pattern matching
 */
export async function recognizeVoiceIntent(voiceText) {
  console.log(`[LLM Service] Recognizing intent for: "${voiceText}"`)
  console.log(`[LLM Service] Provider: ${LLM_CONFIG.provider}`)

  let intent = null

  // Try the configured provider
  switch (LLM_CONFIG.provider) {
    case 'ollama':
      intent = await recognizeIntentWithOllama(voiceText)
      break

    case 'gemini':
      intent = await recognizeIntentWithGemini(voiceText)
      break

    case 'simple':
    default:
      intent = recognizeIntentWithPatternMatching(voiceText)
      break
  }

  // Fallback to pattern matching if LLM failed
  if (intent === null || intent === 'unknown') {
    console.log('[LLM Service] Falling back to pattern matching')
    intent = recognizeIntentWithPatternMatching(voiceText)
  }

  console.log(`[LLM Service] Recognized intent: ${intent}`)
  return intent
}

/**
 * Get current LLM configuration
 */
export function getLLMConfig() {
  return {
    provider: LLM_CONFIG.provider,
    isOllamaConfigured: !!LLM_CONFIG.ollama.baseUrl,
    isGeminiConfigured: !!LLM_CONFIG.gemini.projectId,
  }
}

/**
 * Set LLM provider
 */
export function setLLMProvider(provider) {
  if (['ollama', 'gemini', 'simple'].includes(provider)) {
    LLM_CONFIG.provider = provider
    console.log(`[LLM Service] Provider set to: ${provider}`)
    return true
  }
  return false
}

/**
 * Test Ollama connection
 */
export async function testOllamaConnection() {
  try {
    const response = await fetch(`${LLM_CONFIG.ollama.baseUrl}/api/tags`)
    return response.ok
  } catch (error) {
    return false
  }
}

/**
 * Test Gemini connection (Vertex AI)
 */
export async function testGeminiConnection() {
  if (!LLM_CONFIG.gemini.projectId) {
    return false
  }

  const { projectId, location, model } = LLM_CONFIG.gemini

  try {
    const endpoint = `https://${location}-aiplatform.googleapis.com/v1/projects/${projectId}/locations/${location}/publishers/google/models/${model}:generateContent`

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: 'test' }]
        }],
        generationConfig: {
          maxOutputTokens: 1,
        },
      }),
    })

    return response.ok
  } catch (error) {
    console.error('Gemini test error:', error)
    return false
  }
}
