/**
 * Text-to-Speech Utility
 * Uses Web Speech API's SpeechSynthesis to speak responses
 */

class TextToSpeechService {
  constructor() {
    this.synthesis = window.speechSynthesis
    this.isSpeaking = false
    this.isMuted = false
    this.voice = null
    this.rate = 1.0
    this.pitch = 1.0

    // Initialize voices
    this.initVoices()
  }

  /**
   * Initialize available voices
   * Prefers female US English voices
   */
  initVoices() {
    const loadVoices = () => {
      const voices = this.synthesis.getVoices()

      // Priority order for voice selection:
      // 1. Female US English voices
      // 2. Any US English voice
      // 3. Any English voice
      // 4. First available voice

      // Try to find female US English voice
      let selectedVoice = voices.find(v =>
        v.lang === 'en-US' &&
        v.name.toLowerCase().includes('female')
      )

      // Fallback: Google US English (usually female)
      if (!selectedVoice) {
        selectedVoice = voices.find(v =>
          v.lang === 'en-US' &&
          v.name.toLowerCase().includes('google')
        )
      }

      // Fallback: Samantha (macOS female voice)
      if (!selectedVoice) {
        selectedVoice = voices.find(v =>
          v.name.toLowerCase().includes('samantha')
        )
      }

      // Fallback: Any US English voice
      if (!selectedVoice) {
        selectedVoice = voices.find(v => v.lang === 'en-US')
      }

      // Fallback: Any English voice
      if (!selectedVoice) {
        selectedVoice = voices.find(v => v.lang.startsWith('en-'))
      }

      // Last resort: first available voice
      this.voice = selectedVoice || voices[0]

      console.log('[TTS] Available voices:', voices.length)
      console.log('[TTS] Selected voice:', this.voice?.name, '(' + this.voice?.lang + ')')

      // Log all US English voices for debugging
      const usVoices = voices.filter(v => v.lang === 'en-US')
      if (usVoices.length > 0) {
        console.log('[TTS] Available US English voices:', usVoices.map(v => v.name).join(', '))
      }
    }

    // Load voices (Chrome needs this event listener)
    if (this.synthesis.onvoiceschanged !== undefined) {
      this.synthesis.onvoiceschanged = loadVoices
    }

    loadVoices()
  }

  /**
   * Speak text
   * @param {string} text - Text to speak
   * @param {object} options - Optional settings
   */
  speak(text, options = {}) {
    return new Promise((resolve, reject) => {
      // Don't speak if muted
      if (this.isMuted) {
        console.log('[TTS] Muted, not speaking:', text)
        resolve()
        return
      }

      // Cancel any ongoing speech
      this.cancel()

      // Create utterance
      const utterance = new SpeechSynthesisUtterance(text)

      // Apply settings
      utterance.voice = this.voice
      utterance.rate = options.rate || this.rate
      utterance.pitch = options.pitch || this.pitch
      utterance.volume = options.volume || 1.0

      // Event handlers
      utterance.onstart = () => {
        this.isSpeaking = true
        console.log('[TTS] Started speaking:', text.substring(0, 50))
      }

      utterance.onend = () => {
        this.isSpeaking = false
        console.log('[TTS] Finished speaking')
        resolve()
      }

      utterance.onerror = (event) => {
        this.isSpeaking = false
        console.error('[TTS] Error:', event.error)
        reject(event.error)
      }

      // Speak
      this.synthesis.speak(utterance)
    })
  }

  /**
   * Cancel current speech
   */
  cancel() {
    if (this.synthesis.speaking) {
      this.synthesis.cancel()
      this.isSpeaking = false
    }
  }

  /**
   * Pause speech
   */
  pause() {
    if (this.synthesis.speaking) {
      this.synthesis.pause()
    }
  }

  /**
   * Resume speech
   */
  resume() {
    if (this.synthesis.paused) {
      this.synthesis.resume()
    }
  }

  /**
   * Set mute state
   */
  setMuted(muted) {
    this.isMuted = muted
    if (muted) {
      this.cancel()
    }
  }

  /**
   * Check if currently speaking
   */
  getSpeakingState() {
    return this.isSpeaking
  }

  /**
   * Set speech rate (0.1 to 10)
   */
  setRate(rate) {
    this.rate = Math.max(0.1, Math.min(10, rate))
  }

  /**
   * Set speech pitch (0 to 2)
   */
  setPitch(pitch) {
    this.pitch = Math.max(0, Math.min(2, pitch))
  }

  /**
   * Get available voices
   */
  getVoices() {
    return this.synthesis.getVoices()
  }

  /**
   * Set voice by name
   */
  setVoice(voiceName) {
    const voices = this.getVoices()
    const voice = voices.find(v => v.name === voiceName)
    if (voice) {
      this.voice = voice
      return true
    }
    return false
  }
}

// Export singleton instance
export const ttsService = new TextToSpeechService()

// Export class for testing
export default TextToSpeechService
