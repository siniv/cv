# Health Insurance Voice-Enabled Web App

A responsive prototype web application for health insurance with hands-free voice navigation. This is a demo application inspired by health insurance apps like ICICI Lombard ILTakeCare, built with **dummy data only** and no real brand assets.

## ✨ Features

- 🎤 **Voice Command Navigation** - Navigate hands-free using voice commands
- 💬 **Conversational Q&A** - Ask questions and get spoken answers (like Siri)
- 🤖 **Hybrid AI** - Rule-based (instant) + LLM fallback (smart) question answering
- 🔊 **Text-to-Speech** - Spoken responses with mute/unmute controls
- 📱 **Desktop-Optimized UI** - Clean, modern interface built with React and Tailwind CSS
- 🏥 **Complete Insurance Portal** - Policy details, claims, hospitals, and digital health card
- 🔒 **Privacy-First** - All demo data is local, no real user information

## 📋 Pages

1. **Login Page** - Simple demo login (no real authentication)
2. **Dashboard** - Policy summary and quick actions
3. **Policy Details** - Comprehensive policy information
4. **Claims** - View and track insurance claims
5. **Hospitals** - Search cashless network hospitals
6. **Health Card** - Digital insurance card

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm/yarn/pnpm
- (Optional) Ollama for local AI voice processing
- (Optional) Google Gemini API key for cloud AI voice processing

### Installation

```bash
# 1. Install dependencies
npm install
# or
pnpm install
# or
yarn install

# 2. (Optional) Set up Gemini API key
cp .env.example .env
# Edit .env and add your Gemini API key

# 3. Start development server
npm run dev
# or
pnpm dev
# or
yarn dev
```

The app will open at `http://localhost:3000`

## 🎤 Voice Command Options

This app supports three modes for voice command processing:

### 1. Simple Pattern Matching (Default)
- **No setup required** - works out of the box
- Fast, offline keyword matching
- Good for exact commands like "show my policy" or "go to claims"

### 2. Ollama (Local AI)
- **Privacy-first** - runs entirely on your machine
- Better natural language understanding
- **Setup:**
  ```bash
  # Install Ollama from https://ollama.ai
  
  # Pull a model (llama3.2 recommended)
  ollama pull llama3.2
  
  # Start Ollama (runs on http://localhost:11434)
  ollama run llama3.2
  ```
- Click the settings icon (⚙️) in the Voice Assistant and select "Ollama"

### 3. Google Gemini (Cloud AI via Vertex AI)
- **Most powerful** - Google's latest AI model
- Best natural language understanding
- **Setup:**
  ```bash
  # 1. Set up Google Cloud project at https://console.cloud.google.com/
  # 2. Enable Vertex AI API
  # 3. Note your project ID and preferred location
  
  # 4. Create .env file
  cp .env.example .env
  
  # 5. Add your project ID and location to .env
  VITE_GEMINI_PROJECT_ID=your-project-id
  VITE_GEMINI_LOCATION=us-central1
  
  # 6. Authenticate (if needed):
  # gcloud auth application-default login
  ```
- Click the settings icon (⚙️) in the Voice Assistant and select "Google Gemini"

## 🗣️ Voice Commands & Q&A

### Navigation Commands
Try these to navigate between pages:
- "Go to dashboard"
- "Show my policy"
- "Go to claims"
- "Find hospitals"
- "Show health card"
- "Go back"
- "Logout"

### Ask Questions (NEW!)
The app can now answer questions about your insurance:

**Instant Answers (Rule-based):**
- "What's my policy number?"
- "When does my policy expire?"
- "What's my sum insured?"
- "How many claims do I have?"
- "What's my latest claim?"
- "What's the emergency helpline?"
- "Who is covered under my policy?"

**Smart Answers (LLM-powered with Ollama/Gemini):**
- "Tell me about my most recent claim"
- "Explain my policy benefits"
- "What's not covered in my insurance?"
- "Which hospitals are available nearby?"
- "How much premium do I pay?"

**How it works:**
1. Ask a question using the microphone
2. System detects if it's navigation or Q&A
3. For Q&A: tries rule-based first (instant), falls back to LLM (smart)
4. Speaks the answer using Text-to-Speech
5. Shows conversation history on screen

**Controls:**
- 🔇 Mute/Unmute button - Toggle voice output
- ⏹️ Stop button (appears when speaking) - Stop current speech
- 🗑️ Clear button (in conversation panel) - Clear chat history

**Scope & Safety:**
- ✅ Answers questions about: Policy, claims, coverage, hospitals, premiums
- ❌ Does NOT answer: Medical advice, diagnoses, medication recommendations
- ❌ Out of scope: Weather, news, directions, non-insurance questions
- 🛡️ Built-in guardrails prevent inappropriate medical advice

## 🎨 Tech Stack

- **React 18** - UI framework
- **Vite** - Build tool and dev server
- **React Router** - Client-side routing
- **Tailwind CSS** - Styling
- **Web Speech API** - Voice recognition
- **Ollama / Gemini** - AI-powered intent recognition (optional)

## 📁 Project Structure

```
sinproject/
├── src/
│   ├── components/
│   │   ├── VoiceAssistant.jsx      # Voice interface with Q&A
│   │   └── LLMSettings.jsx         # LLM provider settings
│   ├── pages/
│   │   ├── LoginPage.jsx
│   │   ├── DashboardPage.jsx
│   │   ├── PolicyPage.jsx
│   │   ├── ClaimsPage.jsx
│   │   ├── HospitalsPage.jsx
│   │   └── HealthCardPage.jsx
│   ├── hooks/
│   │   └── useVoiceCommands.js     # Voice + Q&A hook
│   ├── utils/
│   │   ├── llmService.js           # LLM integration (Ollama/Gemini)
│   │   ├── qaService.js            # Hybrid Q&A service
│   │   └── textToSpeech.js         # TTS utility
│   ├── data/
│   │   └── dummyData.js            # All dummy data
│   ├── App.jsx                     # Main app with routing
│   ├── main.jsx                    # Entry point
│   └── index.css                   # Global styles
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── .env.example                    # Gemini API key template
└── README.md
```

## 🔧 Configuration

### Change LLM Provider Programmatically

Edit `src/utils/llmService.js`:

```javascript
const LLM_CONFIG = {
  provider: 'simple', // Change to 'ollama', 'gemini', or 'simple'
  // ... other config
}
```

Or use the settings UI in the app (click ⚙️ icon in Voice Assistant).

### Customize Ollama Model

Edit `src/utils/llmService.js`:

```javascript
ollama: {
  baseUrl: 'http://localhost:11434',
  model: 'llama3.2', // Change to your preferred model
}
```

## 🎯 How It Works

### Voice Recognition Flow
1. **Speech Recognition** - Web Speech API captures your voice
2. **Text Conversion** - Speech is converted to text
3. **Intent Classification** - Determines if it's navigation or Q&A
4. **Action**:
   - **Navigation**: Routes you to the page
   - **Q&A**: Answers your question

### Q&A Processing (Hybrid Approach)
1. **Rule-Based Attempt** (instant, offline):
   - Matches question against predefined patterns
   - Extracts data from dummy data
   - Generates response from template
   - ⚡ Returns answer in milliseconds

2. **LLM Fallback** (smart, optional):
   - If no rule matches or question is complex
   - Sends question + relevant data to Ollama/Gemini
   - AI generates natural language response
   - 🤖 Returns in 1-3 seconds

3. **Text-to-Speech** (always):
   - Speaks the answer using browser's TTS
   - Shows conversation history on screen
   - Can be muted or stopped anytime

## 🚨 Browser Compatibility

Voice commands require browsers that support the Web Speech API:
- ✅ Chrome / Edge (recommended)
- ✅ Safari
- ⚠️ Firefox (limited support)

## 📝 Dummy Data

All data in this app is dummy/sample data:
- Policy information
- Claims history
- Hospital listings
- User profiles

**No real insurance data is used or stored.**

## ⚠️ Important Notes

- This is a **demonstration prototype only**
- Not connected to any real insurance provider
- Do not enter real personal or financial information
- Voice commands require microphone access

## 🏗️ Building for Production

```bash
# Build the app
npm run build

# Preview production build
npm run preview
```

The build output will be in the `dist/` folder.

## 🎓 Learning Resources

- [Web Speech API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API)
- [Ollama Documentation](https://ollama.ai/docs)
- [Google Gemini API](https://ai.google.dev/docs)
- [React Router](https://reactrouter.com/)
- [Tailwind CSS](https://tailwindcss.com/)

## 📄 License

This is a demonstration project for educational purposes.

## 🙋 Support

For issues or questions:
1. Check browser console for error messages
2. Verify microphone permissions are granted
3. For Ollama: Check if Ollama is running (`ollama list`)
4. For Gemini: Verify API key is set in `.env`

---

**Demo Disclaimer**: This app is not connected to any real insurer. All data is fictional.
