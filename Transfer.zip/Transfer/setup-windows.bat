@echo off
REM Windows Setup Script for Voice-Enabled Health Insurance Demo
REM Run this file after transferring the project to Windows

echo ========================================
echo Voice Insurance Demo - Windows Setup
echo ========================================
echo.

REM Check if Node.js is installed
echo [1/4] Checking Node.js installation...
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js is not installed!
    echo Please install Node.js from https://nodejs.org/
    echo.
    pause
    exit /b 1
)
echo Node.js found!
node --version
npm --version
echo.

REM Check if node_modules exists
if exist "node_modules\" (
    echo [2/4] node_modules folder already exists.
    echo Do you want to reinstall dependencies? (Y/N)
    set /p REINSTALL=
    if /i "%REINSTALL%"=="Y" (
        echo Removing old node_modules...
        rmdir /s /q node_modules
        del package-lock.json
        goto INSTALL
    ) else (
        goto ENV_CHECK
    )
) else (
    goto INSTALL
)

:INSTALL
echo [2/4] Installing dependencies...
echo This may take a few minutes...
npm install
if errorlevel 1 (
    echo ERROR: npm install failed!
    echo.
    pause
    exit /b 1
)
echo Dependencies installed successfully!
echo.

:ENV_CHECK
echo [3/4] Checking environment configuration...
if exist ".env" (
    echo .env file found!
) else (
    echo .env file not found.
    echo The app will use default settings (Simple pattern matching)
    echo To use Gemini AI, create .env file from .env.example
)
echo.

echo [4/4] Setup complete!
echo.
echo ========================================
echo Ready to run the application!
echo ========================================
echo.
echo To start the demo:
echo   npm run dev
echo.
echo Then open your browser to:
echo   http://localhost:5173
echo.
echo For more information, see WINDOWS_SETUP.md
echo.
pause
