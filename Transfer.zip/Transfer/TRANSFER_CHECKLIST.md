# Project Transfer Checklist

## ✅ Files/Folders to INCLUDE in Transfer

Copy these to your Windows laptop:

```
sinproject/
├── src/                    ✅ INCLUDE - All source code
├── public/                 ✅ INCLUDE - Static assets
├── .env.example            ✅ INCLUDE - Environment template
├── .gitignore              ✅ INCLUDE - Git ignore rules
├── index.html              ✅ INCLUDE - Entry HTML file
├── package.json            ✅ INCLUDE - Dependencies list
├── package-lock.json       ✅ INCLUDE - Locked dependency versions
├── postcss.config.js       ✅ INCLUDE - PostCSS config
├── tailwind.config.js      ✅ INCLUDE - Tailwind CSS config
├── vite.config.js          ✅ INCLUDE - Vite build config
├── README.md               ✅ INCLUDE - Main documentation
├── QA_SCOPE.md             ✅ INCLUDE - Voice Q&A documentation
├── WINDOWS_SETUP.md        ✅ INCLUDE - Windows setup guide
└── TRANSFER_CHECKLIST.md   ✅ INCLUDE - This file
```

## ❌ Files/Folders to EXCLUDE

**DO NOT** copy these (they will be regenerated on Windows):

```
❌ node_modules/          - Will be installed with npm install
❌ .DS_Store              - Mac-specific, not needed
❌ .env                   - Contains secrets (if exists)
❌ dist/                  - Build output (if exists)
❌ .vite/                 - Vite cache (if exists)
```

## 📦 Transfer Methods

### Option 1: USB Drive
1. Copy the entire `sinproject` folder to USB drive
2. Plug USB into Windows laptop
3. Copy folder to `C:\Users\YourUsername\Projects\`

### Option 2: OneDrive (Recommended - Already using it!)
Since your project is already in OneDrive:
1. Make sure OneDrive is syncing on Windows laptop
2. Navigate to the same OneDrive path on Windows
3. Wait for sync to complete
4. Run `npm install` in the folder

### Option 3: Zip File
1. Compress the `sinproject` folder (excluding node_modules)
2. Transfer zip file via email/cloud/network
3. Extract on Windows laptop

## 🔍 Verification After Transfer

On your Windows laptop, verify these files exist:

```bash
# Check if essential files are present
dir sinproject\package.json
dir sinproject\src
dir sinproject\index.html
dir sinproject\WINDOWS_SETUP.md
```

## 📊 Approximate Sizes

- **With node_modules**: ~150-200 MB
- **Without node_modules**: ~5-10 MB (recommended)

**Recommendation**: Transfer WITHOUT node_modules and run `npm install` on Windows.

## Next Steps

After transfer, follow **WINDOWS_SETUP.md** for complete setup instructions.
