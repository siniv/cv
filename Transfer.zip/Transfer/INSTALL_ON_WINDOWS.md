# Install on Windows - Complete Guide

## Transfer Size: Only 360 KB! 🎉
(Instead of 150+ MB with node_modules)

---

## STEP 1: Install Node.js

1. Download Node.js LTS from: **https://nodejs.org/**
2. Run the installer (node-v18.x.x-x64.msi or later)
3. Follow installation wizard (accept all defaults)
4. **Restart your computer** after installation

### Verify Installation:
Open Command Prompt and run:
```cmd
node --version
npm --version
```

You should see version numbers (e.g., v18.17.0 and 9.8.1)

---

## STEP 2: Copy Transfer Folder to Windows

Transfer the **entire "Transfer" folder** to your Windows laptop:

- Via USB drive
- Via OneDrive
- Via email/cloud storage

Place it somewhere convenient, for example:
```
C:\Users\YourName\Desktop\Transfer
```

---

## STEP 3: Install Dependencies

Open **Command Prompt** or **PowerShell** and navigate to the Transfer folder:

```cmd
cd C:\Users\YourName\Desktop\Transfer
```

Now install all required packages:

```cmd
npm install
```

This will download and install:
- React 18
- React Router
- Vite
- Tailwind CSS
- All other dependencies (150+ MB total)

**This will take 3-5 minutes depending on your internet speed.**

---

## STEP 4: Run the Application

Start the development server:

```cmd
npm run dev
```

You should see output like:
```
  VITE v4.x.x  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

---

## STEP 5: Open in Browser

Open **Chrome** or **Edge** browser and go to:
```
http://localhost:5173
```

The demo should load! 🎉

---

## STEP 6: Allow Microphone Access

When you click the microphone button:
1. Browser will ask for microphone permission
2. Click **Allow**
3. The microphone is now ready!

---

## Quick Commands Reference

### Navigate to project:
```cmd
cd C:\Users\YourName\Desktop\Transfer
```

### Install dependencies (first time only):
```cmd
npm install
```

### Run the app:
```cmd
npm run dev
```

### Stop the app:
Press **Ctrl + C** in the Command Prompt window

### Run on different port (if 5173 is busy):
```cmd
npm run dev -- --port 3000
```

---

## Optional: Setup Google Gemini AI

If you want to use Gemini (cloud AI):

1. Create a `.env` file in the Transfer folder
2. Add your Google Cloud credentials:
   ```
   VITE_GEMINI_PROJECT_ID=your-project-id
   VITE_GEMINI_LOCATION=us-central1
   ```

**Note:** The app works perfectly without this using simple pattern matching!

---

## Optional: Setup Ollama (Local AI)

If you want to use local AI:

1. Download Ollama from: **https://ollama.ai/download/windows**
2. Install Ollama
3. Open Command Prompt and run:
   ```cmd
   ollama pull llama3.2:3b
   ```
4. In the app settings, select "Ollama (Local AI)"

---

## Troubleshooting

### "npm is not recognized"
- Node.js not installed or not in PATH
- Solution: Reinstall Node.js and restart computer

### "Port 5173 is already in use"
- Solution: Use different port:
  ```cmd
  npm run dev -- --port 3000
  ```

### "Permission denied" errors
- Solution: Run Command Prompt as Administrator
  - Right-click Command Prompt → "Run as administrator"

### Microphone not working
- Use Chrome or Edge browser (best support)
- Check browser permissions (click lock icon in address bar)
- Allow microphone access for localhost

### "npm install" fails
- Check internet connection
- Try deleting `node_modules` folder and run again:
  ```cmd
  rmdir /s /q node_modules
  npm install
  ```

---

## What Gets Installed?

When you run `npm install`, these packages are downloaded:

**Main Dependencies:**
- react ^18.2.0
- react-dom ^18.2.0
- react-router-dom ^6.20.0

**Development Tools:**
- vite ^5.0.8
- tailwindcss ^3.4.0
- @vitejs/plugin-react ^4.2.1
- autoprefixer ^10.4.16
- postcss ^8.4.32

**Total size:** ~150-200 MB (stored in node_modules folder)

---

## Demo Features

Once running, you can:

✅ Click microphone to enable voice commands
✅ Say "Genie, show my policy" (if wake word enabled)
✅ Navigate: "Go to claims", "Find hospitals"
✅ Ask questions: "What's my policy number?"
✅ Smart speech correction for unclear audio
✅ Toggle settings (guardrails, wake word, etc.)

**Demo Data:**
- Policyholder: Michael Anderson
- Family: Sarah & Ethan Anderson
- Location: Pittsburgh, PA
- 8 network hospitals
- 3 sample claims

---

## File Structure

```
Transfer/
├── src/                    # All source code
│   ├── components/         # React components
│   ├── pages/             # Page components
│   ├── hooks/             # Voice command hooks
│   ├── utils/             # LLM, Q&A, TTS utilities
│   ├── data/              # Demo data
│   └── context/           # State management
├── public/                # Static files
├── package.json           # Dependencies list
├── package-lock.json      # Locked versions
├── index.html             # Entry point
├── vite.config.js         # Build configuration
├── tailwind.config.js     # Styling configuration
└── setup-windows.bat      # Automated setup script

After npm install:
├── node_modules/          # Downloaded packages (150MB+)
```

---

## Quick Start Summary

```cmd
# 1. Download Node.js from nodejs.org and install

# 2. Open Command Prompt and navigate to Transfer folder
cd C:\Users\YourName\Desktop\Transfer

# 3. Install dependencies (first time only)
npm install

# 4. Run the app
npm run dev

# 5. Open browser to http://localhost:5173
```

**That's it! You're ready to demo! 🎉**

---

## Support

- See **README.md** for detailed features
- See **QA_SCOPE.md** for voice command examples  
- See **WINDOWS_SETUP.md** for advanced setup
- Check browser console (F12) for error messages

---

**Note:** The Transfer folder is only 360 KB. After `npm install`, the node_modules folder will be ~150-200 MB, but you only download this once!
