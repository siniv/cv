# Q&A Scope & Boundaries

This document outlines what the voice assistant CAN and CANNOT answer.

## ✅ WITHIN SCOPE - Will Answer

### Policy Information
- ✓ "What's my policy number?"
- ✓ "When does my policy expire?"
- ✓ "What's my sum insured?"
- ✓ "Who is covered under my policy?"
- ✓ "How much is my premium?"
- ✓ "What's my plan name?"

### Claims Information
- ✓ "How many claims do I have?"
- ✓ "What's my latest claim?"
- ✓ "Show me pending claims"
- ✓ "What's the status of my claim?"
- ✓ "Tell me about my most recent claim"

### Coverage & Benefits
- ✓ "What's covered in my policy?"
- ✓ "What are my policy benefits?"
- ✓ "What's the room rent limit?"
- ✓ "Is maternity covered?"
- ✓ "What's not covered?" (exclusions)

### Hospitals
- ✓ "How many hospitals are available?"
- ✓ "Find hospitals near me"
- ✓ "Which hospitals accept cashless?"
- ✓ "Tell me about network hospitals"

### Contact Information
- ✓ "What's the emergency helpline?"
- ✓ "How do I contact support?"
- ✓ "What's the TPA number?"

---

## ❌ OUT OF SCOPE - Will NOT Answer

### Medical Advice (Blocked)
- ✗ "I have a headache, what medicine should I take?"
- ✗ "Can you diagnose my symptoms?"
- ✗ "What treatment do you recommend?"
- ✗ "Should I take antibiotics?"
- ✗ "What's the cure for diabetes?"

**Response:** "I'm an insurance assistant and cannot provide medical advice, diagnoses, or medication recommendations. Please consult a healthcare professional for medical concerns. I can help you find network hospitals or check your policy coverage."

### Non-Insurance Questions (Blocked)
- ✗ "What's the weather today?"
- ✗ "Tell me the news"
- ✗ "Where's a good restaurant?"
- ✗ "How do I get to the airport?"
- ✗ "Play some music"

**Response:** "I can only answer questions about your health insurance policy, claims, coverage, and network hospitals. I cannot help with that request."

### Personal Information Beyond Policy (Blocked)
- ✗ "What's my home address?"
- ✗ "What's my phone number?"
- ✗ "What's my social security number?"

**Response:** "I can only provide information from your insurance policy data."

### Unknown Insurance Questions (Fallback)
- ? "What's the deductible for dental work?"
- ? "Do you cover international travel?"

**Response:** "I'm sorry, I couldn't find an answer to that question. I can only help with information about your health insurance policy, claims, coverage, and network hospitals. Try asking about your policy number, claims, or available hospitals."

---

## 🛡️ Safety Features

1. **Pattern Matching** - Detects medical/diagnosis keywords and blocks instantly
2. **LLM Instructions** - Reinforces boundaries in AI prompts
3. **Scope Validation** - Checks every question before answering
4. **Graceful Decline** - Provides helpful alternative suggestions

---

## 💡 Example Conversations

### Good (In Scope)
```
User: "What's my policy number?"
Assistant: "Your policy number is DEMO-HI-2026-001."
```

```
User: "How many claims do I have?"
Assistant: "You have 3 claims in your history."
```

```
User: "Tell me about my latest claim"
Assistant: "Your latest claim is for appendicitis at UPMC Presbyterian Hospital, Pittsburgh. The claim amount is $6,200 and the status is Under Review."
```

### Blocked (Medical Advice)
```
User: "I have a fever, what should I take?"
Assistant: "I'm an insurance assistant and cannot provide medical advice, diagnoses, or medication recommendations. Please consult a healthcare professional for medical concerns. I can help you find network hospitals or check your policy coverage."
```

### Blocked (Non-Insurance)
```
User: "What's the weather today?"
Assistant: "I can only answer questions about your health insurance policy, claims, coverage, and network hospitals. I cannot help with that request."
```

---

## 📝 For Demo Purposes

When demonstrating the app, stick to insurance-related questions to showcase the Q&A capabilities effectively:

**Great Demo Questions:**
- "What's my policy number?"
- "How many claims do I have?"
- "What's my sum insured?"
- "Tell me about my latest claim"
- "How many hospitals are available?"
- "What's the emergency helpline?"
- "When does my policy expire?"
- "What's covered in my policy?"
