# Windows Setup Guide

This guide will help you set up the Voice-Enabled Health Insurance Demo on a Windows laptop.

## Prerequisites

Before you begin, install the following on your Windows laptop:

1. **Node.js** (v18 or higher)
   - Download from: https://nodejs.org/
   - Choose the LTS (Long Term Support) version
   - Verify installation: Open Command Prompt and run:
     ```
     node --version
     npm --version
     ```

2. **Git** (optional, for version control)
   - Download from: https://git-scm.com/download/win

## Step-by-Step Setup

### 1. Transfer the Project Folder

Copy the entire `sinproject` folder to your Windows laptop. You can:
- Use a USB drive
- Use OneDrive/cloud storage
- Use network transfer

Place it in a convenient location, for example:
```
C:\Users\YourUsername\Projects\sinproject
```

### 2. Install Dependencies

1. Open **Command Prompt** or **PowerShell** as Administrator
2. Navigate to the project folder:
   ```
   cd C:\Users\YourUsername\Projects\sinproject
   ```
3. Install dependencies:
   ```
   npm install
   ```
   This will take a few minutes to download all required packages.

### 3. Configure Environment (Optional)

If you want to use Google Gemini AI:

1. Create a `.env` file in the project root:
   ```
   copy .env.example .env
   ```
2. Edit `.env` and add your Google Cloud details:
   ```
   VITE_GEMINI_PROJECT_ID=your-project-id
   VITE_GEMINI_LOCATION=us-central1
   ```

**Note**: The app works perfectly without this - it will use the default simple pattern matching.

### 4. Run the Application

1. Start the development server:
   ```
   npm run dev
   ```

2. Open your browser and navigate to:
   ```
   http://localhost:5173
   ```

3. The application should now be running!

## Using the Voice Features

### Browser Requirements
- **Chrome** (recommended) - Best voice recognition support
- **Edge** - Good support
- **Firefox** - Limited support

### Voice Commands

1. Click the microphone button to start listening
2. If wake word is enabled, say "Genie" before your command
3. Try these commands:
   - "Show my policy"
   - "Go to claims"
   - "Find hospitals"
   - "What's my policy number?"
   - "How many claims do I have?"

### Settings

Click the settings gear icon to configure:
- **LLM Provider**: Simple (default), Ollama, or Gemini
- **Content Guardrails**: Enable/disable safety filters
- **Wake Word**: Require "Genie" before commands
- **Edit Before Submit**: Review transcriptions before processing
- **Smart Correction**: AI-powered speech correction

## Optional: Set Up Ollama (Local AI)

If you want to use local AI instead of cloud services:

1. Download Ollama for Windows:
   - Visit: https://ollama.ai/download/windows
   - Install the application

2. Pull the required model:
   ```
   ollama pull llama3.2:3b
   ```

3. Start Ollama (it should auto-start after installation)

4. In the app settings, select "Ollama (Local AI)" as the provider

## Troubleshooting

### Port Already in Use
If you see "Port 5173 is already in use":
```
npm run dev -- --port 3000
```

### Permission Errors
Run Command Prompt or PowerShell as Administrator

### Microphone Not Working
1. Check browser permissions (click the lock icon in the address bar)
2. Allow microphone access for localhost
3. Try Chrome or Edge browser

### npm install Fails
1. Delete `node_modules` folder and `package-lock.json`
2. Run `npm install` again
3. Make sure you have internet connection

## Project Structure

```
sinproject/
├── src/
│   ├── components/     # React components
│   ├── pages/         # Page components
│   ├── hooks/         # Custom React hooks
│   ├── utils/         # Utility functions (LLM, Q&A, TTS)
│   ├── data/          # Demo data
│   └── context/       # React context providers
├── public/            # Static assets
├── .env.example       # Environment variables template
├── package.json       # Dependencies
└── README.md          # Main documentation

```

## Default Demo Data

The demo includes:
- **Policyholder**: Michael Anderson
- **Family**: Sarah Anderson (spouse), Ethan Anderson (son)
- **Policy Number**: DEMO-HI-2026-001
- **Coverage**: $100,000
- **Location**: Pittsburgh, PA
- **Hospitals**: 8 Pittsburgh-area hospitals

## Support

For questions or issues:
1. Check README.md for detailed documentation
2. Review QA_SCOPE.md for voice command examples
3. Check browser console (F12) for error messages

## Quick Start Summary

```bash
# 1. Install Node.js from nodejs.org

# 2. Navigate to project folder
cd C:\Users\YourUsername\Projects\sinproject

# 3. Install dependencies
npm install

# 4. Run the app
npm run dev

# 5. Open browser to http://localhost:5173
```

That's it! The demo should now be running on your Windows laptop. 🎉
