// Voice Recognition and Q&A functionality
let recognition = null;
let isListening = false;
let settings = {
    guardrailsEnabled: true,
    wakeWordEnabled: false,
    smartCorrection: true,
    llmProvider: 'simple'
};

// Initialize on load
document.addEventListener('DOMContentLoaded', async () => {
    await loadSettings();
    initVoiceRecognition();
    loadConversation();
});

// Load settings from server
async function loadSettings() {
    try {
        const response = await fetch('/api/settings');
        settings = await response.json();
        updateSettingsUI();
    } catch (e) {
        console.error('Failed to load settings:', e);
    }
}

// Save settings to server
async function saveSettings() {
    try {
        await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings)
        });
    } catch (e) {
        console.error('Failed to save settings:', e);
    }
}

// Update settings UI
function updateSettingsUI() {
    updateToggle('guardrails-toggle', settings.guardrailsEnabled);
    updateToggle('wakeword-toggle', settings.wakeWordEnabled);
    updateToggle('correction-toggle', settings.smartCorrection);
    updateProviderUI(settings.llmProvider || 'simple');
}

function updateProviderUI(provider) {
    // Update radio buttons
    document.querySelectorAll('input[name="provider"]').forEach(radio => {
        radio.checked = radio.value === provider;
    });

    // Update visual styling
    ['simple', 'ollama', 'gemini'].forEach(p => {
        const el = document.getElementById(`provider-${p}`);
        if (el) {
            if (p === provider) {
                el.classList.remove('border-gray-200', 'hover:border-gray-300');
                el.classList.add('border-blue-500', 'bg-blue-50');
            } else {
                el.classList.remove('border-blue-500', 'bg-blue-50');
                el.classList.add('border-gray-200', 'hover:border-gray-300');
            }
        }
    });
}

function updateToggle(id, enabled) {
    const toggle = document.getElementById(id);
    if (!toggle) return;

    if (enabled) {
        toggle.classList.remove('bg-gray-200');
        toggle.classList.add('bg-blue-600', 'bg-purple-600');
        toggle.querySelector('span').classList.remove('translate-x-0');
        toggle.querySelector('span').classList.add('translate-x-5');
    } else {
        toggle.classList.remove('bg-blue-600', 'bg-purple-600');
        toggle.classList.add('bg-gray-200');
        toggle.querySelector('span').classList.remove('translate-x-5');
        toggle.querySelector('span').classList.add('translate-x-0');
    }
}

// Initialize Web Speech API
function initVoiceRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
        console.warn('Speech recognition not supported');
        return;
    }

    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = async (event) => {
        let transcript = event.results[event.results.length - 1][0].transcript.trim();
        console.log('Heard:', transcript);

        // Wake word check
        if (settings.wakeWordEnabled) {
            const wakeWords = ['genie', 'hey genie', 'ok genie', 'hi genie'];
            let hasWakeWord = false;
            let commandText = transcript;

            for (const wakeWord of wakeWords) {
                if (transcript.toLowerCase().startsWith(wakeWord)) {
                    hasWakeWord = true;
                    commandText = transcript.substring(wakeWord.length).trim();
                    if (commandText.startsWith(',')) {
                        commandText = commandText.substring(1).trim();
                    }
                    break;
                }
            }

            if (!hasWakeWord) {
                console.log('No wake word detected, ignoring');
                return;
            }

            transcript = commandText;
        }

        showRecognizedText(transcript);

        // Smart correction
        if (settings.smartCorrection && settings.llmProvider !== 'simple') {
            try {
                const response = await fetch('/api/correct-transcription', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ transcript })
                });
                const result = await response.json();

                if (result.wasCorrected) {
                    console.log('Corrected:', result.original, '→', result.corrected);
                    showCorrectionInfo(result.original, result.corrected);
                    transcript = result.corrected;
                } else {
                    hideCorrectionInfo();
                }
            } catch (e) {
                console.error('Correction failed:', e);
            }
        }

        // Classify intent
        const intent = classifyIntent(transcript);
        console.log('Intent:', intent.type);

        if (intent.type === 'navigation') {
            await handleNavigation(transcript);
        } else if (intent.type === 'action') {
            if (intent.route) {
                window.location.href = intent.route;
            }
        } else {
            await handleQuestion(transcript);
        }
    };

    recognition.onstart = () => {
        isListening = true;
        updateMicButton(true);
        setStatus('listening', settings.wakeWordEnabled ? '🎤 Listening for "Genie"...' : '🎤 Listening...');
    };

    recognition.onend = () => {
        if (isListening) {
            try {
                recognition.start();
            } catch (e) {
                isListening = false;
                updateMicButton(false);
            }
        } else {
            updateMicButton(false);
        }
    };

    recognition.onerror = (event) => {
        console.error('Recognition error:', event.error);
        isListening = false;
        updateMicButton(false);
    };
}

// Classify intent (navigation vs Q&A vs action)
function classifyIntent(text) {
    const lower = text.toLowerCase();

    // Action keywords
    if ((lower.includes('create') || lower.includes('new') || lower.includes('start')) && lower.includes('claim')) {
        return { type: 'action', route: '/new-claim' };
    }

    // Navigation keywords
    const navKeywords = ['show', 'go to', 'open', 'navigate', 'view', 'display'];
    if (navKeywords.some(kw => lower.includes(kw))) {
        return { type: 'navigation' };
    }

    // Question keywords
    const qKeywords = ['what', 'how', 'when', 'where', 'who', 'why', 'does', 'do', 'is', 'are', 'can', 'will'];
    if (qKeywords.some(kw => lower.startsWith(kw))) {
        return { type: 'question' };
    }

    return { type: 'question' };
}

// Handle navigation
async function handleNavigation(transcript) {
    const lower = transcript.toLowerCase();

    // Simple pattern matching
    if (lower.includes('dashboard') || lower.includes('home')) {
        window.location.href = '/dashboard';
    } else if (lower.includes('policy')) {
        window.location.href = '/policy';
    } else if (lower.includes('claim')) {
        window.location.href = '/claims';
    } else if (lower.includes('hospital')) {
        window.location.href = '/hospitals';
    } else if (lower.includes('health card') || lower.includes('card')) {
        window.location.href = '/health-card';
    } else if (lower.includes('back')) {
        window.history.back();
    } else {
        setStatus('error', '✗ Not recognized');
        setTimeout(() => setStatus('idle', 'Click microphone to start'), 2000);
    }
}

// Handle Q&A
async function handleQuestion(question) {
    setStatus('processing', 'Finding answer...');

    try {
        const response = await fetch('/api/qa', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question })
        });
        const result = await response.json();

        addToConversation('question', question);
        addToConversation('answer', result.answer, result.source);

        // Speak answer
        speakText(result.answer);

        setStatus('idle', 'Click microphone to start');
    } catch (e) {
        console.error('Q&A error:', e);
        setStatus('error', 'Error processing question');
        setTimeout(() => setStatus('idle', 'Click microphone to start'), 2000);
    }
}

// Text-to-Speech with better voice selection
let voicesLoaded = false;
let bestVoice = null;

// Load voices when available
function loadVoices() {
    const voices = speechSynthesis.getVoices();
    if (voices.length === 0) return null;

    // Priority order for best quality female US voices
    const priorities = [
        // Google voices (best quality)
        v => v.name === 'Google US English' && v.lang === 'en-US',
        v => v.name.includes('Google') && v.lang.startsWith('en-US'),
        v => v.name.includes('Google') && v.name.includes('Female'),

        // Samantha (macOS - excellent quality)
        v => v.name === 'Samantha',
        v => v.name.includes('Samantha'),

        // Microsoft voices (Windows - good quality)
        v => v.name.includes('Microsoft Zira'),
        v => v.name.includes('Microsoft') && v.name.includes('Female'),
        v => v.name.includes('Microsoft') && v.lang.startsWith('en-US'),

        // Generic female US voices
        v => v.lang.startsWith('en-US') && v.name.toLowerCase().includes('female'),
        v => v.lang.startsWith('en-US') && (v.name.includes('woman') || v.name.includes('girl')),

        // Any US English voice
        v => v.lang === 'en-US',
        v => v.lang.startsWith('en-US'),

        // Fallback to any English
        v => v.lang.startsWith('en'),
    ];

    for (const priorityFn of priorities) {
        const voice = voices.find(priorityFn);
        if (voice) {
            console.log('Selected voice:', voice.name);
            return voice;
        }
    }

    return voices[0]; // Ultimate fallback
}

// Initialize voices
if ('speechSynthesis' in window) {
    // Voices load asynchronously
    speechSynthesis.onvoiceschanged = () => {
        bestVoice = loadVoices();
        voicesLoaded = true;
    };

    // Try loading immediately (some browsers)
    bestVoice = loadVoices();
    if (bestVoice) voicesLoaded = true;
}

function speakText(text) {
    if (!('speechSynthesis' in window)) {
        console.warn('Speech synthesis not supported');
        return;
    }

    // Cancel any ongoing speech
    speechSynthesis.cancel();

    // Wait a bit for voices to load if needed
    const speak = () => {
        if (!voicesLoaded) {
            bestVoice = loadVoices();
            voicesLoaded = !!bestVoice;
        }

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-US';

        // Set best voice
        if (bestVoice) {
            utterance.voice = bestVoice;
        }

        // Quality settings for more natural speech
        utterance.rate = 0.95;      // Slightly slower than default (1.0)
        utterance.pitch = 1.1;      // Slightly higher pitch (female)
        utterance.volume = 1.0;     // Full volume

        speechSynthesis.speak(utterance);
    };

    // If voices not loaded yet, wait a bit
    if (!voicesLoaded && speechSynthesis.getVoices().length === 0) {
        setTimeout(speak, 100);
    } else {
        speak();
    }
}

// UI Updates
function toggleListening() {
    if (!recognition) {
        alert('Voice recognition not supported in this browser');
        return;
    }

    if (isListening) {
        isListening = false;
        recognition.stop();
    } else {
        isListening = true;
        recognition.start();
    }
}

function updateMicButton(active) {
    const button = document.getElementById('mic-button');
    if (active) {
        button.classList.remove('bg-blue-500', 'hover:bg-blue-600');
        button.classList.add('bg-red-500', 'hover:bg-red-600', 'animate-pulse');
    } else {
        button.classList.remove('bg-red-500', 'hover:bg-red-600', 'animate-pulse');
        button.classList.add('bg-blue-500', 'hover:bg-blue-600');
    }
}

function setStatus(type, message) {
    const statusEl = document.getElementById('status-message');
    statusEl.textContent = message;

    statusEl.className = 'text-sm font-medium ';
    if (type === 'listening') statusEl.className += 'text-blue-600';
    else if (type === 'processing') statusEl.className += 'text-yellow-600';
    else if (type === 'error') statusEl.className += 'text-red-600';
    else statusEl.className += 'text-gray-600';
}

function showRecognizedText(text) {
    const container = document.getElementById('recognized-text');
    const content = document.getElementById('recognized-content');
    content.textContent = `"${text}"`;
    container.classList.remove('hidden');
}

function showCorrectionInfo(original, corrected) {
    const container = document.getElementById('correction-info');
    document.getElementById('correction-original').textContent = `"${original}"`;
    document.getElementById('correction-corrected').textContent = `"${corrected}"`;
    container.classList.remove('hidden');
}

function hideCorrectionInfo() {
    document.getElementById('correction-info').classList.add('hidden');
}

// Conversation Management
function addToConversation(type, text, source) {
    const panel = document.getElementById('conversation-panel');
    const list = document.getElementById('conversation-list');

    const entry = document.createElement('div');
    entry.className = `p-3 rounded-lg ${type === 'question' ? 'bg-blue-50 border border-blue-200' : 'bg-green-50 border border-green-200'}`;

    entry.innerHTML = `
        <div class="flex items-start space-x-2">
            <span class="text-lg flex-shrink-0">${type === 'question' ? '❓' : '💬'}</span>
            <div class="flex-1">
                <p class="text-sm text-gray-900">${text}</p>
                ${source ? `<p class="text-xs text-gray-500 mt-1">${source === 'rule-based' ? '⚡ Instant' : '🤖 AI'}</p>` : ''}
            </div>
        </div>
    `;

    list.appendChild(entry);
    panel.classList.remove('hidden');
    list.scrollTop = list.scrollHeight;
}

async function clearConversation() {
    await fetch('/api/conversation', { method: 'DELETE' });
    document.getElementById('conversation-list').innerHTML = '';
    document.getElementById('conversation-panel').classList.add('hidden');
}

async function loadConversation() {
    try {
        const response = await fetch('/api/conversation');
        const conversation = await response.json();

        conversation.forEach(entry => {
            if (entry.type === 'question' || entry.type === 'answer') {
                addToConversation(entry.type, entry.text, entry.source);
            }
        });
    } catch (e) {
        console.error('Failed to load conversation:', e);
    }
}

// Settings
function toggleSettings() {
    const modal = document.getElementById('settings-modal');
    modal.classList.toggle('hidden');
}

async function toggleSetting(key) {
    settings[key] = !settings[key];
    await saveSettings();
    updateSettingsUI();
}

async function setProvider(provider) {
    settings.llmProvider = provider;
    await saveSettings();
    updateProviderUI(provider);
}

async function testOllama() {
    const statusEl = document.getElementById('ollama-status');
    statusEl.textContent = '⏳ Testing...';
    statusEl.className = 'text-sm text-yellow-600';

    try {
        const response = await fetch('/api/test-ollama');
        const result = await response.json();

        if (result.connected) {
            statusEl.textContent = '✓ Connected';
            statusEl.className = 'text-sm text-green-600';
        } else {
            statusEl.textContent = '✗ Failed';
            statusEl.className = 'text-sm text-red-600';
        }
    } catch (e) {
        statusEl.textContent = '✗ Error';
        statusEl.className = 'text-sm text-red-600';
    }

    // Clear status after 3 seconds
    setTimeout(() => {
        statusEl.textContent = '';
    }, 3000);
}
