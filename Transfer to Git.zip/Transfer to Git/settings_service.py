"""Settings Service for managing app settings"""
import json
import os

SETTINGS_FILE = 'settings.json'

DEFAULT_SETTINGS = {
    'guardrailsEnabled': True,
    'editBeforeSubmit': False,
    'wakeWordEnabled': False,
    'smartCorrection': True,
    'llmProvider': 'simple',
}

def get_settings():
    """Get all settings"""
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r') as f:
                stored = json.load(f)
                return {**DEFAULT_SETTINGS, **stored}
    except Exception as e:
        print(f'Error loading settings: {e}')
    return DEFAULT_SETTINGS

def update_settings(updates):
    """Update settings"""
    try:
        current = get_settings()
        updated = {**current, **updates}
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(updated, f, indent=2)
        return updated
    except Exception as e:
        print(f'Error saving settings: {e}')
        return get_settings()

def get_setting(key):
    """Get specific setting"""
    settings = get_settings()
    return settings.get(key)

def set_setting(key, value):
    """Set specific setting"""
    return update_settings({key: value})
