========================================
VOICE-ENABLED HEALTH INSURANCE DEMO
========================================

📦 Ready to Transfer to Windows Laptop
⏱️ Setup Time: 5-10 minutes
🎯 No admin access required

========================================
WHAT'S INCLUDED
========================================

✅ Complete Flask web application
✅ Voice navigation and Q&A
✅ Smart AI-powered speech correction
✅ Text-to-speech responses
✅ All demo data (US-based)
✅ Step-by-step setup guide

========================================
QUICK START
========================================

1. Read: WINDOWS_SETUP_GUIDE.txt (complete instructions)

2. Install Python from python.org

3. Run these commands:
   pip install --user flask requests google-cloud-aiplatform
   python app.py

4. Open browser: http://localhost:5001

5. Click microphone and speak!

========================================
FILE COUNT
========================================

• 6 Python files (app logic)
• 8 HTML templates (pages)
• 1 JavaScript file (voice features)
• 1 requirements.txt (package list)
• 2 guides (this file + setup guide)

Total: ~40 KB of code

========================================
FEATURES
========================================

Voice Navigation:
  "Show my policy"
  "Go to claims"
  "Find hospitals"

Voice Q&A:
  "What's my policy number?"
  "How many claims do I have?"
  "Does my policy cover COVID?"

Smart Features:
  • AI intent understanding
  • Speech correction
  • Wake word "Genie"
  • Conversation history
  • Multiple LLM options

========================================
NEXT STEP
========================================

👉 Open WINDOWS_SETUP_GUIDE.txt

This has complete step-by-step instructions for:
  • Installing Python
  • Installing packages
  • Running the app
  • Testing voice features
  • Troubleshooting

========================================

Everything you need is in this folder! 🚀
