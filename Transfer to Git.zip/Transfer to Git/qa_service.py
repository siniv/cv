"""Q&A Service with rule-based patterns and LLM fallback"""
import re
from data import policy_data, claims_data, hospitals_data, user_profile
from llm_service import call_ollama, call_gemini

# Question keywords for intent classification
QUESTION_KEYWORDS = ['what', 'how', 'when', 'where', 'who', 'why', 'does', 'do', 'is', 'are', 'can', 'will', 'would', 'should', 'which', 'tell me']
NAVIGATION_KEYWORDS = ['show', 'go to', 'open', 'navigate', 'view', 'display', 'take me']
ACTION_KEYWORDS = ['create', 'add', 'new', 'start', 'submit', 'file']

# Out of scope patterns for guardrails
OUT_OF_SCOPE_PATTERNS = [
    r'\b(diagnos|symptom|treat|medicine|medication|drug|prescri|cure|disease|illness)\b',
    r'\b(weather|news|sports|stock|bitcoin|crypto)\b',
]

def classify_intent(transcript):
    """Classify if command is navigation, Q&A, or action"""
    lower_text = transcript.lower()

    # Check for actions first
    if any(keyword in lower_text for keyword in ACTION_KEYWORDS):
        if 'claim' in lower_text:
            return {'type': 'action', 'action': 'newClaim', 'route': '/new-claim'}
        return {'type': 'action', 'action': 'unknown'}

    # Check for navigation
    if any(keyword in lower_text for keyword in NAVIGATION_KEYWORDS):
        return {'type': 'navigation'}

    # Check for questions
    if any(lower_text.startswith(keyword) for keyword in QUESTION_KEYWORDS):
        return {'type': 'question'}

    # Default to question for anything else
    return {'type': 'question'}

def check_guardrails(question):
    """Check if question is out of scope"""
    for pattern in OUT_OF_SCOPE_PATTERNS:
        if re.search(pattern, question, re.IGNORECASE):
            return {
                'blocked': True,
                'answer': "I'm focused on helping with health insurance questions. For medical advice, please consult a healthcare professional.",
                'source': 'guardrail'
            }
    return {'blocked': False}

def answer_question_rule_based(question):
    """Answer using rule-based patterns"""
    q_lower = question.lower()

    # Policy number
    if 'policy number' in q_lower or 'policy id' in q_lower:
        return {
            'answer': f"Your policy number is {policy_data['policyNumber']}.",
            'source': 'rule-based'
        }

    # Sum insured / coverage
    if ('sum insured' in q_lower or 'coverage' in q_lower or 'covered for' in q_lower) and 'how much' in q_lower:
        return {
            'answer': f"Your policy covers up to {policy_data['sumInsured']}.",
            'source': 'rule-based'
        }

    # Premium
    if 'premium' in q_lower and ('how much' in q_lower or 'cost' in q_lower or 'pay' in q_lower):
        return {
            'answer': f"Your annual premium is {policy_data['premium']}.",
            'source': 'rule-based'
        }

    # Claims count
    if 'how many claims' in q_lower or 'number of claims' in q_lower:
        return {
            'answer': f"You have {len(claims_data)} claims on record.",
            'source': 'rule-based'
        }

    # Settled claims
    if 'settled' in q_lower and 'claims' in q_lower:
        settled = [c for c in claims_data if c['status'] == 'Settled']
        return {
            'answer': f"You have {len(settled)} settled claims.",
            'source': 'rule-based'
        }

    # Pending claims
    if ('pending' in q_lower or 'under review' in q_lower) and 'claims' in q_lower:
        pending = [c for c in claims_data if c['status'] == 'Under Review']
        return {
            'answer': f"You have {len(pending)} claim under review.",
            'source': 'rule-based'
        }

    # Total claim amount
    if 'total' in q_lower and 'claim' in q_lower and ('amount' in q_lower or 'value' in q_lower):
        total = sum(c['claimAmountValue'] for c in claims_data)
        return {
            'answer': f"Your total claimed amount is ${total:,}.",
            'source': 'rule-based'
        }

    # Hospitals count
    if 'how many hospitals' in q_lower or 'number of hospitals' in q_lower:
        return {
            'answer': f"There are {len(hospitals_data)} network hospitals in your area.",
            'source': 'rule-based'
        }

    # Nearest hospital
    if 'nearest hospital' in q_lower or 'closest hospital' in q_lower:
        nearest = min(hospitals_data, key=lambda h: float(h['distance'].split()[0]))
        return {
            'answer': f"The nearest hospital is {nearest['name']} at {nearest['distance']}.",
            'source': 'rule-based'
        }

    # Policy validity
    if 'valid' in q_lower and ('until' in q_lower or 'till' in q_lower or 'expiry' in q_lower):
        return {
            'answer': f"Your policy is valid until {policy_data['validUntil']}.",
            'source': 'rule-based'
        }

    # Family members
    if 'family member' in q_lower or 'who is covered' in q_lower or 'who are covered' in q_lower:
        members = ', '.join([m['name'] for m in policy_data['familyMembers']])
        return {
            'answer': f"Your policy covers: {members}.",
            'source': 'rule-based'
        }

    # Coverage check - COVID
    if 'cover' in q_lower and 'covid' in q_lower:
        return {
            'answer': "Yes, COVID-19 treatment is covered under your policy.",
            'source': 'rule-based'
        }

    # Coverage check - maternity
    if 'cover' in q_lower and ('maternity' in q_lower or 'pregnancy' in q_lower):
        return {
            'answer': f"Maternity benefits are {policy_data['coverage']['maternityBenefit'].lower()}.",
            'source': 'rule-based'
        }

    return None

def answer_question_llm(question, provider='simple'):
    """Answer using LLM with insurance context"""
    if provider == 'simple':
        return None

    context = f"""You are a health insurance assistant. Answer based on this policy information:
Policy Number: {policy_data['policyNumber']}
Coverage: {policy_data['sumInsured']}
Premium: {policy_data['premium']}
Family: {', '.join([m['name'] for m in policy_data['familyMembers']])}
Claims: {len(claims_data)} total
Valid until: {policy_data['validUntil']}

Answer the question briefly and accurately. If information is not available, say so."""

    prompt = f"Question: {question}\n\nAnswer:"

    if provider == 'ollama':
        response = call_ollama(prompt, context)
    elif provider == 'gemini':
        response = call_gemini(prompt, context)
    else:
        return None

    if response:
        return {
            'answer': response.strip(),
            'source': 'llm'
        }
    return None

def answer_question(question, provider='simple', guardrails_enabled=True):
    """Main Q&A function with guardrails, rules, and LLM fallback"""
    # Check guardrails
    if guardrails_enabled:
        guard_result = check_guardrails(question)
        if guard_result['blocked']:
            return guard_result

    # Try rule-based first
    rule_answer = answer_question_rule_based(question)
    if rule_answer:
        return rule_answer

    # Try LLM fallback
    llm_answer = answer_question_llm(question, provider)
    if llm_answer:
        return llm_answer

    # Default response
    return {
        'answer': "I'm not sure about that. Could you ask about your policy, claims, or hospitals?",
        'source': 'fallback'
    }

def correct_transcription(transcript, provider='simple'):
    """Use LLM to understand intent and refine unclear transcriptions"""
    if provider == 'simple':
        return {'corrected': transcript, 'wasCorrected': False, 'original': transcript}

    system_message = """You are an intelligent voice assistant for health insurance that corrects speech transcription errors and refines questions.

Your job:
1. Understand the user's INTENT from potentially garbled speech
2. Fix transcription errors (mishearings, wrong words, missing words)
3. Refine the question to be clear and specific
4. Preserve the original meaning

Insurance context:
- User has a health insurance policy (policy number, premium, coverage, benefits)
- Can ask about claims (submitted, settled, pending, amounts)
- Can ask about hospitals (network, cashless, nearest)
- Can ask about coverage (what's covered, exclusions, limits)
- Can navigate (show policy, go to claims, find hospitals)

Common transcription errors:
- "polly see" → "policy"
- "clames" → "claims"
- "hospitable" → "hospital"
- "cloverage" → "coverage"
- "primeum" → "premium"
- "bene fits" → "benefits"

If the transcription is already clear and correct, return it unchanged.
If it's garbled or unclear, fix it and make it a proper question or command.

Examples:
Input: "what's my polly see number"
Output: "what's my policy number"

Input: "show me the clames"
Output: "show me the claims"

Input: "does cover cove it"
Output: "does my policy cover covid"

Input: "how many hospitable nearby"
Output: "how many hospitals are nearby"

Input: "go to dash board"
Output: "go to dashboard"
"""

    prompt = f'''Voice transcription (may contain errors): "{transcript}"

Understand the intent and provide the corrected, refined question or command.
Output ONLY the corrected text, nothing else:'''

    if provider == 'ollama':
        response = call_ollama(prompt, system_message)
    elif provider == 'gemini':
        response = call_gemini(prompt, system_message)
    else:
        return {'corrected': transcript, 'wasCorrected': False, 'original': transcript}

    if not response:
        return {'corrected': transcript, 'wasCorrected': False, 'original': transcript}

    # Clean up the response
    corrected = response.strip().strip('"').strip("'").strip()

    # Remove common LLM prefixes if present
    prefixes_to_remove = [
        'corrected:',
        'output:',
        'corrected transcription:',
        'refined:',
    ]
    corrected_lower = corrected.lower()
    for prefix in prefixes_to_remove:
        if corrected_lower.startswith(prefix):
            corrected = corrected[len(prefix):].strip()
            break

    was_corrected = corrected.lower() != transcript.lower()

    return {
        'corrected': corrected,
        'wasCorrected': was_corrected,
        'original': transcript
    }
