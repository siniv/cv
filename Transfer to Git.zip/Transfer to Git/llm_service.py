"""LLM Service for Ollama and Gemini integration"""
import os
import requests
import json

OLLAMA_BASE_URL = 'http://localhost:11434'
OLLAMA_MODEL = 'llama3.2:3b'

def get_llm_config():
    return {
        'provider': 'simple',
        'ollama': {
            'baseUrl': OLLAMA_BASE_URL,
            'model': OLLAMA_MODEL,
        },
        'gemini': {
            'projectId': os.getenv('GEMINI_PROJECT_ID', ''),
            'location': os.getenv('GEMINI_LOCATION', 'us-central1'),
            'model': 'gemini-1.5-flash',
        }
    }

def test_ollama_connection():
    """Test if Ollama is running"""
    try:
        response = requests.get(f'{OLLAMA_BASE_URL}/api/tags', timeout=2)
        return response.status_code == 200
    except:
        return False

def call_ollama(prompt, system_message=''):
    """Call Ollama API"""
    try:
        url = f'{OLLAMA_BASE_URL}/api/generate'
        data = {
            'model': OLLAMA_MODEL,
            'prompt': f'{system_message}\n\n{prompt}' if system_message else prompt,
            'stream': False,
        }
        response = requests.post(url, json=data, timeout=30)
        response.raise_for_status()
        return response.json().get('response', '')
    except Exception as e:
        print(f'Ollama error: {e}')
        return None

def call_gemini(prompt, system_message=''):
    """Call Google Gemini via Vertex AI"""
    try:
        from google.cloud import aiplatform
        from vertexai.preview.generative_models import GenerativeModel

        config = get_llm_config()
        aiplatform.init(
            project=config['gemini']['projectId'],
            location=config['gemini']['location']
        )

        model = GenerativeModel(config['gemini']['model'])
        full_prompt = f'{system_message}\n\n{prompt}' if system_message else prompt
        response = model.generate_content(full_prompt)
        return response.text
    except Exception as e:
        print(f'Gemini error: {e}')
        return None

def recognize_voice_intent(transcript, provider='simple'):
    """Recognize voice intent using LLM"""
    system_message = """You are a voice command router for a health insurance app.
Routes available:
- /dashboard - main page
- /policy - policy details
- /claims - view claims
- /hospitals - find hospitals
- /health-card - health card

Respond with ONLY the route path (e.g., "/policy") or "unknown" if unclear."""

    prompt = f'Voice command: "{transcript}"\n\nRoute:'

    if provider == 'ollama':
        response = call_ollama(prompt, system_message)
    elif provider == 'gemini':
        response = call_gemini(prompt, system_message)
    else:
        return 'unknown'

    if not response:
        return 'unknown'

    route = response.strip().lower()
    if route.startswith('/'):
        return route
    return 'unknown'
