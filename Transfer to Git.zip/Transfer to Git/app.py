"""Flask Voice-Enabled Health Insurance App"""
from flask import Flask, render_template, request, jsonify, session
from data import user_profile, policy_data, claims_data, hospitals_data, health_card_data
from qa_service import answer_question, classify_intent, correct_transcription
from llm_service import recognize_voice_intent, test_ollama_connection, get_llm_config
from settings_service import get_settings, update_settings, get_setting, set_setting
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Initialize session claims if not exists
def init_session():
    if 'claims' not in session:
        session['claims'] = claims_data.copy()
    if 'conversation' not in session:
        session['conversation'] = []

@app.before_request
def before_request():
    init_session()

# Routes
@app.route('/')
@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html',
                         user=user_profile,
                         policy=policy_data,
                         claims=session.get('claims', []))

@app.route('/policy')
def policy():
    return render_template('policy.html',
                         policy=policy_data)

@app.route('/claims')
def claims():
    return render_template('claims.html',
                         claims=session.get('claims', []))

@app.route('/new-claim', methods=['GET', 'POST'])
def new_claim():
    if request.method == 'POST':
        # Add new claim
        hospital = request.form.get('hospital')
        ailment = request.form.get('ailment')

        new_claim_data = {
            'claimId': f'CLM-2026-{len(session["claims"]) + 1:04d}',
            'hospital': hospital,
            'dateOfAdmission': datetime.now().strftime('%d %b %Y'),
            'dateOfDischarge': 'Pending',
            'claimAmount': 'Pending',
            'claimAmountValue': 0,
            'approvedAmount': 'Pending',
            'status': 'Submitted',
            'statusColor': 'blue',
            'claimType': 'Cashless',
            'ailment': ailment,
        }

        session['claims'].insert(0, new_claim_data)
        session.modified = True

        return jsonify({'success': True, 'claim': new_claim_data})

    return render_template('new_claim.html',
                         hospitals=hospitals_data)

@app.route('/hospitals')
def hospitals():
    return render_template('hospitals.html',
                         hospitals=hospitals_data)

@app.route('/health-card')
def health_card():
    return render_template('health_card.html',
                         card=health_card_data)

# API Routes
@app.route('/api/qa', methods=['POST'])
def api_qa():
    """Q&A API endpoint"""
    data = request.json
    question = data.get('question', '')
    provider = get_setting('llmProvider') or 'simple'
    guardrails = get_setting('guardrailsEnabled')

    result = answer_question(question, provider, guardrails)

    # Add to conversation history
    conversation = session.get('conversation', [])
    conversation.append({
        'type': 'question',
        'text': question,
        'timestamp': datetime.now().isoformat()
    })
    conversation.append({
        'type': 'answer',
        'text': result['answer'],
        'source': result['source'],
        'timestamp': datetime.now().isoformat()
    })
    session['conversation'] = conversation
    session.modified = True

    return jsonify(result)

@app.route('/api/voice-intent', methods=['POST'])
def api_voice_intent():
    """Voice intent recognition API"""
    data = request.json
    transcript = data.get('transcript', '')
    provider = get_setting('llmProvider') or 'simple'

    route = recognize_voice_intent(transcript, provider)
    return jsonify({'route': route})

@app.route('/api/correct-transcription', methods=['POST'])
def api_correct_transcription():
    """Transcription correction API"""
    data = request.json
    transcript = data.get('transcript', '')
    provider = get_setting('llmProvider') or 'simple'

    result = correct_transcription(transcript, provider)
    return jsonify(result)

@app.route('/api/settings', methods=['GET', 'POST'])
def api_settings():
    """Settings API"""
    if request.method == 'POST':
        updates = request.json
        updated = update_settings(updates)
        return jsonify(updated)

    return jsonify(get_settings())

@app.route('/api/test-ollama', methods=['GET'])
def api_test_ollama():
    """Test Ollama connection"""
    is_connected = test_ollama_connection()
    return jsonify({'connected': is_connected})

@app.route('/api/llm-config', methods=['GET'])
def api_llm_config():
    """Get LLM configuration"""
    return jsonify(get_llm_config())

@app.route('/api/conversation', methods=['GET', 'DELETE'])
def api_conversation():
    """Get or clear conversation history"""
    if request.method == 'DELETE':
        session['conversation'] = []
        session.modified = True
        return jsonify({'success': True})

    return jsonify(session.get('conversation', []))

if __name__ == '__main__':
    print('=' * 60)
    print('Voice-Enabled Health Insurance Demo')
    print('=' * 60)
    print('Starting Flask server...')
    print('Open your browser to: http://localhost:5001')
    print('=' * 60)
    app.run(debug=True, port=5001)
